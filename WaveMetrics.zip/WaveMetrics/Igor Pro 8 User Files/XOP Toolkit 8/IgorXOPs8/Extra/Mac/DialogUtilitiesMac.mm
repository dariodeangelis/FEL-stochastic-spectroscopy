﻿#import <Cocoa/Cocoa.h>
#import "DialogUtilitiesMac.h"

bool
RectIsEntirelyOnScreen(NSRect r)
{
	NSArray *screens = [NSScreen screens];
	NSInteger screenCount = [screens count];
	for(NSUInteger i = 0; i < screenCount; ++i) {
		NSScreen* screen = [screens objectAtIndex:i];
		NSRect screenRect = [screen visibleFrame];
		CGRect cgScreenRect = NSRectToCGRect(screenRect);	// These conversions are required
		CGRect cgRect = NSRectToCGRect(r);					// by the 32-bit compiler only
		if (CGRectContainsRect(cgScreenRect, cgRect))
			return true;
	}
	
	return false;
}

void
GetDialogPositionAndSize(NSWindow* window, DialogPositionAndSize* dp)
{
	NSRect frame = [ window frame ];
	dp->x = (short)frame.origin.x;
	dp->y = (short)frame.origin.y;
	dp->width = (short)frame.size.width;
	dp->height = (short)frame.size.height;
}

void
RestoreDialogPositionAndSize(NSWindow* window, DialogPositionAndSize* dp)
{
	NSUInteger modifiers = [ NSEvent modifierFlags ];
	if ((modifiers & NSAlternateKeyMask) == 0) {		// Press option key to prevent restoring window size and position
		if (dp->width!=0 && dp->height!=0) {
			NSRect frame;
			frame.origin.x = dp->x;
			frame.origin.y = dp->y;
			frame.size.width = dp->width;
			frame.size.height = dp->height;
			/*	This is not needed because Cocoa clips the window position when we set its frame.
				if (RectIsEntirelyOnScreen(frame))
			*/
			[ window setFrame:frame display:YES ];
		}
	}
}
