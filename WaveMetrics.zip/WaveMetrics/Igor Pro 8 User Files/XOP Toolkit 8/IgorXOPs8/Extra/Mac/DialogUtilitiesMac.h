﻿/*	DialogUtilitiesWin.h

	Declares routines used for Windows dialogs.
*/

#ifndef DIALOG_UTILITIES_MAC
#define DIALOG_UTILITIES_MAC

struct DialogPositionAndSize {
	short x;
	short y;
	short width;
	short height;
};
typedef struct DialogPositionAndSize DialogPositionAndSize;

#ifdef __OBJC__
	// We assume that the Cocoa headers are already #imported
	bool RectIsEntirelyOnScreen(NSRect r);
	void GetDialogPositionAndSize(NSWindow* window, DialogPositionAndSize* dp);
	void RestoreDialogPositionAndSize(NSWindow* window, DialogPositionAndSize* dp);
#endif

#endif		// DIALOG_UTILITIES_MAC
