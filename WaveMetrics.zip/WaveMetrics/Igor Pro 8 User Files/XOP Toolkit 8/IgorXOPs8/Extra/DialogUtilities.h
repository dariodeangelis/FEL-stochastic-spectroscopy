﻿#ifdef MACIGOR
	#include "../Extra/Mac/DialogUtilitiesMac.h"
#endif
#ifdef WINIGOR
	#include "..\Extra\Windows\DialogUtilitiesWin.h"
#endif
