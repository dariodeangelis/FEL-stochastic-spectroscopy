﻿/*	DialogUtilitiesWin.h

	Declares routines used for Windows dialogs.
*/

#ifndef DIALOG_UTILITIES_WIN
#define DIALOG_UTILITIES_WIN

#ifdef __cplusplus
extern "C" {						// This allows C++ to call the XOPSupport routines.
#endif

typedef HWND XOPDialogRef;

struct DialogPositionAndSize {
	short x;
	short y;
	short width;
	short height;
};
typedef struct DialogPositionAndSize DialogPositionAndSize;

BOOL RectIsEntirelyOnScreen(RECT r);
void RestoreDialogPositionAndSize(HWND theDialog, DialogPositionAndSize* dp);
void GetDialogPositionAndSize(HWND theDialog, DialogPositionAndSize* dp);

int IsWinDialogItemHitMessage(XOPDialogRef theDialog, int itemID, int notificationMessage);

void HideDialogItem(XOPDialogRef theDialog, int itemID);
void ShowDialogItem(XOPDialogRef theDialog, int itemID);

void GetDBox(XOPDialogRef theDialog, int itemID, Rect *box);
void MoveDItem(XOPDialogRef theDialog, int itemID, Rect *newItemBox);

void HiliteDControl(XOPDialogRef theDialog, int itemID, int enable);
void DisableDControl(XOPDialogRef theDialog, int itemID);
void EnableDControl(XOPDialogRef theDialog, int itemID);

int GetRadioButton(XOPDialogRef theDialog, int itemID);
void SetRadioButton(XOPDialogRef theDialog, int firstID, int lastID, int theID);

int ToggleCheckBox(XOPDialogRef theDialog, int itemID);
int GetCheckBox(XOPDialogRef theDialog, int itemID);
int SetCheckBox(XOPDialogRef theDialog, int itemID, int val);

int GetDText(XOPDialogRef theDialog, int theItem, char *theText);
void SetDText(XOPDialogRef theDialog, int theItem, const char *theText);
int GetDInt(XOPDialogRef theDialog, int theItem, int *theInt);
void SetDInt(XOPDialogRef theDialog, int theItem, int theInt);
int GetDInt64(XOPDialogRef theDialog, int theItem, SInt64* valPtr);
void SetDInt64(XOPDialogRef theDialog, int theItem, SInt64 val);
int GetDDouble(XOPDialogRef theDialog, int theItem, double *theDouble);
void SetDDouble(XOPDialogRef theDialog, int theItem, double theDouble);

void SelEditItem(XOPDialogRef theDialog, int itemID);

void InitPopMenus(XOPDialogRef theDialog);
int ItemIsPopMenu(XOPDialogRef theDialog, int itemID);
int CreatePopMenu(XOPDialogRef theDialog, int popupItemNumber, int titleItemNumber, const char* itemList, int initialItem);	// Added in Igor Pro 3.1 but works with any version.
void GetPopMenu(XOPDialogRef theDialog, int itemID, int *selItem, char *selStr);
int SetPopMatch(XOPDialogRef theDialog, int itemID, const char *selStr);
void SetPopItem(XOPDialogRef theDialog, int itemID, int theItem);
void KillPopMenus(XOPDialogRef theDialog);
void AddPopMenuItems(XOPDialogRef theDialog, int itemID, const char *itemList);
void FillPopMenu(XOPDialogRef theDialog, int itemID, const char *itemList, int itemListLen, int afterItem);
int FillWavePopMenu(XOPDialogRef theDialog, int itemID, const char *match, const char *options, int afterItem);
int FillPathPopMenu(XOPDialogRef theDialog, int itemID, const char *match, const char *options, int afterItem);
int FillWindowPopMenu(XOPDialogRef theDialog, int itemID, const char *match, const char *options, int afterItem);
void DeletePopMenuItems(XOPDialogRef theDialog, int itemID, int afterItem);

void DisplayDialogCmd(XOPDialogRef theDialog, int itemID, const char* cmd);
void ShowDialogWindow(XOPDialogRef theDialog);

#ifdef __cplusplus
}
#endif

#endif		// DIALOG_UTILITIES_WIN
