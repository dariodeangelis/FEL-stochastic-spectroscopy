﻿//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MenuXOP1.rc
//
#define IDR_MENU1                       100
#define IDR_MENU2                       101
#define IDR_MENU3                       102
#define IDR_MENU4                       103
#define IDR_MENU5                       104
#define ID_MENUXOP1_ITEM1               40001
#define ID_MENUXOP1_ITEM2               40002
#define ID_MENUXOP1_ITEM3               40003
#define ID_SUBMENU1_SUBITEM11           40004
#define ID_SUBMENU1_SUBITEM12           40005
#define ID_SUBMENU1_SUBITEM13           40006
#define ID_SUBMENU3_SUBITEM31           40007
#define ID_SUBMENU3_SUBITEM32           40008
#define ID_SUBMENU3_SUBITEM33           40009
#define ID_SUBMENU3_SUBITEM321          40010
#define ID_SUBMENU3_SUBITEM322          40011
#define ID_SUBMENU3_SUBITEM323          40012
#define ID_MENUXOP1_ANALYSISITEM1       40013
#define ID_MENUXOP1_ANALYSISITEM2       40014
#define ID_MENUXOP1_ANALYSISITEM3       40015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40016
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
