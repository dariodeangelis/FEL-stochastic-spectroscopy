/*
 *	MenuXOP1.h
 *		equates for MenuXOP1 XOP
 *
 */
 
/* MenuXOP1 custom error codes */

#define OLD_IGOR 1 + FIRST_XOP_ERR						// "MenuXOP1 requires Igor version 8.00 or later"
#define MAIN_MENU_ONLY 2 + FIRST_XOP_ERR				// "Expected resource ID of main MenuXOP1 menu (100)"
#define BAD_MENU_ID 3 + FIRST_XOP_ERR					// "Expected resource ID of MenuXOP1-accessible menu (100 to 104, 5 for Analysis, 8 for Misc)"
#define BAD_ITEM_NUM 4 + FIRST_XOP_ERR					// "Expected item number of MenuXOP1-accessible menu item"
#define EXPECTED_MENUXOP1_MENUID 5 + FIRST_XOP_ERR		// "Expected resource ID of MenuXOP1-created menu (100 to 104)"
#define EXPECTED_MENUXOP1_ITEMNUM 6 + FIRST_XOP_ERR		// "Expected item number of an item in a MenuXOP1-created menu"
#define MENU_INACCESSIBLE 7 + FIRST_XOP_ERR				// "Can't get menu reference possibly because it is a hidden main menu"

/* Prototypes */
HOST_IMPORT int XOPMain(IORecHandle ioRecHandle);
