/*	MenuXOP1.c - For illustrating XOP menu features

	HR, 020919: Revamped to use Operation Handler.
	
	HR, 091021
		Updated for 64-bit compatibility.

	HR, 2013-02-08
		Updated for Xcode 4 compatibility. Changed to use XOPMain instead of main.
		As a result the XOP now requires Igor Pro 6.20 or later.
		
	HR, 2013-05-21, MenuXOP1 version 2.00
		Changed to use new menu API provided by Igor 6.32 and XOP Toolkit 6.40.
		See "XOP Menu Compatibility" in XOPSupport/XOPMenus.c for details.

	HR, 2018-05-04
		Recompiled with XOP Toolkit 8 which supports long object names.
		As a result the XOP now requires Igor Pro 8.00 or later.
*/

#include "XOPStandardHeaders.h"				// Include ANSI headers, Mac headers, IgorXOP.h, XOP.h and XOPSupport.h
#include "MenuXOP1.h"

// These equates must agree with MENU, XMN1, XSM1 and XMI1 resources.
#ifdef MACIGOR
	#define MAINMENU_ID 100					// Menu resource ID of main menu.
	#define SUBMENU1_ID 101					// Menu resource ID of first submenu.
	#define SUBMENU2_ID 102					// Menu resource ID of second submenu.
	#define SUBMENU3_ID 103					// Menu resource ID of third submenu.
	#define SUBMENU4_ID 104					// Menu resource ID of fourth submenu.
#endif
#ifdef WINIGOR
	#include "resource.h"					// Contains symbols for menu resource IDs.
	#define MAINMENU_ID IDR_MENU1			// Menu resource ID of main menu.
	#define SUBMENU1_ID IDR_MENU2			// Menu resource ID of first submenu.
	#define SUBMENU2_ID IDR_MENU3			// Menu resource ID of second submenu.
	#define SUBMENU3_ID IDR_MENU4			// Menu resource ID of third submenu.
	#define SUBMENU4_ID IDR_MENU5			// Menu resource ID of fourth submenu.
#endif

// Global Variables
XOPMenuRef gMainMenuRef = NULL;				// Menu ref for main MenuXOP1 menu

/*	GetMenuRefAndItem(menuIDIn, itemNumberIn, allowIgorMenu, menuRefOut, itemNumberOut)

	This routine takes parameters passed to the MenuXOP1 operation and returns
	an actual menuRef and an actual item number. The calling routine uses
	the returned values to operation on a menu item.
	
	menuIDIn is either an Igor menu ID to which MenuXOP1 adds menu items
	(ANALYSISID or MISCID) or the resource menuID of a MenuXOP1 menu.
	
	If menuIDIn references an Igor menu then itemNumberIn is a *resource* item number.
	If menuIDIn reference a MenuXOP1 menu item then itemNumberIn is an actual item number.
	In either case the output item number is an actual item number.
	
	If menuIDIn references an Igor menu and allowIgorMenu is 0 then an error is returned.
	
	If menuIDIn references an Igor menu and allowIgorMenu is 1 then itemNumberIn
	must be the resource item number of an item added by MenuXOP1 to an Igor menu.
	Otherwise an error is returned.
	
	If menuIDIn references a MenuXOP1 menu then itemNumberIn can reference any
	valid item in the MenuXOP1 menu.
	
	*menuRefOut and *itemNumberOut are set to the menuRef and actual item
	number to use when acting on the referenced menu item.
	
	If menuIDIn is valid but the menu is hidden, GetMenuRefAndItem returns
	NULL via menuRefOut and 0 as the function result. This is not an error
	but the menu can not be accessed because it is hidden. The reason for
	this is that, when running with Igor Pro 6 and before, XOPActualMenuIDToMenuRef
	can not obtain the menuRef for a hidden menu. In Igor Pro 7 it can.
	
	Function result is 0 if OK or error code.
*/
static int
GetMenuRefAndItem(int menuIDIn, int itemNumberIn, int allowIgorMenu, XOPMenuRef* menuRefOut, int* itemNumberOut)
{
	XOPMenuRef menuRef;
	int actualMenuID, itemNumber;
	int isIgorMenu;

	*menuRefOut = NULL;
	*itemNumberOut = 0;
	
	actualMenuID = ResourceToActualMenuID(menuIDIn);
	isIgorMenu = actualMenuID == 0;
	if (isIgorMenu && !allowIgorMenu)
		return EXPECTED_MENUXOP1_MENUID;
	
	if (isIgorMenu) {
		actualMenuID = menuIDIn;		// Presumably an Igor menu with item added by XOP.
		if (actualMenuID!=MISCID && actualMenuID!=ANALYSISID)
			return BAD_MENU_ID;			// Only these menus are supported by MenuXOP1.
		menuRef = XOPActualMenuIDToMenuRef(actualMenuID);	// NULL if menu is hidden and we are running Igor Pro 6
		if (menuRef == NULL)
			return 0;					// Menu is hidden -- not in menu bar.
	}
	else {
		// menuIDIn should be a resource menuID of a MenuXOP1 resource
		menuRef = XOPResourceMenuIDToMenuRef(menuIDIn);
		if (menuRef == NULL)
			return BAD_MENU_ID;
	}

	itemNumber = itemNumberIn;
	if (isIgorMenu) {
		itemNumber = ResourceToActualItem(actualMenuID,itemNumberIn);
		if (itemNumber == 0)			// This item was not added to the Igor menu by the XOP
			return BAD_ITEM_NUM;
	}
		
	if (itemNumber<1 || itemNumber>XOPCountMenuItems(menuRef))
		return BAD_ITEM_NUM;
		
	*menuRefOut = menuRef;
	*itemNumberOut = itemNumber;
	
	return 0;
}

// Operation template: MenuXOP1 showMenu=number:showMenuID, hideMenu=number:hideMenuID, appendMenuItem={number:appendMenuID,string:appendItemText}, insertMenuItem={number:insertMenuID,number:insertAfterItemNumber,string:insertItemText}, deleteMenuItem={number:deleteMenuID,number:deleteItemNumber}, deleteMenuItemRange={number:deleteMenuItemRangeID,number:deleteMenuItemRangeFirst,number:deleteMenuItemRangeLast}, fillMenu={number:fillMenuID,number:fillMenuAfterItemNumber,string:fillMenuItemList}, fillMenuNoMeta={number:fillNoMetaMenuID,number:fillNoMetaAfterItemNumber,string:fillNoMetaItemList}, getMenuItemText={number:getTextMenuID,number:getTextItemNumber,varName:itemText}, setMenuItemText={number:setTextMenuID,number:setTextItemNumber,string:setTextText}, enableMenuItem={number:enableMenuID,number:enableItemNumber}, disableMenuItem={number:disableMenuID,number:disableItemNumber}, checkMenuItem={number:checkMenuID,number:checkMenuItemNumber,number:checkMenuState}, getMenuInfo={number:getMenuInfoID,varName:numMenuItems}, getMenuItemInfo={number:getMenuItemInfoID,number:getMenuItemInfoNumber,varName:enabledVar,varName:checkedVar}, quit

// Runtime param structure for MenuXOP1 operation.
#pragma pack(2)	// All structures passed to Igor are two-byte aligned.
struct MenuXOP1RuntimeParams {
	// Flag parameters.

	// Main parameters.

	// Parameters for showMenu keyword group.
	int showMenuEncountered;
	double showMenuID;
	int showMenuParamsSet[1];

	// Parameters for hideMenu keyword group.
	int hideMenuEncountered;
	double hideMenuID;
	int hideMenuParamsSet[1];

	// Parameters for appendMenuItem keyword group.
	int appendMenuItemEncountered;
	double appendMenuID;
	Handle appendItemText;
	int appendMenuItemParamsSet[2];

	// Parameters for insertMenuItem keyword group.
	int insertMenuItemEncountered;
	double insertMenuID;
	double insertAfterItemNumber;
	Handle insertItemText;
	int insertMenuItemParamsSet[3];

	// Parameters for deleteMenuItem keyword group.
	int deleteMenuItemEncountered;
	double deleteMenuID;
	double deleteItemNumber;
	int deleteMenuItemParamsSet[2];

	// Parameters for deleteMenuItemRange keyword group.
	int deleteMenuItemRangeEncountered;
	double deleteMenuItemRangeID;
	double deleteMenuItemRangeFirst;
	double deleteMenuItemRangeLast;
	int deleteMenuItemRangeParamsSet[3];

	// Parameters for fillMenu keyword group.
	int fillMenuEncountered;
	double fillMenuID;
	double fillMenuAfterItemNumber;
	Handle fillMenuItemList;
	int fillMenuParamsSet[3];

	// Parameters for fillMenuNoMeta keyword group.
	int fillMenuNoMetaEncountered;
	double fillNoMetaMenuID;
	double fillNoMetaAfterItemNumber;
	Handle fillNoMetaItemList;
	int fillMenuNoMetaParamsSet[3];

	// Parameters for getMenuItemText keyword group.
	int getMenuItemTextEncountered;
	double getTextMenuID;
	double getTextItemNumber;
	char itemText[MAX_OBJ_NAME+1];
	int getMenuItemTextParamsSet[3];

	// Parameters for setMenuItemText keyword group.
	int setMenuItemTextEncountered;
	double setTextMenuID;
	double setTextItemNumber;
	Handle setTextText;
	int setMenuItemTextParamsSet[3];

	// Parameters for enableMenuItem keyword group.
	int enableMenuItemEncountered;
	double enableMenuID;
	double enableItemNumber;
	int enableMenuItemParamsSet[2];

	// Parameters for disableMenuItem keyword group.
	int disableMenuItemEncountered;
	double disableMenuID;
	double disableItemNumber;
	int disableMenuItemParamsSet[2];

	// Parameters for checkMenuItem keyword group.
	int checkMenuItemEncountered;
	double checkMenuID;
	double checkMenuItemNumber;
	double checkMenuState;
	int checkMenuItemParamsSet[3];

	// Parameters for getMenuInfo keyword group.
	int getMenuInfoEncountered;
	double getMenuInfoID;
	char numMenuItems[MAX_OBJ_NAME+1];
	int getMenuInfoParamsSet[2];

	// Parameters for getMenuItemInfo keyword group.
	int getMenuItemInfoEncountered;
	double getMenuItemInfoID;
	double getMenuItemInfoNumber;
	char enabledVar[MAX_OBJ_NAME+1];
	char checkedVar[MAX_OBJ_NAME+1];
	int getMenuItemInfoParamsSet[4];

	// Parameters for quit keyword group.
	int quitEncountered;
	// There are no fields for this group because it has no parameters.

	// These are postamble fields that Igor sets.
	int calledFromFunction;					// 1 if called from a user function, 0 otherwise.
	int calledFromMacro;					// 1 if called from a macro, 0 otherwise.
};
typedef struct MenuXOP1RuntimeParams MenuXOP1RuntimeParams;
typedef struct MenuXOP1RuntimeParams* MenuXOP1RuntimeParamsPtr;
#pragma pack()	// Reset structure alignment to default.

/*	ExecuteMenuXOP1(p)
	
	Executes MenuXOP1 operation.
*/
extern "C" int
ExecuteMenuXOP1(MenuXOP1RuntimeParamsPtr p)
{
	XOPMenuRef menuRef;
	int resourceMenuID, actualMenuID, itemNumber, afterItemNumber, state;
	char itemText[256];
	char itemList[1024];
	int err = 0;
	
	if (p->showMenuEncountered) {				// This is allowed to act only on the main MenuXOP1 menu
		resourceMenuID = (int)p->showMenuID;
		if (resourceMenuID != MAINMENU_ID)
			return MAIN_MENU_ONLY;
		menuRef = XOPResourceMenuIDToMenuRef(resourceMenuID);
		if (menuRef != NULL)
			XOPShowMainMenu(gMainMenuRef, 0);
	}
	
	if (p->hideMenuEncountered) {				// This is allowed to act only on the main MenuXOP1 menu
		resourceMenuID = (int)p->hideMenuID;
		if (resourceMenuID != MAINMENU_ID)
			return MAIN_MENU_ONLY;
		menuRef = XOPResourceMenuIDToMenuRef(resourceMenuID);
		if (menuRef != NULL)
			XOPHideMainMenu(menuRef);
	}

	if (p->appendMenuItemEncountered) {			// This is allowed to act only on MenuXOP1 menus, not on Igor menus
		resourceMenuID = (int)p->appendMenuID;
		menuRef = XOPResourceMenuIDToMenuRef(resourceMenuID);
		if (menuRef == NULL)
			return EXPECTED_MENUXOP1_MENUID;	// Not a MenuXOP1-created menu
		if (err = GetCStringFromHandle(p->appendItemText, itemText, sizeof(itemText)-1))
			return err;
		if (err = XOPAppendMenuItem(menuRef, itemText))
			return err;
	}

	if (p->insertMenuItemEncountered) {			// This is allowed to act only on MenuXOP1 menus, not on Igor menus
		// We don't call GetMenuRefAndItem here because afterItemNumber can be 0 and GetMenuRefAndItem does not allow 0 as an item number
		resourceMenuID = (int)p->insertMenuID;
		menuRef = XOPResourceMenuIDToMenuRef(resourceMenuID);
		if (menuRef == NULL)
			return EXPECTED_MENUXOP1_MENUID;	// Not a MenuXOP1-created menu
		afterItemNumber = (int)p->insertAfterItemNumber;
		if (err = GetCStringFromHandle(p->insertItemText, itemText, sizeof(itemText)-1))
			return err;
		if (err = XOPInsertMenuItem(menuRef, afterItemNumber, itemText))
			return err;
	}

	if (p->deleteMenuItemEncountered) {	// This is allowed to act only on MenuXOP1 menus, not on Igor menus
		if (err = GetMenuRefAndItem((int)p->deleteMenuID, (int)p->deleteItemNumber, 0, &menuRef, &itemNumber))
			return err;
		if (menuRef == NULL)			// NULL if menuRef not available because menu is hidden
			return MENU_INACCESSIBLE;
		if (err = XOPDeleteMenuItem(menuRef, itemNumber))
			return err;
	}

	if (p->deleteMenuItemRangeEncountered) {	// This is allowed to act only on MenuXOP1 menus, not on Igor menus
		// We don't call GetMenuRefAndItem here because it does not support an item number range
		resourceMenuID = (int)p->deleteMenuItemRangeID;
		menuRef = XOPResourceMenuIDToMenuRef(resourceMenuID);
		if (menuRef == NULL)
			return EXPECTED_MENUXOP1_MENUID;	// Not a MenuXOP1-created menu
		int first = (int)p->deleteMenuItemRangeFirst;
		int last = (int)p->deleteMenuItemRangeLast;
		if (err = XOPDeleteMenuItemRange(menuRef, first, last))		// Clips first and last
			return err;
	}

	if (p->fillMenuEncountered) {				// This is allowed to act only on MenuXOP1 menus, not on Igor menus
		// We don't call GetMenuRefAndItem here because afterItemNumber can be 0 and GetMenuRefAndItem does not allow 0 as an item number
		resourceMenuID = (int)p->fillMenuID;
		menuRef = XOPResourceMenuIDToMenuRef(resourceMenuID);
		if (menuRef == NULL)
			return EXPECTED_MENUXOP1_MENUID;	// Not a MenuXOP1-created menu
		afterItemNumber = (int)p->fillMenuAfterItemNumber;
		if (err = GetCStringFromHandle(p->fillMenuItemList, itemList, sizeof(itemList)-1))
			return err;
		if (err = XOPFillMenu(menuRef, afterItemNumber, itemList))
			return err;
	}

	if (p->fillMenuNoMetaEncountered) {			// This is allowed to act only on MenuXOP1 menus, not on Igor menus
		// We don't call GetMenuRefAndItem here because afterItemNumber can be 0 and GetMenuRefAndItem does not allow 0 as an item number
		resourceMenuID = (int)p->fillNoMetaMenuID;
		menuRef = XOPResourceMenuIDToMenuRef(resourceMenuID);
		if (menuRef == NULL)
			return EXPECTED_MENUXOP1_MENUID;	// Not a MenuXOP1-created menu
		afterItemNumber = (int)p->fillNoMetaAfterItemNumber;
		if (err = GetCStringFromHandle(p->fillNoMetaItemList, itemList, sizeof(itemList)-1))
			return err;
		if (err = XOPFillMenuNoMeta(menuRef, afterItemNumber, itemList))
			return err;
	}

	if (p->getMenuItemTextEncountered) {		// This is allowed to act on MenuXOP1-created menu items whether in a MenuXOP1 menu or in an Igor menu
		if (err = GetMenuRefAndItem((int)p->getTextMenuID, (int)p->getTextItemNumber, 1, &menuRef, &itemNumber))
			return err;
		if (menuRef == NULL)			// NULL if menuRef not available because menu is hidden
			return MENU_INACCESSIBLE;
		if (err = XOPGetMenuItemText(menuRef, itemNumber, itemText))
			return err;
		if (err = StoreStringDataUsingVarName(p->itemText, itemText, strlen(itemText)))
			return err;
	}

	if (p->setMenuItemTextEncountered) {// This is allowed to act on MenuXOP1-created menu items whether in a MenuXOP1 menu or in an Igor menu
		if (err = GetMenuRefAndItem((int)p->setTextMenuID, (int)p->setTextItemNumber, 1, &menuRef, &itemNumber))
			return err;
		if (menuRef == NULL)			// NULL if menuRef not available because menu is hidden
			return MENU_INACCESSIBLE;
		if (err = GetCStringFromHandle(p->setTextText, itemText, sizeof(itemText)-1))
			return err;
		if (err = XOPSetMenuItemText(menuRef, itemNumber, itemText))
			return err;
	}

	if (p->enableMenuItemEncountered) {	// This is allowed to act on MenuXOP1-created menu items whether in a MenuXOP1 menu or in an Igor menu
		if (err = GetMenuRefAndItem((int)p->enableMenuID, (int)p->enableItemNumber, 1, &menuRef, &itemNumber))
			return err;
		if (menuRef == NULL)			// NULL if menuRef not available because menu is hidden
			return MENU_INACCESSIBLE;
		XOPEnableMenuItem(menuRef, itemNumber);
	}

	if (p->disableMenuItemEncountered) {// This is allowed to act on MenuXOP1-created menu items whether in a MenuXOP1 menu or in an Igor menu
		if (err = GetMenuRefAndItem((int)p->disableMenuID, (int)p->disableItemNumber, 1, &menuRef, &itemNumber))
			return err;
		if (menuRef == NULL)			// NULL if menuRef not available because menu is hidden
			return MENU_INACCESSIBLE;
		XOPDisableMenuItem(menuRef, itemNumber);
	}

	if (p->checkMenuItemEncountered) {	// This is allowed to act on MenuXOP1-created menu items whether in a MenuXOP1 menu or in an Igor menu
		if (err = GetMenuRefAndItem((int)p->checkMenuID, (int)p->checkMenuItemNumber, 1, &menuRef, &itemNumber))
			return err;
		if (menuRef == NULL)			// NULL if menuRef not available because menu is hidden
			return MENU_INACCESSIBLE;
		state = (int)p->checkMenuState;
		if (err = XOPCheckMenuItem(menuRef, itemNumber, state))
			return err;
	}

	if (p->getMenuInfoEncountered) {			// This is allowed to act only on MenuXOP1 menus, not on Igor menus
		resourceMenuID = (int)p->getMenuInfoID;
		menuRef = XOPResourceMenuIDToMenuRef(resourceMenuID);
		if (menuRef == NULL)
			return EXPECTED_MENUXOP1_MENUID;	// Not a MenuXOP1-created menu

		int numMenuItems = XOPCountMenuItems(menuRef);
		
		if (err = StoreNumericDataUsingVarName(p->numMenuItems, numMenuItems, 0))
			return err;
	}

	if (p->getMenuItemInfoEncountered) {		// This is allowed to act on MenuXOP1-created menu items whether in a MenuXOP1 menu or in an Igor menu
		if (err = GetMenuRefAndItem((int)p->getMenuItemInfoID, (int)p->getMenuItemInfoNumber, 1, &menuRef, &itemNumber))
			return err;
		if (menuRef == NULL)	// NULL if menuRef not available because Igor main menu is hidden
			return MENU_INACCESSIBLE;
		
		// XOPGetMenuItemInfo requires Igor Pro 6.32 or later and returns NOT_IMPLEMENTED for earlier versions
		int isEnabled, isChecked;
		if (err = XOPGetMenuItemInfo(menuRef, itemNumber, &isEnabled, &isChecked, NULL, NULL))
			return err;
		
		if (err = StoreNumericDataUsingVarName(p->enabledVar, isEnabled, 0))
			return err;
		if (err = StoreNumericDataUsingVarName(p->checkedVar, isChecked, 0))
			return err;
	}
	
	if (p->quitEncountered) {
		// If you unload MenuXOP1 while main menu is hidden it will not be retrievable if MenuXOP1 is reloaded.
		actualMenuID = ResourceToActualMenuID(MAINMENU_ID);
		if (XOPActualMenuIDToMenuRef(actualMenuID) == NULL)
			XOPShowMainMenu(gMainMenuRef, 0);
		SetXOPType(TRANSIENT);							// Tell Igor to unload XOP.
	}

	return err;
}

/*	RegisterMenuXOP1()
	
	Registers MenuXOP1 operation with Igor's Operation Handler.
*/
static int
RegisterMenuXOP1(void)
{
	const char* cmdTemplate;
	const char* runtimeNumVarList;
	const char* runtimeStrVarList;

	cmdTemplate = "MenuXOP1 showMenu=number:showMenuID, hideMenu=number:hideMenuID, appendMenuItem={number:appendMenuID,string:appendItemText}, insertMenuItem={number:insertMenuID,number:insertAfterItemNumber,string:insertItemText}, deleteMenuItem={number:deleteMenuID,number:deleteItemNumber}, deleteMenuItemRange={number:deleteMenuItemRangeID,number:deleteMenuItemRangeFirst,number:deleteMenuItemRangeLast}, fillMenu={number:fillMenuID,number:fillMenuAfterItemNumber,string:fillMenuItemList}, fillMenuNoMeta={number:fillNoMetaMenuID,number:fillNoMetaAfterItemNumber,string:fillNoMetaItemList}, getMenuItemText={number:getTextMenuID,number:getTextItemNumber,varName:itemText}, setMenuItemText={number:setTextMenuID,number:setTextItemNumber,string:setTextText}, enableMenuItem={number:enableMenuID,number:enableItemNumber}, disableMenuItem={number:disableMenuID,number:disableItemNumber}, checkMenuItem={number:checkMenuID,number:checkMenuItemNumber,number:checkMenuState}, getMenuInfo={number:getMenuInfoID,varName:numMenuItems}, getMenuItemInfo={number:getMenuItemInfoID,number:getMenuItemInfoNumber,varName:enabledVar,varName:checkedVar}, quit";
	runtimeNumVarList = "";
	runtimeStrVarList = "";
	
	/*	We pass NULL here instead of ExecuteMenuXOP1 because we want the operation to be called via
		the EXECUTE_OPERATION message, not directly. This is because we want to be able to unload
		the XOP from memory.
	*/
	return RegisterOperation(cmdTemplate, runtimeNumVarList, runtimeStrVarList, sizeof(MenuXOP1RuntimeParams), NULL, 0);
}

/*	XOPMenuItem()

	XOPMenuItem is called when user selects XOPs menu item.
*/
static int
XOPMenuItem(void)
{
	XOPMenuRef menuRef;
	int resourceMenuID, actualMenuID;
	int resourceItemNumber, actuaItemNumber;
	int isIgorMenu, isXOPMenu;
	char itemText[256];
	char message[400];
	char prefix[64];
	int err;
	
	isIgorMenu = isXOPMenu = 0;
	
	actualMenuID = (int)GetXOPItem(0);
	actuaItemNumber = (int)GetXOPItem(1);
	
	menuRef = XOPActualMenuIDToMenuRef(actualMenuID);			// This would be NULL if the menu were hidden.
	
	int selector = 0;											// Controls the switch statement below
	resourceMenuID = ActualToResourceMenuID(actualMenuID);		// Convert to resource menu ID.
	if (resourceMenuID != 0) {									// Menu added by XOP ?
		selector = resourceMenuID;
		isXOPMenu = 1;
	}
	else {														// This is an Igor menu.
		selector = actualMenuID;
		isIgorMenu = 1;
	}
	
	char menuTitle[256];
	int tmpActualMenuID;
	int inMenuBar;
	err = XOPGetMenuInfo(menuRef, &tmpActualMenuID, menuTitle, &inMenuBar, NULL, NULL);
	if (igorVersion < 632) {
		strcpy(menuTitle, "Unknown");		// menuTitle and inMenuBar require IP 6.32 or later
		inMenuBar = -1;
	}
	if (err != 0)
		strcpy(menuTitle, "ERROR");
	
	// resourceItemNumber will be 0 if item was added by MenuXOP1 to Igor menu, non-zero if item is in MenuXOP1 menu
	resourceItemNumber = ActualToResourceItem(actualMenuID, actuaItemNumber);
	
	if (menuRef == NULL) {
		strcpy(itemText, "Unknown");
	}
	else {
		err = XOPGetMenuItemText(menuRef, actuaItemNumber, itemText);
		if (err != 0)
			sprintf(itemText, "Error %d", err);
	}
	
	switch (selector) {
		case MAINMENU_ID:				// MenuXOP1 menu in main menu bar.
			strcpy(prefix, "Main MenuXOP1 menu: ");
			break;
			
		case SUBMENU1_ID:				// Submenu in item 1 of main menu bar.
			strcpy(prefix, "MenuXOP1 submenu: ");
			break;
			
		case SUBMENU2_ID:				// Submenu in item 3 of main menu bar.
			strcpy(prefix, "MenuXOP1 submenu: ");
			break;
			
		case SUBMENU3_ID:				// Sub-submenu in item 2 of 2nd submenu.
			strcpy(prefix, "MenuXOP1 submenu: ");
			break;
			
		case SUBMENU4_ID:				// Submenu in item added to Analysis menu.
			strcpy(prefix, "Analysis submenu: ");
			break;
			
		case MISCID:					// MISCID = 8 (see IgorXOP.h).
			strcpy(prefix, "Misc menu: ");
			break;
			
		default:
			/*	This should not happen because Igor will not call us if the selected
				menu item is not a MenuXOP1 item.
			*/
			sprintf(prefix, "Igor menu ID=%d: ", selector);
			break;
	}
	
	sprintf(message, "%s%s" CR_STR, prefix, itemText);	// e.g., "Main MenuXOP1 menu: Item2"
	XOPNotice(message);
	
	if (isIgorMenu) {
		sprintf(message, "menuRef=%p, menuTitle=\"%s\", inMenuBar=%d, actualMenuID=%d, resourceItemNumber=%d, actuaItemNumber=%d" CR_STR,
					  menuRef, menuTitle, inMenuBar, actualMenuID, resourceItemNumber, actuaItemNumber);
		XOPNotice(message);
	}
	if (isXOPMenu) {
		sprintf(message, "menuRef=%p, menuTitle=\"%s\", inMenuBar=%d, resourceMenuID=%d, actualMenuID=%d, actuaItemNumber=%d" CR_STR,
					  menuRef, menuTitle, inMenuBar, resourceMenuID, actualMenuID, actuaItemNumber);
		XOPNotice(message);
	}
	
	return 0;
}

/*	XOPMenuEnable()

	Sets XOPs menu items according to current conditions.
*/
static void
XOPMenuEnable(void)
{
}

/*	XOPEntry()

	This is the entry point from the host application to the XOP when the message specified by the
	host is other than INIT.
*/
extern "C" void
XOPEntry(void)
{	
	XOPIORecResult result = 0;
	
	switch (GetXOPMessage()) {
		case MENUITEM:								// XOPs menu item selected.
			XOPMenuItem();
			break;

		case MENUENABLE:							// Enable/disable XOPs menu item.
			XOPMenuEnable();
			break;
			
		case EXECUTE_OPERATION:
			{
				void* params;
				params = (void*)GetXOPItem(1);
				result = ExecuteMenuXOP1((MenuXOP1RuntimeParams*)params);
			}
			break;
	}
	
	SetXOPResult(result);
}

/*	XOPMain(ioRecHandle)

	This is the initial entry point at which the host application calls XOP.
	The message sent by the host must be INIT.

	main does any necessary initialization and then sets the XOPEntry field of the
	ioRecHandle to the address to be called for future messages.
*/
HOST_IMPORT int
XOPMain(IORecHandle ioRecHandle)				// The use of XOPMain rather than main means this XOP requires Igor Pro 6.20 or later
{
	int err;
	
	XOPInit(ioRecHandle);						// Do standard XOP initialization.
	if (igorVersion < 800) {					// XOP Toolkit 8.00 or later requires Igor Pro 8.00 or later
		SetXOPResult(OLD_IGOR);
		return EXIT_FAILURE;
	}
	
	if (err = RegisterMenuXOP1()) {
		SetXOPResult(err);
		return EXIT_FAILURE;
	}
	
	SetXOPEntry(XOPEntry);						// Set entry point for future calls.
	SetXOPType(RESIDENT);						// Specify XOP to stick around and to Idle.
	
	int actualMenuID = ResourceToActualMenuID(MAINMENU_ID);
	gMainMenuRef = XOPActualMenuIDToMenuRef(actualMenuID);
	if (gMainMenuRef == NULL) {
		SetXOPResult(GENERAL_BAD_VIBS);
		return EXIT_FAILURE;
	}
	
	SetXOPResult(0L);
	return EXIT_SUCCESS;
}
