
// GBLoadWaveX custom error codes
#define IMPROPER_FILE_TYPE 1 + FIRST_XOP_ERR		// not the type of file this XOP loads
#define NO_DATA_FOUND 2 + FIRST_XOP_ERR				// file being loaded contains no data
#define EXPECTED_GB_FILE 3 + FIRST_XOP_ERR			// expected name of loadable file
#define EXPECTED_BASENAME 4 + FIRST_XOP_ERR			// expected base name for new waves
#define EXPECTED_FILETYPE 5 + FIRST_XOP_ERR			// expected file type
#define TOO_MANY_FILETYPES 6 + FIRST_XOP_ERR		// too many file types
#define BAD_DATA_LENGTH 7 + FIRST_XOP_ERR			// data length in bits must be 8, 16, 32 or 64
#define BAD_NUM_ARRAYS 8 + FIRST_XOP_ERR			// Number of arrays must be an integer >= 1
#define BAD_NUM_POINTS_IN_ARRAY 9 + FIRST_XOP_ERR	// The number of points per array must be a positive integer or 'auto'
#define NOT_ENOUGH_BYTES 10 + FIRST_XOP_ERR			// file contains too few bytes for specified ...
#define BAD_DATA_TYPE 11 + FIRST_XOP_ERR			// bad data type value
#define OLD_IGOR 12 + FIRST_XOP_ERR					// Requires Igor Pro 8.00 or later
#define BAD_FP_FORMAT_CODE 13 + FIRST_XOP_ERR		// Valid floating point formats are 1 (IEEE) and 2 (VAX).
#define ARRAY_TOO_BIG_FOR_IGOR 14 + FIRST_XOP_ERR	// The array is too big for an Igor wave.
#define LAST_GBLOADWAVE_ERR ARRAY_TOO_BIG_FOR_IGOR

#define ERR_ALERT 1258

// #defines for GBLoadWaveX flags

#define OVERWRITE 1						// /O means overwrite
#define DOUBLE_PRECISION 2				// /D means double precision
#define INTERACTIVE 4					// /I means interactive -- use open dialog
#define AUTO_NAME 8						// /A or /N means autoname wave
#define PATH 16							// /P means use symbolic path
#define QUIET 32						// /Q means quiet -- no messages in history
#define FROM_MENU 64					// LoadWave summoned from menu item
#define COMPLEX 128						// data is complex

// structure used in reading file
struct ColumnInfo {
	char waveName[MAX_OBJ_NAME+1];		// Name of wave for this column.
	waveHndl waveHandle;				// Handle to this wave.
	int wavePreExisted;					// True if wave existed before this command ran.
	CountInt points;					// Total number of points in wave.
	void *dataPtr;						// To save pointer to start of wave data.
};
typedef struct ColumnInfo ColumnInfo;
typedef struct ColumnInfo *ColumnInfoPtr;
typedef struct ColumnInfo **ColumnInfoHandle;

// This structure is used in memory only - not saved to disk.
struct LoadSettings {
	int flags;						// Flag bits are defined in GBLoadWaveX.h.
	int lowByteFirst;				// 0 = high byte first (Motorola); 1 = low byte first (Intel). Set by /B flag.
	int inputDataType;				// Igor number type (e.g., NT_FP64, NT_I32 - see IgorXOPs.h). Set by /T flag or /L flag or /F flag.
	int inputBytesPerPoint;			// 1, 2, 4 or 8. Set by /T flag or /L flag.
	int inputDataFormat;			// SIGNED_INT, UNSIGNED_INT, IEEE_FLOAT. Set by /T flag or /F flag.
	int outputDataType;				// Igor number type (e.g., NT_FP64, NT_I32 - see IgorXOPs.h). Set by /T flag or /D flag.
	int outputBytesPerPoint;		// Set by /T flag or /D flag.
	int outputDataFormat;			// SIGNED_INT, UNSIGNED_INT, IEEE_FLOAT. Set by /T flag or /D flag.
	CountInt preambleBytes;			// Bytes to skip at start of file. Set by /S flag.
	int numArrays;					// Number of waves in file 0 for auto. Set by /W flag.
	CountInt arrayPoints;			// Number of points in each array in file or 0 for auto. Set by /U flag.
	char fileFilterStr[256];		// Set by /FILT flag.
	int interleaved;				// Truth that arrays in file are interleaved. Set by /V flag.
	int floatingPointFormat;		// 1 = IEEE; 2 = VAX. Set by /J flag.
	double offset;					// Output data = (input data + offset) * multiplier.
	double multiplier;				// Set by /Y flag.
};
typedef struct LoadSettings LoadSettings;
typedef struct LoadSettings *LoadSettingsPtr;

// Needed for DialogPositionAndSize structure
#include "../Extra/DialogUtilities.h"

// These settings are used in memory and are stored in preferences
const double kGBLoadWaveXDialogSettingsVersion = 1.00;
#pragma pack(2)	// All structures stored on disk are two-byte aligned
struct GBLoadWaveSettings {
	double version;					// Version of this structure
	
	DialogPositionAndSize dialogPosition;
	
	int interactive;				// /I flag: Display Open File dialog unconditionally
	int quiet;						// /Q flag: Don't print to history

	// Input
	int inputDataType;				// /T flag: NT_FP64, NT_FP32, NT_I64, ... see IgorXOPs.h
	SInt64 bytesToSkip;				// /S flag: Bytes to skip at start of file
	int numberOfArraysInFile;		// /W flag: Number of arrays in file
	SInt64 numberOfPointsInArray;	// /U flag: Number of points in each array
	int byteOrder;					// /B flag: 0=high byte first, 1=low byte first
	int floatingPointFormat;		// /J flag: 1=IEEE, 2=VAX
	int interleaved;				// /V flag: Truth that arrays in file are interleaved
	char symbolicPathName[256];		// /P flag: Name of symbolic path or ""
	char fullMacPath[MAX_PATH_LEN+1];

	// Output
	int outputDataType;				// /T flag second parameter: NT_FP64, NT_FP32, NT_I64, ... see IgorXOPs.h
	char baseName[256];				// /A or /N flag: Base name for output waves
	int overwrite;					// /O flag: Overwrite output waves if they exist
	int applyScaling;				// /Y flag - Output data = (input data + offset) * multiplier
	double scalingOffset;			// /Y flag first parameter
	double scalingMultiplier;		// /Y flag second parameter
	
	char reserved[512];
};
typedef struct GBLoadWaveSettings GBLoadWaveSettings;
typedef struct GBLoadWaveSettings *GBLoadWaveSettingsPtr;
typedef struct GBLoadWaveSettings **GBLoadWaveSettingsHandle;
#pragma pack()	// Restore default structure packing

// Miscellaneous #defines

#define MAX_IGOR_UNITS 4				// max chars allowed in Igor unit string
#define MAX_USER_LABEL 3
#define MAX_WAVEFORM_TITLE 18

// Prototypes

// In GBLoadWaveX.c
HOST_IMPORT int XOPMain(IORecHandle ioRecHandle);
int LoadWave(LoadSettings* lsp, const char* baseName, const char* symbolicPathName, const char* fileParam, int runningInUserFunction);

// In GBLoadWaveXOperation.c
int RegisterGBLoadWaveX(void);

// In GBLoadWaveDialogController.mm on Macintosh, GBLoadWaveDialogWin.cpp on Windows
int GBLoadWaveDialog(void);

