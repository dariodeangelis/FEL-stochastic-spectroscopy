#import "GBLoadWaveDialogController.h"

/*	Cocoa Dialog Notes

	The GBLoadWave dialog is defined in a nib file as is the practice in Cocoa.

	The GBLoadWave dialog is invoked from C++ by calling the GBLoadWaveDialog routine.
	GBLoadWaveDialog creates a GBLoadWaveDialogLoader Objective-C object.
	The GBLoadWaveDialogLoader loads the nib. The act of loading the nib creates
	the GBLoadWaveDialogController. The GBLoadWaveDialogController runs the dialog.
	
	We need the GBLoadWaveDialogLoader because we need an Objective-C object to load
	the nib. The GBLoadWaveDialogController cannot load the nib because it is created
	by loading the nib. The GBLoadWaveDialogController *must* be created by loading the
	nib because this is what sets the GBLoadWaveDialogController outlets to point to
	the dialog window and to the various controls in the dialog. The GBLoadWaveDialogController
	object uses these pointers to get and set dialog settings.
	
	We use the old-fashioned Objective-C retain/release memory management because the
	newer ARC (automatic reference counting) technique is not supported in 32 bits.
	If you do not plan to support 32 bits in your XOP, you can switch to ARC. See
	Apple's "Transitioning to ARC" document. If you do this, you can get rid of the 
	instance variables (e.g., _dialogWindow), defined in GBLoadWaveDialogController.h,
	since these are needed for 32 bits only.

	The GBLoadWaveDialogController object is wired as the dialog window's delegate in the nib.
	This means that the window object will send messages to the GBLoadWaveDialogController object
	giving it the opportunity to customize the behavior of the window, if the GBLoadWaveDialogController
	object implements the appropriate methods. windowShouldClose is an example of an implemented
	delegate method.
	
	The GBLoadWaveDialogController object is wired as each NSTextView control's delegate in the nib.
	controlDidChange is an example of an implemented delegate method. This is what allows us
	to update the GBLoadWaveX command each time the user types in an NSTextView control.
	This is needed because NSTextViews normally do not send action messages until the user
	presses return but we need to know about changes each time the user changes the text
	so that we can update the dialog's command box.

	Setting the tab order is surprisingly difficult. See
		http://www.cocoabuilder.com/archive/cocoa/298020-how-to-set-tab-order-in-window-that-has-view-swapping.html
	Because of this I am punting and allowing Cocoa to set the tab order, even though
	it is not optimal.
	
	The help button does not work. We hide it in initializeDialog. This is because of
	an incompatibility between Qt and Cocoa. When the user clicks the Help button,
	the helpButtonClicked method calls XOPDisplayHelpTopic which calls back to Igor.
	Igor uses Qt to display a modal help dialog. When the user clicks Done in the modal
	help dialog, it is dismissed. At this point, the XOP Cocoa dialog, which should remain
	on the screen, is also dismissed. This issue has something to do with Qt's handling of
	modal dialogs. There is no apparent solution for this incompatibility. Because of this,
	if you want to support a help button on Macintosh, you will need to implement your own
	help window. Calling a Cocoa subdialog, such as calling XOPOKAlert, does not cause a problem.
*/

@interface GBLoadWaveDialogController ()

@end

@implementation GBLoadWaveDialogController

@synthesize dialogWindow = _dialogWindow;
@synthesize inputDataTypePopup = _inputDataTypePopup;
@synthesize bytesToSkipTextField = _bytesToSkipTextField;
@synthesize numberOfArraysInFileTextField = _numberOfArraysInFileTextField;
@synthesize numberOfPointsInArrayTextField = _numberOfPointsInArrayTextField;
@synthesize byteOrderPopup = _byteOrderPopup;
@synthesize interleavedCheckbox = _interleavedCheckbox;
@synthesize pathPopup = _pathPopup;
@synthesize fileButton = _fileButton;
@synthesize fileNameTextField = _fileNameTextField;
@synthesize outputDataTypePopup = _outputDataTypePopup;
@synthesize baseNameTextField = _baseNameTextField;
@synthesize overwriteCheckbox = _overwriteCheckbox;
@synthesize scalingCheckbox = _scalingCheckbox;
@synthesize scalingOffsetTextField = _scalingOffsetTextField;
@synthesize scalingMultiplierTextField = _scalingMultiplierTextField;
@synthesize okButton = _okButton;
@synthesize toCmdButton = _toCmdButton;
@synthesize toClipButton = _toClipButton;
@synthesize cancelButton = _cancelButton;
@synthesize helpButton = _helpButton;
@synthesize cmdTextView = _cmdTextView;

- (void)windowDidLoad {
    [super windowDidLoad];
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
}

- (BOOL)windowShouldClose:(id)sender {						// From NSWindowDelegate protocol
	/*	This is called when the user clicks the close box but not when the user
		clicks the OK or Cancel button. If we return YES here the dialog is hidden
		but not deallocated. Furthermore, it does not terminate the modal loop.
		Therefore we can not allow the user to close the dialog this way. He must
		click OK or Cancel. This will not actually be called because we have disabled
		the close control using the window's attributes in the nib. This routine
		would be needed only if the close control were enabled.
	*/
	// NSLog(@"windowShouldClose");
	return NO;						// Prevents close box from killing window
}

- (void)windowWillClose:(NSNotification*)notification {		// From NSWindowDelegate protocol
	/*	This is called when the user clicks the close box but not when the user
		clicks the OK or Cancel button.
	*/
	// NSLog(@"windowWillClose");
}

- (void)controlTextDidChange:(NSNotification*)notification		// Called by NSTextView controls
{
	// NSLog(@"controlTextDidChange");
	[ self updateDialog ];
}

- (IBAction)inputDataTypeSelected:(id)sender {
	[ self updateDialog ];
}

- (IBAction)byteOrderSelected:(id)sender {
	[ self updateDialog ];
}

- (IBAction)interleavedCheckboxClicked:(id)sender {
	[ self updateDialog ];
}

- (IBAction)pathSelected:(id)sender {
	NSString* pathNameStr = [ self.pathPopup titleOfSelectedItem ];	// Auto-released
	strcpy(self->symbolicPathName, [ pathNameStr UTF8String ]);
	if (CmpStr(self->symbolicPathName, "_none_") == 0) {
		*self->symbolicPathName = 0;
		self->pointOpenFileDialog = false;
	}
	else {
		self->pointOpenFileDialog = true;
	}
	[ self updateDialog ];
}

- (IBAction)fileButtonClicked:(id)sender {
	int flagsIn = 0;
	const char* fileFilterStr = "All Files:.*;";
	static int fileFilterIndex = 1;
	char initialDir[MAX_PATH_LEN+1];
	char initialFile[MAX_FILENAME_LEN+1];
	
	*initialFile = 0;
	*initialDir = 0;

	// If the user just selected a symbolic path, show the corresponding folder in the Open File dialog.
	if (self->pointOpenFileDialog) {
		GetPathInfo2(self->symbolicPathName, initialDir);	// Returns native path which is what XOPOpenFileDialog requires
		self->pointOpenFileDialog = false;
	}

	int err;
	char fullPath[MAX_PATH_LEN+1];
	if (err = XOPOpenFileDialog2(flagsIn, "Choose a general binary file", fileFilterStr, &fileFilterIndex, initialDir, initialFile, NULL, fullPath))
		return;
	// fullPath is an HFS path
	
	strcpy(self->fullMacPath, fullPath);
	
	[ self updateDialog ];
}

- (IBAction)outputDataTypeSelected:(id)sender {
	[ self updateDialog ];
}

- (IBAction)overwriteCheckboxClicked:(id)sender {
	[ self updateDialog ];
}

- (IBAction)scalingCheckboxClicked:(id)sender {
	[ self updateDialog ];
}

- (IBAction)doItButtonClicked:(id)sender {
	NSString* cmdStr = [ self generateCommand ];			// Auto-released
	char cmd[MAXCMDLEN+1];
	strcpy(cmd, [ cmdStr UTF8String ]);
	FinishDialogCmd(cmd, 1);
    [NSApp stopModal];
}

- (IBAction)toCmdLineButtonClicked:(id)sender {
	NSString* cmdStr = [ self generateCommand ];			// Auto-released
	char cmd[MAXCMDLEN+1];
	strcpy(cmd, [ cmdStr UTF8String ]);
	FinishDialogCmd(cmd, 2);
    [NSApp stopModal];
}

- (IBAction)toClipButtonClicked:(id)sender {
	NSString* cmdStr = [ self generateCommand ];			// Auto-released
	char cmd[MAXCMDLEN+1];
	strcpy(cmd, [ cmdStr UTF8String ]);
	FinishDialogCmd(cmd, 3);
    [NSApp stopModal];
}

- (IBAction)helpButtonClicked:(id)sender {
	// This will not be called. See the discussion of the Help button at the top of the file.
	XOPDisplayHelpTopic("GBLoadWaveX Help", "GBLoadWaveX XOP", 1);
}

- (IBAction)cancelButtonClicked:(id)sender {
	// NSLog(@"Cancel button clicked");
	self->dialogResult = -1;
    [NSApp stopModal];
}

static int
MenuItemToDataType(int zeroBasedMenuItemNumber)
{
	int dataType = 0;
	
	switch(zeroBasedMenuItemNumber) {
		case 0:
			dataType = NT_FP64;
			break;
		case 1:
			dataType = NT_FP32;
			break;
		case 2:
			dataType = NT_I64;
			break;
		case 3:
			dataType = NT_I32;
			break;
		case 4:
			dataType = NT_I16;
			break;
		case 5:
			dataType = NT_I8;
			break;
		case 6:
			dataType = NT_I64 | NT_UNSIGNED;
			break;
		case 7:
			dataType = NT_I32 | NT_UNSIGNED;
			break;
		case 8:
			dataType = NT_I16 | NT_UNSIGNED;
			break;
		case 9:
			dataType = NT_I8 | NT_UNSIGNED;
			break;
	}

	return dataType;
}

static int
DataTypeToMenuItemIndex(int dataType)
{
	int zeroBasedMenuItemIndex = 0;
	
	switch(dataType) {
		case NT_FP64:
			zeroBasedMenuItemIndex = 0;
			break;
		case NT_FP32:
			zeroBasedMenuItemIndex = 1;
			break;
		case NT_I64:
			zeroBasedMenuItemIndex = 2;
			break;
		case NT_I32:
			zeroBasedMenuItemIndex = 3;
			break;
		case NT_I16:
			zeroBasedMenuItemIndex = 4;
			break;
		case NT_I8:
			zeroBasedMenuItemIndex = 5;
			break;
		case NT_I64 | NT_UNSIGNED:
			zeroBasedMenuItemIndex = 6;
			break;
		case NT_I32 | NT_UNSIGNED:
			zeroBasedMenuItemIndex = 7;
			break;
		case NT_I16 | NT_UNSIGNED:
			zeroBasedMenuItemIndex = 8;
			break;
		case NT_I8 | NT_UNSIGNED:
			zeroBasedMenuItemIndex = 9;
			break;
	}

	return zeroBasedMenuItemIndex;
}

/*	GetNextListItem(pp, pEnd, output, bufferSize)

	Returns the next item in the semicolon-separated list via output.
	
	*pp points to the beginning of the next items.
	pEnd points one byte past the end of the entire list.
	The list is assumed to be semicolon-separated, including the last item.
	
	The item is returned via output, null-terminated, without the semicolon.
	
	If we hit the end of the input or if there is an error, such as the item
	will not fit in the output buffer, the function result is non-zero.
	
	If you receive an empty string via output, there are no more list items
	and you must terminate the loop calling this function.
	
	If you receive a non-zero result, you must terminate the loop calling this function.
	
	pp is advanced to point to the start of the next item in the list.
*/
static int
GetNextListItem(const char** pp, const char* pEnd, char* output, int bufferSize)
{
	int result = 0;
	
	char* pOut = output;
	const char* p = *pp;
	int bytesWritten = 0;
	
	while(1) {
		if (p >= pEnd) {
			result = GENERAL_BAD_VIBS;				// Went beyond end of input list
			break;
		}
		if (*p == ';') {
			*pp = p + 1;
			break;
		}
		if (bytesWritten >= (bufferSize-1)) {
			result = STR_TOO_LONG;
			break;
		}
		*pOut++ = *p++;
		bytesWritten += 1;
	}
	
	*pOut = 0;
	
	return result;
}

- (void)initializeDialog
{
	// The Help button does not work. See the discussion of the Help button at the top of the file.
	[ self.helpButton setHidden:YES ];
	
	NSFont* font = [ NSFont fontWithName:@"Monaco" size:12 ];
	if (font != nil)
		[ self.cmdTextView setFont:font ];

	Handle listHandle = WMNewHandle(0L);
	if (listHandle != NULL) {
		int err = PathList(listHandle, "*", ";", "");
		if (err == 0) {
			const char* p = *listHandle;
			int len = (int)WMGetHandleSize(listHandle);
			const char* pEnd = p + len;					// Points one byte past last byte in handle
			while(1) {
				char pathName[MAX_OBJ_NAME+1];
				if (GetNextListItem(&p, pEnd, pathName, sizeof(pathName)) != 0)
					break;								// Error
				if (*pathName == 0)
					break;								// No more items
				NSString* itemText = [ NSString stringWithUTF8String:pathName ];	// Auto-released
				[ [self pathPopup] addItemWithTitle:itemText ];
			}
			WMDisposeHandle(listHandle);
		}
	}
	
	*fullMacPath = 0;
	
	[ self updateDialog ];
}

- (void)storeDialogSettingsInPrefs
{
	GBLoadWaveSettings s;
	[ self gatherSettings:&s ];
	
	BCInt numBytes = sizeof(s);
	Handle h = WMNewHandle(numBytes);
	if (h == NULL)
		return;
	memcpy(*h, &s, numBytes);
	int err = SaveXOPPrefsHandle(h);
	if (err != 0)
		XOPNotice("GBLoadWaveX error in storeDialogSettingsInPrefs" CR_STR);
	WMDisposeHandle(h);
}

- (void)restoreDialogSettingsFromPrefs
{
	Handle h;
	int err = GetXOPPrefsHandle((Handle*)&h);
	if (h == NULL)
		return;						// There are no stored dialog preferences
	if (err != 0)
		XOPNotice("GBLoadWaveX error in restoreDialogSettingsFromPrefs" CR_STR);
	
	BCInt len = WMGetHandleSize(h);
	if (len != sizeof(GBLoadWaveSettings)) {
		WMDisposeHandle(h);
		return;
	}
	
	GBLoadWaveSettings s;
	memcpy(&s, *h, len);
	WMDisposeHandle(h);
	if (s.version != kGBLoadWaveXDialogSettingsVersion)
		return;
	
	RestoreDialogPositionAndSize(self.dialogWindow, &s.dialogPosition);
	
	int menuItemIndex = DataTypeToMenuItemIndex(s.inputDataType);
	[ self.inputDataTypePopup selectItemAtIndex:menuItemIndex ];
	
	NSString* str = [ NSString stringWithFormat: @"%lld", s.bytesToSkip];				// Auto-released
	[ self.bytesToSkipTextField setStringValue:str ];
	
	/*	We can't use NSTextField setIntValue because it localizes the text and therefore
		uses dot or comma as the decimal separator, depending on the user's preferences.
		Igor dialogs alway requires dot as the decimal separator.
	*/
	str = [ NSString stringWithFormat: @"%d", (int)s.numberOfArraysInFile];				// Auto-released
	[ self.numberOfArraysInFileTextField setStringValue:str ];
	
	if (s.numberOfPointsInArray <= 0)
		str = @"auto";																	// Auto-released
	else
		str = [ NSString stringWithFormat: @"%lld", (SInt64)s.numberOfPointsInArray];	// Auto-released
	[ self.numberOfPointsInArrayTextField setStringValue:str ];
	
	[ self.byteOrderPopup selectItemAtIndex:s.byteOrder ];
	
	[ self.interleavedCheckbox setIntValue:s.interleaved ];
	
	char symbolicPathDirPath[MAX_PATH_LEN+1];
	if (GetPathInfo2(s.symbolicPathName, symbolicPathDirPath) == 0) {	// Valid symbolic path name?
		NSString* pathNameStr = [ NSString stringWithUTF8String:s.symbolicPathName ];	// Auto-released
		[ self.pathPopup selectItemWithTitle:pathNameStr];
	}
	else {
		[ self.pathPopup selectItemAtIndex:0 ];							// Select _none_
	}
	
	menuItemIndex = DataTypeToMenuItemIndex(s.outputDataType);
	[ self.outputDataTypePopup selectItemAtIndex:menuItemIndex ];
	
	NSString* baseNameStr = [ NSString stringWithUTF8String:s.baseName ];	// Auto-released
	[ self.baseNameTextField setStringValue:baseNameStr ];
	
	[ self.overwriteCheckbox setIntValue:s.overwrite ];
	
	/*	We can't use NSTextField setDoubleValue because it localizes the text and therefore
		uses dot or comma as the decimal separator, depending on the user's preferences.
		Igor dialogs alway requires dot as the decimal separator.
	*/
	NSString* scalingOffsetStr = [ NSString stringWithFormat: @"%.15g", s.scalingOffset ];			// Auto-released
	NSString* scalingMultiplierStr = [ NSString stringWithFormat: @"%.15g", s.scalingMultiplier ];	// Auto-released
	[ self.scalingCheckbox setIntValue:s.applyScaling ];
	[ self.scalingOffsetTextField setStringValue:scalingOffsetStr ];
	[ self.scalingMultiplierTextField setStringValue:scalingMultiplierStr ];
}

- (void)gatherSettings:(GBLoadWaveSettingsPtr)p {
	MemClear(p, sizeof(GBLoadWaveSettings));
	
	p->version = kGBLoadWaveXDialogSettingsVersion;
	
	GetDialogPositionAndSize(self.dialogWindow, &p->dialogPosition);
	
	// General
	p->interactive = 0;				// Currently not represented in dialog
	p->quiet = 0;					// Currently not represented in dialog
	
	// Input
	p->inputDataType = MenuItemToDataType((int)[ self.inputDataTypePopup indexOfSelectedItem ]);
	p->bytesToSkip = (SInt64)[ self.bytesToSkipTextField doubleValue ];
	p->numberOfArraysInFile = [ self.numberOfArraysInFileTextField intValue ];
	NSString* numberOfPointsInArrayStr = [ self.numberOfPointsInArrayTextField stringValue ];
	if ( [ numberOfPointsInArrayStr localizedCaseInsensitiveCompare:@"auto"] == NSOrderedSame )
		p->numberOfPointsInArray = 0;
	else
		p->numberOfPointsInArray = (SInt64)[ self.numberOfPointsInArrayTextField doubleValue ];
	p->byteOrder = (int)[ self.byteOrderPopup indexOfSelectedItem ];
	p->floatingPointFormat = 1;		// 1=IEEE, 2=VAX. This rare setting is not available in Macintosh dialog.
	p->interleaved = [ self.interleavedCheckbox intValue ];
	strcpy(p->symbolicPathName, self->symbolicPathName);
	strcpy(p->fullMacPath, self->fullMacPath);
	
	// Output
	p->outputDataType = MenuItemToDataType((int)[ self.outputDataTypePopup indexOfSelectedItem ]);
	NSString* baseNameStr = [ self.baseNameTextField stringValue ];
	strcpy(p->baseName, [ baseNameStr UTF8String ]);
	p->overwrite = [ self.overwriteCheckbox intValue ];
	
	// Scaling
	p->applyScaling = [ self.scalingCheckbox intValue ];
	p->scalingOffset = [ self.scalingOffsetTextField doubleValue ];
	p->scalingMultiplier = [ self.scalingMultiplierTextField doubleValue ];
}

/*	SymbolicPathPointsToFolder(symbolicPathName, macDirPath)

	symbolicPathName is the name of an Igor symbolic path.

	macDirPath is a full path to a folder. This is an HFS path with trailing colon.
	
	Returns true if the symbolic path refers to the folder specified by macDirPath.
*/
static bool
SymbolicPathPointsToFolder(const char* symbolicPathName, const char* macDirPath)
{
	char symbolicPathDirPath[MAX_PATH_LEN+1];
	if (GetPathInfo2(symbolicPathName, symbolicPathDirPath))	// Returns native path
		return 0;		// Error getting path info.
	
	char nativeDirPath[MAX_PATH_LEN+1];
	if (GetNativePath(macDirPath, nativeDirPath) != 0)
		return 0;		// Should not happen
	
	if (CmpStr(nativeDirPath, symbolicPathDirPath) == 0)
		return true;
	return false;
}

static bool
TextFieldContainsValidInteger(NSTextField* textField)
{
	NSString* str = [ textField stringValue ];
	const char* p = [ str UTF8String ];
	double dValue;
	char junk[100];
	if (sscanf(p, "%lg%9s", &dValue, junk) != 1)
		return false;								// Empty text or text following number
	if ((SInt64)dValue != dValue)
		return false;								// Not an integer
	return true;
}

static bool
TextFieldContainsValidDouble(NSTextField* textField)
{
	NSString* str = [ textField stringValue ];
	const char* p = [ str UTF8String ];
	double dValue;
	char junk[100];
	if (sscanf(p, "%lg%9s", &dValue, junk) != 1)
		return false;								// Empty text or text following number
	if (dValue != dValue)
		return false;								// Catches NaN
	return true;
}

static int
CheckBaseNameTextField(NSTextField* textField)
{
	NSString* str = [ textField stringValue ];
	const char* p = [ str UTF8String ];
	
	if (*p == 0)
		return 0;		// Empty defaults to "wave"

	if (strlen(p) > (MAX_OBJ_NAME-10))
		return NAME_TOO_LONG;

	char cleanedUpBaseName[MAX_OBJ_NAME+1];
	strcpy(cleanedUpBaseName, p);
	int err = CleanupName(0, cleanedUpBaseName, MAX_OBJ_NAME-10);	// Require standard, not liberal name
	if (err != 0)
		return err;
	
	if (CmpStr(cleanedUpBaseName,p) != 0)
		return BAD_CHAR_IN_NAME;			// CleanupName had to do some cleanup
	
	return 0;
}

static int
CheckBytesToSkipTextField(NSTextField* textField)
{
	if (!TextFieldContainsValidInteger(textField))	// This catches empty or garbage text
		return EXPECTED_NONNEGATIVE_INTEGER;

	double dValue = [ textField doubleValue ];
	if (dValue < 0.0)
		return EXPECTED_NONNEGATIVE_INTEGER;

	SInt64 iValue = (SInt64)dValue;
	if (iValue != dValue)				// Not an integral value?
		return EXPECTED_NONNEGATIVE_INTEGER;

	return 0;
}

static int
CheckNumberOfArraysTextField(NSTextField* textField)
{
	if (!TextFieldContainsValidInteger(textField))	// This catches empty or garbage text
		return BAD_NUM_ARRAYS;

	double dValue = [ textField doubleValue ];
	if (dValue <= 0.0)
		return BAD_NUM_ARRAYS;

	SInt64 iValue = (SInt64)dValue;
	if (iValue != dValue)							// Not an integral value?
		return BAD_NUM_ARRAYS;

	return 0;
}

static int
CheckNumberOfPointsInArrayTextField(NSTextField* textField)
{
	NSString* str = [ textField stringValue ];
	if ([ str localizedCaseInsensitiveCompare:@"auto"] == NSOrderedSame)
		return 0;	// 'auto' means GBLoadWaveX will calculate the number of points per array from the file size

	if (!TextFieldContainsValidInteger(textField))	// This catches empty or garbage text
		return BAD_NUM_POINTS_IN_ARRAY;
	
	double dValue = [ textField doubleValue ];
	if (dValue < 1.0)
		return BAD_NUM_POINTS_IN_ARRAY;

	SInt64 iValue = (SInt64)dValue;
	if (iValue != dValue)				// Not an integral value?
		return BAD_NUM_POINTS_IN_ARRAY;

	return 0;
}

static int
CheckFloatingPointTextField(NSTextField* textField)
{
	if (!TextFieldContainsValidDouble(textField))	// This catches empty or garbage text or NaN
		return BADNUM;								// "expected number"
	return 0;
}

/*	CreateErrorFrameTextField(errorControl)

	CreateErrorFrameTextField creates an error frame control and inserts it in the dialog
	to highlight errorControl which is the control that contains an invalid parameter.
	
	The error frame is implemented as an NSTextField with a colored background.
	CreateErrorFrameTextField inserts it into the view hierarchy just below errorControl.
	
	On return, only errorControl's superview retains the error frame control.
	It is released when we remove it from the superview which is done in generateCmd.
	
	If the user clicks cancel while the error frame exists, it is releaed when the dialog
	and all of its views are destroyed.
*/
static NSTextField*
CreateErrorFrameTextField(NSControl* errorControl)
{
	NSColor* errorBackgroundColor = [ NSColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:1.0 ];

	// Create an error frame to highlight error
	NSRect frame = [ errorControl frame ];
	frame.origin.x -= 6;
	frame.origin.y -= 6;
	frame.size.width += 12;
	frame.size.height += 12;
	NSTextField* errorFrameTextField = [ [ NSTextField alloc ] init ];	// This retains errorFrameTextField
	[ errorFrameTextField setFrame:frame ];
	[ errorFrameTextField setBackgroundColor:errorBackgroundColor ];
	[ errorFrameTextField setBezeled:NO ];								// No border
	NSView* superView = [ errorControl superview ];

	// The superview retains errorFrameTextField
	[ superView addSubview:errorFrameTextField  positioned:NSWindowBelow relativeTo:errorControl ];
	[ errorFrameTextField release];			// Balances alloc. Now only the superview retains errorFrameTextField.

	return errorFrameTextField;
}

static NSTextField* gErrorFrameTextField = nil;

- (NSString*)generateCommand {
	int err = 0;
	
	NSControl* errorControl = nil;		// The control containing an invalid parameter, if any

	// Dynamically-created text field used to highlight a control that contains an invalid parameter
	if (gErrorFrameTextField != nil) {
		/*	Remove the error frame in case the error was corrected.
			If there is still an error, a new frame is created below.
		*/
		[ gErrorFrameTextField removeFromSuperview ];	// Releases gErrorFrameTextField. This balances addSubview in CreateErrorFrameTextField.
		gErrorFrameTextField = nil;
	}
	
	self->cmdIsValid = false;
	self->settingsAreOK = false;

	GBLoadWaveSettings s;
	[ self gatherSettings:&s ];

	NSMutableString* cmd = [ NSMutableString stringWithCapacity:(NSUInteger)1024 ];
	
	do {
		bool useSymbolicPath = false;
		char fileName[MAX_FILENAME_LEN+1];
		char fileMacDirPath[MAX_DIRNAME_LEN+1];
		
		if (*s.fullMacPath == 0) {
			*fileName = 0;
			*fileMacDirPath = 0;
		}
		else {
			if (GetDirectoryAndFileNameFromFullPath(s.fullMacPath, fileMacDirPath, fileName) != 0) {
				[ cmd appendFormat:@" %s", "*** GetDirectoryAndFileNameFromFullPath Error ***" ];	// Should not happen
				break;
			}
		}

		[ cmd appendString:@"GBLoadWave" ];
		
		// Symbolic path
		if (*s.symbolicPathName != 0) {
			if (SymbolicPathPointsToFolder(s.symbolicPathName, fileMacDirPath)) {
				[ cmd appendFormat:@"/P=%s", s.symbolicPathName ];
				useSymbolicPath = true;
			}
		}
		
		// Overwrite
		if (s.overwrite)
			[ cmd appendString:@"/O" ];
		
		// Byte order
		if (s.byteOrder)
			[ cmd appendString:@"/B" ];
		
		// Interleaved
		if (s.interleaved)
			[ cmd appendString:@"/V" ];
		
		// Base name (/A or /N)
		err = CheckBaseNameTextField(self.baseNameTextField);
		if (err != 0) {
			errorControl = self.baseNameTextField;
			break;
		}
		if (*s.baseName!=0 && strcmp(s.baseName,"wave")!=0) {
			if (s.overwrite)
				[ cmd appendFormat:@"/N=%s", s.baseName ];
			else
				[ cmd appendFormat:@"/A=%s", s.baseName ];
		}
		
		// /T flag
		[ cmd appendFormat:@"/T={%d,%d}", s.inputDataType, s.outputDataType ];
		
		// Floating point format: /J=1 (IEEE - default) or /J=2 (VAX)
		// I elected to omit this infrequently-used flag from the dialog
		
		// Scaling (/Y)
		err = CheckFloatingPointTextField(self.scalingOffsetTextField);
		if (err != 0) {
			errorControl = self.scalingOffsetTextField;
			break;
		}
		err = CheckFloatingPointTextField(self.scalingMultiplierTextField);
		if (err != 0) {
			errorControl = self.scalingMultiplierTextField;
			break;
		}
		if (s.applyScaling)
			[ cmd appendFormat:@"/Y={%g,%g}", s.scalingOffset, s.scalingMultiplier ];
		
		// Bytes to skip (/S)
		err = CheckBytesToSkipTextField(self.bytesToSkipTextField);
		if (err != 0) {
			errorControl = self.bytesToSkipTextField;
			break;
		}
		if (s.bytesToSkip != 0)
			[ cmd appendFormat:@"/S=%lld", (long long)s.bytesToSkip ];
		
		// Number of arrays (/W)
		err = CheckNumberOfArraysTextField(self.numberOfArraysInFileTextField);
		if (err != 0) {
			errorControl = self.numberOfArraysInFileTextField;
			break;
		}
		[ cmd appendFormat:@"/W=%d", s.numberOfArraysInFile ];
		
		// Points per array (/U)
		// "auto" means GBLoadWave automatically deduces the number of points from the file size
		err = CheckNumberOfPointsInArrayTextField(self.numberOfPointsInArrayTextField);
		if (err != 0) {
			errorControl = self.numberOfPointsInArrayTextField;
			break;
		}
		if (s.numberOfPointsInArray > 0)
			[ cmd appendFormat:@"/U=%lld", (long long)s.numberOfPointsInArray ];
		
		self->settingsAreOK = true;
		
		// File name
		if (*s.fullMacPath == 0) {
			[ cmd setString:@"" ];		// No file chosen so no command generated
			break;
		}

		if (useSymbolicPath)
			[ cmd appendFormat:@" \"%s\"", fileName ];
		else
			[ cmd appendFormat:@" \"%s\"", s.fullMacPath ];

		self->cmdIsValid = true;
	} while(0);

	if (err != 0) {
		if (errorControl != nil)
			gErrorFrameTextField = CreateErrorFrameTextField(errorControl);
	
		char errorMessage[256+8];
		strcpy(errorMessage, "*** ");
		GetIgorErrorMessage(err, errorMessage+4);
		strcat(errorMessage, " ***");
		NSString* errorStr = [ NSString stringWithUTF8String:errorMessage ];	// Auto-released
		return errorStr;
	}
	
	NSString* result = [ NSString stringWithString:cmd ];		// Auto-released
	return result;
}

- (void)updateDialog
{
	char fileName[MAX_FILENAME_LEN+1];
	char fileMacDirPath[MAX_DIRNAME_LEN+1];
	const char* path = self->fullMacPath;
	if (*path == 0) {
		*fileName = 0;
		*fileMacDirPath = 0;
	}
	else {
		if (GetDirectoryAndFileNameFromFullPath(path, fileMacDirPath, fileName) != 0)
			strcpy(fileName, "Error");	// Should not happen
	}
	NSString* str = [ NSString stringWithUTF8String:fileName ];	// Auto-released
	[ self.fileNameTextField setStringValue:str ];

	NSString* cmd = [ self generateCommand ];					// Auto-released
	NSTextView* cmdTextView = self.cmdTextView;
	[ cmdTextView setEditable:YES ];
	[ cmdTextView setString:cmd ];
	[ cmdTextView setEditable:NO ];
	
	BOOL enable = self->cmdIsValid;
	[ self.okButton setEnabled:enable ];
	[ self.toCmdButton setEnabled:enable ];
	[ self.toClipButton setEnabled:enable ];
}

- (int)runModalDialog
{
	self->dialogResult = 0;
	
	gErrorFrameTextField = nil;
	
	[ self initializeDialog ];
	
	[ self restoreDialogSettingsFromPrefs ];
	
	[ self generateCommand ];					// Needed to detect invalid parameter, if any, at startup

	NSWindow* window = [ self dialogWindow ];
    [ window makeKeyAndOrderFront:nil ];
    [ NSApp runModalForWindow:window ];
    [ window orderOut:nil ];

	gErrorFrameTextField = nil;
	
	if (self->settingsAreOK)					// Don't store bad settings in prefs
		[ self storeDialogSettingsInPrefs ];
	
	int result = self->dialogResult;
	return result;
}

- (void)dealloc
{
	// NSLog(@"GBLoadWaveDialogController dealloc called");
	[ _cmdTextView release ];
	[ _dialogWindow release ];
	[ super dealloc ];
}

@end


/*	GBLoadWaveDialogLoader

	The GBLoadWaveDialogController object runs the dialog. In order to create it
	and to wire it to the dialog window and controls, as specified in the nib,
	we need another object to load the nib. The GBLoadWaveDialogController cannot
	load the nib because it is created by loading the nib.
	
	The GBLoadWaveDialogLoader is this other object. We manually create the GBLoadWaveDialogLoader
	object. This creates the GBLoadWaveDialogController object and sets the dialogController member
	of the GBLoadWaveDialogLoader to point to the new GBLoadWaveDialogController object.
	
	The loading of the nib also makes all of the connections wired in the nib between
	the GBLoadWaveDialogController and the dialog window and its controls.
*/
@implementation GBLoadWaveDialogLoader

@synthesize dialogController = _dialogController;

- (void)dealloc
{
	// NSLog(@"GBLoadWaveDialogLoader dealloc called");
	[ _dialogController release ];
	[ super dealloc ];
}

-(int)runGBLoadWaveDialog {	// Loads dialog from nib and runs it
	/*	These identifiers must agree with the identifiers that you enter in the
		Bundle Identifier field of the XOP's Info.plist or Info64.plist file.
		They are case-sensitive.
	*/
	#ifdef __LP64__
		NSString* bundleIdentifier = @"com.wavemetrics.xop.gbloadwavex64";	// Must agree with Info64.plist
	#else
		NSString* bundleIdentifier = @"com.wavemetrics.xop.gbloadwavex";	// Must agree with Info.plist
	#endif
	[ bundleIdentifier autorelease ];

	// Find the XOP bundle (the WindowXOP1.xop folder)
	NSBundle* xopBundle = [ NSBundle bundleWithIdentifier:bundleIdentifier ];	// xopBundle is autoreleased
	if (xopBundle == nil) {
		XOPNotice("Can't find GBLoadWaveX bundle - check the identifier passed to bundleWithIdentifier" CR_STR);
		return GENERAL_BAD_VIBS;
	}
	
	// Connect to the nib (GBLoadWaveX.xop/Contents/Resources/GBLoadWave.nib or 64-bit equivalent)
	NSNib* aNib = [[NSNib alloc] initWithNibNamed:@"GBLoadWaveDialog" bundle:xopBundle];
	if (aNib == nil) {
		XOPNotice("GBLoadWaveX initWithNibNamed failed");
		return GENERAL_BAD_VIBS;
	}
	
	// Load the nib
	NSArray* topLevelObjects = nil;
	if ([aNib instantiateNibWithOwner:self topLevelObjects:&topLevelObjects] == NO) {
		XOPNotice("GBLoadWaveX instantiateNibWithOwner failed");
		[aNib release];
		return GENERAL_BAD_VIBS;
	}
	
	// Release the raw nib data.
	[aNib release];

	GBLoadWaveDialogController* dialogController = [ self dialogController ];
	int result = [ dialogController runModalDialog ];

	/*	Apple's "Resource Programming Guide" says:
			For historical reasons, in OS X the top-level objects in a nib file
			are created with an additional reference count
		and prescribes this next statement.
	*/
	[topLevelObjects makeObjectsPerformSelector:@selector(release)];
	// topLevelObjects is autoreleased by instantiateNibWithOwner
	
	return result;
}

@end

int
GBLoadWaveDialog(void)	// Returns 0 if OK, -1 if cancel, or error code
{
	GBLoadWaveDialogLoader* loader = [ [ GBLoadWaveDialogLoader alloc ] init ];	// Retains loader
	int result = [ loader runGBLoadWaveDialog ];
	[ loader release ];															// Balance alloc retain
	return result;
}
