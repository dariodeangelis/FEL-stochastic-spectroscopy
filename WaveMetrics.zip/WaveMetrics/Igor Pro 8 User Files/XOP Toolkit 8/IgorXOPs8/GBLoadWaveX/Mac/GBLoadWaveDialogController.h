#import <Cocoa/Cocoa.h>
#import "XOPStandardHeaders.h"
#import "GBLoadWaveX.h"

@interface GBLoadWaveDialogController : NSWindowController <NSWindowDelegate, NSTextDelegate>
{
	/*	Compiling a property for 32 bits requires an explicit instance variable, a.k.a. "backing ivar". See
		http://stackoverflow.com/questions/3377869/how-to-define-and-implement-properties-in-protocol
	*/
	NSWindow* _dialogWindow;
	__weak NSPopUpButton* _inputDataTypePopup;
	__weak NSTextField* _bytesToSkipTextField;
	__weak NSTextField* _numberOfArraysInFileTextField;
	__weak NSTextField* _numberOfPointsInArrayTextField;
	__weak NSPopUpButton* _byteOrderPopup;
	__weak NSButton* _interleavedCheckbox;
	__weak NSPopUpButton* _pathPopup;
	__weak NSButton* _fileButton;
	__weak NSTextField* _fileNameTextField;
	__weak NSPopUpButton* _outputDataTypePopup;
	__weak NSTextField* _baseNameTextField;
	__weak NSButton* _overwriteCheckbox;
	__weak NSButton* _scalingCheckbox;
	__weak NSTextField* _scalingOffsetTextField;
	__weak NSTextField* _scalingMultiplierTextField;
	__weak NSButton* _okButton;
	__weak NSButton* _toCmdButton;
	__weak NSButton* _toClipButton;
	__weak NSButton* _helpButton;
	__weak NSButton* _cancelButton;
	NSTextView* _cmdTextView;
	
	bool cmdIsValid;
	bool settingsAreOK;
	char fullMacPath[MAX_PATH_LEN+1];		// Full HFS path to file to be loaded
	char symbolicPathName[MAX_OBJ_NAME+1];	// Name of last-selected symbolic path or ""
	bool pointOpenFileDialog;				// If the user selects a symbolic path, we show that path in the Open File dialog when the File button is next clicked
	int dialogResult;						// 0 if OK, -1 if cancel, or error code
}

@property (strong) IBOutlet NSWindow* dialogWindow;
@property (weak) IBOutlet NSPopUpButton* inputDataTypePopup;
@property (weak) IBOutlet NSTextField* bytesToSkipTextField;
@property (weak) IBOutlet NSTextField* numberOfArraysInFileTextField;
@property (weak) IBOutlet NSTextField* numberOfPointsInArrayTextField;
@property (weak) IBOutlet NSPopUpButton* byteOrderPopup;
@property (weak) IBOutlet NSButton* interleavedCheckbox;
@property (weak) IBOutlet NSPopUpButton* pathPopup;
@property (weak) IBOutlet NSButton* fileButton;
@property (weak) IBOutlet NSTextField* fileNameTextField;
@property (weak) IBOutlet NSPopUpButton* outputDataTypePopup;
@property (weak) IBOutlet NSTextField* baseNameTextField;
@property (weak) IBOutlet NSButton* overwriteCheckbox;
@property (weak) IBOutlet NSButton* scalingCheckbox;
@property (weak) IBOutlet NSTextField* scalingOffsetTextField;
@property (weak) IBOutlet NSTextField* scalingMultiplierTextField;
@property (weak) IBOutlet NSButton* okButton;
@property (weak) IBOutlet NSButton* toCmdButton;
@property (weak) IBOutlet NSButton* toClipButton;
@property (weak) IBOutlet NSButton* helpButton;
@property (weak) IBOutlet NSButton* cancelButton;
@property (strong) IBOutlet NSTextView* cmdTextView;	// NSTextView does not support weak references

- (IBAction)inputDataTypeSelected:(id)sender;
- (IBAction)byteOrderSelected:(id)sender;
- (IBAction)interleavedCheckboxClicked:(id)sender;
- (IBAction)pathSelected:(id)sender;
- (IBAction)fileButtonClicked:(id)sender;
- (IBAction)outputDataTypeSelected:(id)sender;
- (IBAction)overwriteCheckboxClicked:(id)sender;
- (IBAction)scalingCheckboxClicked:(id)sender;
- (IBAction)doItButtonClicked:(id)sender;
- (IBAction)toCmdLineButtonClicked:(id)sender;
- (IBAction)toClipButtonClicked:(id)sender;
- (IBAction)helpButtonClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;

- (void)controlTextDidChange:(NSNotification*)notification;	// Called by NSTextView controls for which we are wired in the nib as the delegate
- (void)windowDidLoad;
- (BOOL)windowShouldClose:(id)sender;
- (void)windowWillClose:(NSNotification*)notification;

- (void)initializeDialog;
- (void)gatherSettings:(GBLoadWaveSettingsPtr)p;
- (NSString*)generateCommand;
- (void)updateDialog;
- (int)runModalDialog;
@end

@interface GBLoadWaveDialogLoader : NSObject
{
	/*	Compiling a property for 32 bits requires an explicit instance variable, a.k.a. "backing ivar". See
		http://stackoverflow.com/questions/3377869/how-to-define-and-implement-properties-in-protocol
	*/
	GBLoadWaveDialogController* _dialogController;
}

@property (strong) IBOutlet GBLoadWaveDialogController* dialogController;

-(int)runGBLoadWaveDialog;

@end

int GBLoadWaveDialog(void);

