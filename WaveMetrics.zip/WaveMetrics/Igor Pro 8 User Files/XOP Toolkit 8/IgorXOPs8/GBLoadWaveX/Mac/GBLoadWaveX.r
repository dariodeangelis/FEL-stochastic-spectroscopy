#include "XOPStandardHeaders.r"

resource 'vers' (1) {						// XOP version info
	0x02, 0x01, release, 0x00, 0,			// version bytes and country integer
	"2.01",
	"2.01, Copyright 1994-2018 WaveMetrics, Inc., all rights reserved."
};

resource 'vers' (2) {						// Igor version info
	0x08, 0x00, release, 0x00, 0,			// version bytes and country integer
	"8.00",
	"(for Igor Pro 8.00 or later)"
};

resource 'STR#' (1101) {					// Misc strings that Igor looks for.
	{
		/* [1] */
		"-1",								// This item is no longer supported by the Carbon XOP Toolkit.
		/* [2] */
		"---"		,						// This item is no longer supported by the Carbon XOP Toolkit.
		/* [3] */
		"GBLoadWaveX Help",					// Name of XOP's help file.
	}
};

// Description of menu items added to built-in Igor menus.
resource 'XMI1' (1100) {
	{
		50,									// Add item to menu with ID=50 (Load Waves menu).
		"Load General Binary File X...",	// This is text for added menu item.
		0,									// This item has no submenu.
		0,									// Flags field.
	}
};

resource 'STR#' (1100) {					// custom error messages
	{
		/* [1] */
		"This is not a general binary file",
		/* [2] */
		"There is no data in file",
		/* [3] */
		"Expected name of general binary file",
		/* [4] */
		"Expected base name for new waves",
		/* [5] */
		"Expected file type",
		/* [6] */
		"Too many file types (4 allowed)",
		/* [7] */
		"Data length in bits must be 8, 16, 32 or 64",
		/* [8] */
		"Number of arrays must be an integer >= 1",
		/* [9] */
		"The number of points per array must be a positive integer or 'auto'",
		/* [10] */
		"File contains too few bytes for specified number of bytes/point, points and arrays",
		/* [11] */
		"Bad data type value",
		/* [12] */
		"GBLoadWaveX requires Igor Pro version 8.00 or later",
		/* [13] */
		"Valid floating point formats are 1 (IEEE) and 2 (VAX)",
		/* [14] */
		"The array is too big for an Igor wave.",
	}
};

resource 'XOPI' (1100) {
	XOP_VERSION,							// XOP protocol version.
	DEV_SYS_CODE,							// Code for development system used to make XOP
	XOP_FEATURE_FLAGS,						// Tells Igor about XOP features
	XOPI_RESERVED,							// Reserved - must be zero.
	XOP_TOOLKIT_VERSION,					// XOP Toolkit version.
};

resource 'XOPC' (1100) {
	{
		"GBLoadWaveX",						// Name of operation
		XOPOp+UtilOP+compilableOp,			// Operation's category
	}
};
