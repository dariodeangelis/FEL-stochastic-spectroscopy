﻿/*	GBLoadWaveDialog.c -- dialog handling routines for the GBLoadWave XOP.

*/

#include "XOPStandardHeaders.h"			// Include ANSI headers, Mac headers, IgorXOP.h, XOP.h and XOPSupport.h

#include "..\GBLoadWaveX.h"
#include "resource.h"

// Global Variables

static DialogPositionAndSize gDialogPositionAndSize = {0};

// Structures

struct DialogStorage {						// See InitDialogStorage for a discussion of this structure.
	char fullMacPath[MAX_PATH_LEN+1];		// Full HFS file path
	int pointOpenFileDialog;				// Determines when we point the open file dialog at a particular directory.
	bool cmdIsValid;
	bool settingsAreOK;
};
typedef struct DialogStorage DialogStorage;
typedef struct DialogStorage *DialogStoragePtr;

static int
MenuItemToDataType(int dataTypeItemNumber)
{
	int result;
	
	switch(dataTypeItemNumber) {
		case 1:
			result = NT_FP64;
			break;
		case 2:
			result = NT_FP32;
			break;
		case 3:
			result = NT_I64;
			break;
		case 4:
			result = NT_I32;
			break;
		case 5:
			result = NT_I16;
			break;
		case 6:
			result = NT_I8;
			break;
		case 7:
			result = NT_I64 | NT_UNSIGNED;
			break;
		case 8:
			result = NT_I32 | NT_UNSIGNED;
			break;
		case 9:
			result = NT_I16 | NT_UNSIGNED;
			break;
		case 10:
			result = NT_I8 | NT_UNSIGNED;
			break;
		default:
			result = NT_FP64;
			break;	
	}
	return result;
}

static int
DataTypeToMenuItemIndex(int dataType)
{
	int oneBasedMenuItemIndex = 1;
	
	switch(dataType) {
		case NT_FP64:
			oneBasedMenuItemIndex = 1;
			break;
		case NT_FP32:
			oneBasedMenuItemIndex = 2;
			break;
		case NT_I64:
			oneBasedMenuItemIndex = 3;
			break;
		case NT_I32:
			oneBasedMenuItemIndex = 4;
			break;
		case NT_I16:
			oneBasedMenuItemIndex = 5;
			break;
		case NT_I8:
			oneBasedMenuItemIndex = 6;
			break;
		case NT_I64 | NT_UNSIGNED:
			oneBasedMenuItemIndex = 7;
			break;
		case NT_I32 | NT_UNSIGNED:
			oneBasedMenuItemIndex = 8;
			break;
		case NT_I16 | NT_UNSIGNED:
			oneBasedMenuItemIndex = 9;
			break;
		case NT_I8 | NT_UNSIGNED:
			oneBasedMenuItemIndex = 10;
			break;
	}

	return oneBasedMenuItemIndex;
}

static void
GatherSettings(XOPDialogRef theDialog, GBLoadWaveSettingsPtr p)
{
	int itemNumber;
	int int1;
	SInt64 int64;
	double d1;
	char temp[256];

	MemClear(p, sizeof(GBLoadWaveSettings));
	
	p->version = kGBLoadWaveXDialogSettingsVersion;
	
	GetDialogPositionAndSize(theDialog, &p->dialogPosition);
	
	// General
	p->interactive = 0;				// Currently not represented in dialog
	p->quiet = 0;					// Currently not represented in dialog
	
	// Input
	{
		GetPopMenu(theDialog, IDC_INPUT_TYPE_POPUP, &itemNumber, temp);
		p->inputDataType = MenuItemToDataType(itemNumber);

		if (GetDInt64(theDialog,IDC_SKIP_BYTES_TEXT,&int64) == 0)
			p->bytesToSkip = int64;

		if (GetDInt(theDialog,IDC_NUMBER_OF_ARRAYS_TEXT,&int1) == 0)
			p->numberOfArraysInFile = int1;

		if (GetDInt64(theDialog,IDC_NUMBER_OF_POINTS_TEXT,&int64) == 0)
			p->numberOfPointsInArray = int64;

		GetPopMenu(theDialog, IDC_BYTE_ORDER_POPUP, &itemNumber, temp);
		p->byteOrder = itemNumber==1 ? 0:1;					// 0=high byte first, 1=low byte first

		GetPopMenu(theDialog, IDC_FLOAT_FORMAT_POPUP, &itemNumber, temp);
		p->floatingPointFormat = itemNumber;				// 1=IEEE, 2=VAX

		p->interleaved = GetCheckBox(theDialog, IDC_POINTS_INTERLEAVED);

		GetPopMenu(theDialog, IDC_PATH_POPUP, &itemNumber, temp);
		strcpy(p->symbolicPathName, temp);
	}
	
	// Output
	{
		GetPopMenu(theDialog, IDC_OUTPUT_TYPE_POPUP, &itemNumber, temp);
		p->outputDataType = MenuItemToDataType(itemNumber);

		if (GetDText(theDialog, IDC_BASE_NAME_TEXT, temp) < sizeof(p->baseName))
			strcpy(p->baseName, temp);

		if (GetDText(theDialog,IDC_BASE_NAME_TEXT,temp) < sizeof(p->baseName))
			strcpy(p->baseName, temp);

		p->overwrite = GetCheckBox(theDialog, IDC_OVERWRITE_WAVES);

		p->applyScaling = GetCheckBox(theDialog, IDC_SCALING_CHECKBOX);
		
		if (GetDDouble(theDialog, IDC_OFFSET_TEXT, &d1) == 0)
			p->scalingOffset = d1;
		
		if (GetDDouble(theDialog, IDC_MULTIPLIER_TEXT, &d1) == 0)
			p->scalingMultiplier = d1;
	}
}

static void
StoreDialogSettingsInPrefs(XOPDialogRef theDialog, DialogStorage* dsp)	// Save dialog settings for next time
{
	GBLoadWaveSettingsHandle gbHandle = (GBLoadWaveSettingsHandle)WMNewHandle((BCInt)sizeof(GBLoadWaveSettings));
	if (gbHandle != NULL) {
		GatherSettings(theDialog, *gbHandle);
		SaveXOPPrefsHandle((Handle)gbHandle);
		WMDisposeHandle((Handle)gbHandle);
	}
}

static void
RestoreDialogSettingsFromPrefs(XOPDialogRef theDialog, DialogStorage* dsp)
{
	GBLoadWaveSettingsHandle gbHandle;

	GetXOPPrefsHandle((Handle*)&gbHandle);

	if (gbHandle && (*gbHandle)->version==kGBLoadWaveXDialogSettingsVersion) {
		GBLoadWaveSettingsPtr p = (GBLoadWaveSettingsPtr)(*gbHandle);

		RestoreDialogPositionAndSize(theDialog, &p->dialogPosition);

		// Input
		{
			int inputDataTypeItemNumber = DataTypeToMenuItemIndex(p->inputDataType);
			SetPopItem(theDialog, IDC_INPUT_TYPE_POPUP, inputDataTypeItemNumber);
			
			SetDInt64(theDialog, IDC_SKIP_BYTES_TEXT, p->bytesToSkip);
		
			SetDInt(theDialog, IDC_NUMBER_OF_ARRAYS_TEXT, p->numberOfArraysInFile);
		
			if (p->numberOfPointsInArray <= 0)
				SetDText(theDialog, IDC_NUMBER_OF_POINTS_TEXT, "auto");
			else
				SetDInt64(theDialog, IDC_NUMBER_OF_POINTS_TEXT, p->numberOfPointsInArray);
			
			SetPopItem(theDialog, IDC_BYTE_ORDER_POPUP, p->byteOrder ? 2:1);

			SetPopItem(theDialog, IDC_FLOAT_FORMAT_POPUP, p->floatingPointFormat);		// 1=IEEE, 2=VAX

			SetCheckBox(theDialog, IDC_POINTS_INTERLEAVED, p->interleaved);

			SetPopMatch(theDialog, IDC_PATH_POPUP, p->symbolicPathName);
		}
		
		// Output
		{
			int outputDataTypeItemNumber = DataTypeToMenuItemIndex(p->outputDataType);
			SetPopItem(theDialog, IDC_OUTPUT_TYPE_POPUP, outputDataTypeItemNumber);
			
			SetDText(theDialog, IDC_BASE_NAME_TEXT, p->baseName);
		
			SetCheckBox(theDialog, IDC_OVERWRITE_WAVES, p->overwrite);

			SetCheckBox(theDialog, IDC_SCALING_CHECKBOX, p->applyScaling);

			SetDDouble(theDialog, IDC_OFFSET_TEXT, p->scalingOffset);

			SetDDouble(theDialog, IDC_MULTIPLIER_TEXT, p->scalingMultiplier);
		}
	}
	
	if (gbHandle != NULL)
		WMDisposeHandle((Handle)gbHandle);
}

/*	InitDialogStorage(dsp)

	We use a DialogStorage structure to store working values during the dialog.
	In a Macintosh application, the fields in this structure could be local variables
	in the main dialog routine. However, in a Windows application, they would have
	to be globals. By using a structure like this, we are able to avoid using globals.
	Also, routines that access these fields (such as this one) can be used for
	both platforms.
*/
static int
InitDialogStorage(DialogStorage* dsp)
{
	MemClear(dsp, sizeof(DialogStorage));
	return 0;
}

static void
DisposeDialogStorage(DialogStorage* dsp)
{
	// Does nothing for this dialog.
}

static int
InitDialogPopups(XOPDialogRef theDialog)
{
	int err;

	err = 0;
	do {
		const char* dataTypeStr;
		dataTypeStr = "Double float;Single float;64-bit signed integer;32-bit signed integer;16-bit signed integer;8-bit signed integer;64-bit unsigned integer;32-bit unsigned integer;16-bit unsigned integer;8-bit unsigned integer";
		
		if (err = CreatePopMenu(theDialog, IDC_PATH_POPUP, IDC_PATH_POPUP_TITLE, "_none_", 1))
			break;
		FillPathPopMenu(theDialog, IDC_PATH_POPUP, "*", "", 1);
		
		if (err = CreatePopMenu(theDialog, IDC_INPUT_TYPE_POPUP, IDC_INPUT_TYPE_POPUP_TITLE, dataTypeStr, 1))
			break;
		
		if (err = CreatePopMenu(theDialog, IDC_OUTPUT_TYPE_POPUP, IDC_OUTPUT_TYPE_POPUP_TITLE, dataTypeStr, 1))
			break;
		
		if (err = CreatePopMenu(theDialog, IDC_FLOAT_FORMAT_POPUP, IDC_FLOAT_FORMAT_POPUP_TITLE, "IEEE;VAX", 1))
			break;
		
		if (err = CreatePopMenu(theDialog, IDC_BYTE_ORDER_POPUP, IDC_BYTE_ORDER_POPUP_TITLE, "High byte first;Low byte first", 1))
			break;
	} while(0);
	
	return err;
}

/*	UpdateDialogItems(theDialog, dsp)

	Shows, hides, enables, disables dialog items as necessary.
*/
static void
UpdateDialogItems(XOPDialogRef theDialog, DialogStorage* dsp)
{
	int enableInterleave;
	int itemNumber;
	int int1;
	char temp[256];

	GetPopMenu(theDialog, IDC_INPUT_TYPE_POPUP, &itemNumber, temp);
	if (itemNumber > 2) {			// Not a floating point format?
		HideDialogItem(theDialog, IDC_FLOAT_FORMAT_POPUP);
		HideDialogItem(theDialog, IDC_FLOAT_FORMAT_POPUP_TITLE);
	}
	else {
		ShowDialogItem(theDialog, IDC_FLOAT_FORMAT_POPUP);
		ShowDialogItem(theDialog, IDC_FLOAT_FORMAT_POPUP_TITLE);
	}
	
	enableInterleave = GetDInt(theDialog, IDC_NUMBER_OF_ARRAYS_TEXT, &int1)==0 && int1>1;
	HiliteDControl(theDialog, IDC_POINTS_INTERLEAVED, enableInterleave);
}

/*	InitDialogSettings(theDialog, dsp)

	Called when the dialog is first displayed to initialize all items.
*/
static int
InitDialogSettings(XOPDialogRef theDialog, DialogStorage* dsp)
{
	int err;
	
	err = 0;
	
	InitPopMenus(theDialog);
	
	do {
		if (err = InitDialogPopups(theDialog))
			break;
		
		SetDInt(theDialog, IDC_SKIP_BYTES_TEXT, 0);
		SetDInt(theDialog, IDC_NUMBER_OF_ARRAYS_TEXT, 1);
		SetDText(theDialog, IDC_NUMBER_OF_POINTS_TEXT, "auto");
		SetDText(theDialog, IDC_BASE_NAME_TEXT, "wave");
		SetDText(theDialog, IDC_FILE_NAME, "");
		SetDText(theDialog, IDC_OFFSET_TEXT, "0.0");
		SetDText(theDialog, IDC_MULTIPLIER_TEXT, "1.0");
	
		SetCheckBox(theDialog, IDC_POINTS_INTERLEAVED, 0);
		SetCheckBox(theDialog, IDC_OVERWRITE_WAVES, 0);
		SetCheckBox(theDialog, IDC_SCALING_CHECKBOX, 0);
	
		RestoreDialogSettingsFromPrefs(theDialog, dsp);
		
		UpdateDialogItems(theDialog, dsp);
	} while(0);
	
	if (err)
		KillPopMenus(theDialog);
	
	return err;
}

static void
ShutdownDialogSettings(XOPDialogRef theDialog, DialogStorage* dsp)
{
	if (dsp->settingsAreOK)
		StoreDialogSettingsInPrefs(theDialog, dsp);
	
	KillPopMenus(theDialog);
}

/*	SymbolicPathPointsToFolder(symbolicPathName, folderPath)

	symbolicPathName is the name of an Igor symbolic path.

	folderPath is a full path to a folder. This is a native path with trailing
	colon (Mac) or backslash (Win).
	
	Returns true if the symbolic path refers to the folder specified by folderPath.
*/
static int
SymbolicPathPointsToFolder(const char* symbolicPathName, const char* folderPath)
{
	char symbolicPathDirPath[MAX_PATH_LEN+1];	// This is a native path with trailing colon (Mac) or backslash (Win).
	
	if (GetPathInfo2(symbolicPathName, symbolicPathDirPath))
		return 0;		// Error getting path info.
	
	return CmpStr(folderPath, symbolicPathDirPath) == 0;
}

static bool
TextFieldContainsValidInteger(XOPDialogRef theDialog, int dialogItemID)
{
	char text[256];
	if (GetDText(theDialog, dialogItemID, text) == 0)
		return false;								// Empty text
	char junk[100];
	double dValue;
	if (sscanf(text, "%lg%9s", &dValue, junk) != 1)
		return false;								// Text preceding or following number
	GetDDouble(theDialog, dialogItemID, &dValue);
	if ((SInt64)dValue != dValue)
		return false;								// Not an integer
	return true;
}

static bool
TextFieldContainsValidDouble(XOPDialogRef theDialog, int dialogItemID)
{
	char text[256];
	if (GetDText(theDialog, dialogItemID, text) == 0)
		return false;								// Empty text
	double dValue;
	char junk[100];
	if (sscanf(text, "%lg%9s", &dValue, junk) != 1)
		return false;								// Text preceding or following number
	if (dValue != dValue)
		return false;								// Catches NaN
	return true;
}

static int
CheckBaseNameTextField(XOPDialogRef theDialog, int dialogItemID)
{
	char text[256];
	if (GetDText(theDialog, dialogItemID, text) == 0)
		return 0;		// Empty defaults to "wave"

	if (strlen(text) > (MAX_OBJ_NAME-10))
		return NAME_TOO_LONG;

	char cleanedUpBaseName[MAX_OBJ_NAME+1];
	strcpy(cleanedUpBaseName, text);
	int err = CleanupName(0, cleanedUpBaseName, MAX_OBJ_NAME-10);	// Require standard, not liberal name
	if (err != 0)
		return err;
	
	if (CmpStr(cleanedUpBaseName,text) != 0)
		return BAD_CHAR_IN_NAME;			// CleanupName had to do some cleanup
	
	return 0;
}

static int
CheckBytesToSkipTextField(XOPDialogRef theDialog, int dialogItemID)
{
	if (!TextFieldContainsValidInteger(theDialog, dialogItemID))	// This catches empty or garbage text
		return EXPECTED_NONNEGATIVE_INTEGER;

	double dValue;
	GetDDouble(theDialog, dialogItemID, &dValue);
	if (dValue < 0.0)
		return EXPECTED_NONNEGATIVE_INTEGER;

	SInt64 iValue = (SInt64)dValue;
	if (iValue != dValue)				// Not an integral value?
		return EXPECTED_NONNEGATIVE_INTEGER;

	return 0;
}

static int
CheckNumberOfArraysTextField(XOPDialogRef theDialog, int dialogItemID)
{
	if (!TextFieldContainsValidInteger(theDialog, dialogItemID))	// This catches empty or garbage text
		return BAD_NUM_ARRAYS;

	double dValue;
	GetDDouble(theDialog, dialogItemID, &dValue);
	if (dValue <= 0.0)
		return BAD_NUM_ARRAYS;

	SInt64 iValue = (SInt64)dValue;
	if (iValue != dValue)				// Not an integral value?
		return BAD_NUM_ARRAYS;

	return 0;
}

static int
CheckNumberOfPointsInArrayTextField(XOPDialogRef theDialog, int dialogItemID)
{
	char text[256];
	
	GetDText(theDialog, dialogItemID, text);
	if (CmpStr(text,"auto") == 0)
		return 0;	// 'auto' means GBLoadWaveX will calculate the number of points per array from the file size

	if (!TextFieldContainsValidInteger(theDialog, dialogItemID))	// This catches empty or garbage text
		return BAD_NUM_POINTS_IN_ARRAY;
	
	double dValue;
	GetDDouble(theDialog, dialogItemID, &dValue);
	if (dValue < 1.0)
		return BAD_NUM_POINTS_IN_ARRAY;

	SInt64 iValue = (SInt64)dValue;
	if (iValue != dValue)				// Not an integral value?
		return BAD_NUM_POINTS_IN_ARRAY;

	return 0;
}

static int
CheckFloatingPointTextField(XOPDialogRef theDialog, int dialogItemID)
{
	if (!TextFieldContainsValidDouble(theDialog, dialogItemID))	// This catches empty or garbage text or NaN
		return BADNUM;								// "expected number"
	return 0;
}

static int
GetFilePath(bool useFullPath, const char* fullMacPath, const char* fileName, char* buffer, int bufferSize)
{
	char filePath[MAX_PATH_LEN+1];
	int length;

	if (!useFullPath) {
		// We want just the file name
		strcpy(filePath, fileName);
	}
	else {
		strcpy(filePath, fullMacPath);
	
		// Escape backslashes if the path is a Windows UNC path (e.g., \\server\share).
		length = (int)strlen(filePath) + 1;				// Include null terminator.
		if (EscapeSpecialCharacters(filePath, length, filePath, sizeof(filePath), &length) != 0)
			return PATH_TOO_LONG;
	}
	
	length = (int)strlen(filePath);
	if (length > (bufferSize-1-1-1))	// -1 for leading quote, -1 for trailing quote, -1 for null terminator
		return PATH_TOO_LONG;
	
	strcpy(buffer, " \"");
	strcat(buffer, filePath);
	strcat(buffer, "\"");
	return 0;
}

static void
ShowOrHideBadItemIndicator(XOPDialogRef theDialog, int badItemID)
{
	if (badItemID == 0) {
		HideDialogItem(theDialog, IDC_BAD_ITEM_INDICATOR);
	}
	else {
		/*	Position and show the bad item indicator. We would like to have a
			louder indicator but we found no simple way to do it on Windows.
			You could do it by adding a custom control. See
			https://msdn.microsoft.com/en-us/library/windows/desktop/bb775501(v=vs.85).aspx
		*/
		Rect badItemBox, errorIndicatorBox;
		GetDBox(theDialog, badItemID, &badItemBox);
		GetDBox(theDialog, IDC_BAD_ITEM_INDICATOR, &errorIndicatorBox);
		int width = errorIndicatorBox.right - errorIndicatorBox.left;
		int height = errorIndicatorBox.bottom - errorIndicatorBox.top;
		errorIndicatorBox.left = badItemBox.right + 5;
		errorIndicatorBox.right = errorIndicatorBox.left + width;
		errorIndicatorBox.top = badItemBox.top + 3;
		errorIndicatorBox.bottom = errorIndicatorBox.top + height;
		MoveDItem(theDialog, IDC_BAD_ITEM_INDICATOR, &errorIndicatorBox);
		ShowDialogItem(theDialog, IDC_BAD_ITEM_INDICATOR);
	}
}

/*	GenerateCommand(theDialog, dsp, cmd)

	Generates a GBLoadWaveX command based on the dialog's items.
	
	Returns 0 if the command is OK or non-zero if it is not valid.
	Returns -1 if cmd contains error message that should be shown in dialog.
*/
static int
GenerateCommand(XOPDialogRef theDialog, DialogStorage* dsp, char cmd[MAXCMDLEN+1])
{
	char temp[256+2];
	int badItemID = 0;
	bool useSymbolicPath = false;
	int err = 0;
	
	*cmd = 0;
	
	dsp->cmdIsValid = false;
	dsp->settingsAreOK = false;
	
	GBLoadWaveSettings s;
	GatherSettings(theDialog, &s);
	
	do {
		char fileName[MAX_FILENAME_LEN+1];
		char fileMacDirPath[MAX_DIRNAME_LEN+1];
		if (*dsp->fullMacPath == 0) {
			*fileName = 0;
			*fileMacDirPath = 0;
		}
		else {
			err = GetDirectoryAndFileNameFromFullPath(dsp->fullMacPath, fileMacDirPath, fileName);
			if (err != 0) {
				sprintf(cmd, "*** GetDirectoryAndFileNameFromFullPath Error ***");
				break;
			}
		}

		strcpy(cmd, "GBLoadWaveX");
		
		// Symbolic path
		if (*s.symbolicPathName != 0) {
			if (SymbolicPathPointsToFolder(s.symbolicPathName, fileMacDirPath)) {
				strcat(cmd, "/P=");
				strcat(cmd, s.symbolicPathName);
				useSymbolicPath = true;
			}
		}
		
		// Overwrite
		if (s.overwrite)
			strcat(cmd, "/O");
		
		// Byte order
		if (s.byteOrder > 0)					// Low byte first?
			strcat(cmd, "/B");
		
		// Interleaved
		if (s.interleaved)
			strcat(cmd, "/V");
		
		// Base name (/A or /N)
		err = CheckBaseNameTextField(theDialog, IDC_BASE_NAME_TEXT);
		if (err != 0) {
			badItemID = IDC_BASE_NAME_TEXT;
			break;
		}
		if (*s.baseName!=0 && strcmp(s.baseName,"wave")!=0) {
			if (s.overwrite)
				strcat(cmd, "/N=");
			else
				strcat(cmd, "/A=");
			strcat(cmd, s.baseName);
		}
		
		// /T flag
		sprintf(temp, "/T={%d,%d}", s.inputDataType, s.outputDataType);
		strcat(cmd, temp);
		
		// Floating point format (/J)
		if (s.inputDataType==NT_FP64 || s.outputDataType==NT_FP32) {
			if (s.floatingPointFormat == 2)						// 1=IEEE, 2=VAX
				strcat(cmd, "/J=2");
		}
		
		// Scaling (/Y)
		err = CheckFloatingPointTextField(theDialog, IDC_OFFSET_TEXT);
		if (err != 0) {
			badItemID = IDC_OFFSET_TEXT;
			break;
		}
		err = CheckFloatingPointTextField(theDialog, IDC_MULTIPLIER_TEXT);
		if (err != 0) {
			badItemID = IDC_MULTIPLIER_TEXT;
			break;
		}
		if (s.applyScaling) {
			sprintf(temp, "/Y={%g,%g}", s.scalingOffset, s.scalingMultiplier);
			strcat(cmd, temp);
		}
		
		// Bytes to skip (/S)
		err = CheckBytesToSkipTextField(theDialog, IDC_SKIP_BYTES_TEXT);
		if (err != 0) {
			badItemID = IDC_SKIP_BYTES_TEXT;
			break;
		}
		if (s.bytesToSkip != 0) {
			sprintf(temp, "/S=%lld", s.bytesToSkip);
			strcat(cmd, temp);
		}
		
		// Number of arrays (/W)
		err = CheckNumberOfArraysTextField(theDialog, IDC_NUMBER_OF_ARRAYS_TEXT);
		if (err != 0) {
			badItemID = IDC_NUMBER_OF_ARRAYS_TEXT;
			break;
		}
		sprintf(temp, "/W=%d", s.numberOfArraysInFile);
		strcat(cmd, temp);
		
		// Points per array (/U)
		// "auto" means GBLoadWave automatically deduces the number of points from the file size
		err = CheckNumberOfPointsInArrayTextField(theDialog, IDC_NUMBER_OF_POINTS_TEXT);
		if (err != 0) {
			badItemID = IDC_NUMBER_OF_POINTS_TEXT;
			break;
		}
		if (s.numberOfPointsInArray > 0) {
			sprintf(temp, "/U=%lld", s.numberOfPointsInArray);
			strcat(cmd, temp);
		}

		dsp->settingsAreOK = true;
		
		// File name
		// Add file name or full path to the command.
		if (*dsp->fullMacPath == 0) {
			*cmd = 0;				// No file chose so no command generated
			break;
		}
		else {
			int len = (int)strlen(cmd);
			err = GetFilePath(!useSymbolicPath, dsp->fullMacPath, fileName, cmd+len, MAXCMDLEN+1-len);
			if (err != 0)
				break;
		}

		dsp->cmdIsValid = true;
	} while(0);
	
	if (err != 0) {
		char errorMessage[256+8];
		strcpy(errorMessage, "*** ");
		GetIgorErrorMessage(err, errorMessage+4);
		strcat(errorMessage, " ***");
		strcpy(cmd, errorMessage);
	}
	
	ShowOrHideBadItemIndicator(theDialog, badItemID);
	
	return err;
}

/*	ShowCmd(theDialog, dsp, cmd)

	Displays GBLoadWave cmd in dialog cmd box.
	Returns 0 if cmd is OK, non-zero otherwise.
	
	Also, enables or disables buttons based on cmd being OK or not.
*/
static int
ShowCmd(XOPDialogRef theDialog, DialogStorage* dsp, char cmd[MAXCMDLEN+1])
{
	int result, enable;

	result = GenerateCommand(theDialog, dsp, cmd);
	if (result)
		enable = 0;
	else
		enable = 1;
	
	HiliteDControl(theDialog, IDC_DOIT_BUTTON, enable);
	HiliteDControl(theDialog, IDC_TO_CLIP_BUTTON, enable);
	HiliteDControl(theDialog, IDC_TO_CMD_BUTTON, enable);
	
	DisplayDialogCmd(theDialog, IDC_COMMAND_BOX, cmd);

	return result;
}

/*	GetFileToLoad(theDialog, pointOpenFileDialog, fullMacPath)

	Displays open file dialog. Returns 0 if the user clicks Open or -1 if
	the user cancels.
	
	If the user clicks Open, returns via fullMacPath the full HFS path to the file
	to be loaded. We always use Macintosh HFS-style paths, even when running on Windows.
	This avoids a complication presented by the fact that backslash is an escape character in Igor.
	
	If pointOpenFileDialog is true then the open file dialog will initially
	display the directory associated with the symbolic path selected in the
	path popup menu.
*/
static int
GetFileToLoad(XOPDialogRef theDialog, int pointOpenFileDialog, char fullMacPath[MAX_PATH_LEN+1])
{
	char symbolicPathName[MAX_OBJ_NAME+1];
	int flagsIn;
	static int fileFilterIndex = 1;
	const char* fileFilterStr = "All Files:.*;";
	char initialDir[MAX_PATH_LEN+1];
	char initialFile[MAX_FILENAME_LEN+1];
	int pathItemNumber;
	int result;
	
	flagsIn = 0;
	
	// Assume that the last path shown in the Open File dialog is what we want to show.
	*initialFile = 0;
	*initialDir = 0;
	
	// If the user just selected a symbolic path, show the corresponding folder in the open file dialog.
	if (pointOpenFileDialog) {
		GetPopMenu(theDialog, IDC_PATH_POPUP, &pathItemNumber, symbolicPathName);
		if (pathItemNumber > 1)					// Item 1 is "_none_".
			GetPathInfo2(symbolicPathName, initialDir);
	}
	
	// Display the open file dialog.
	char fullWinPath[MAX_PATH_LEN+1];
	result = XOPOpenFileDialog2(flagsIn, "Choose a general binary file", fileFilterStr, &fileFilterIndex, initialDir, initialFile, NULL, fullWinPath);

	// Reactivate the parent dialog.
	SetWindowPos(theDialog, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	
	if (result != 0)
		return result;

	/*	We always use Macintosh HFS-style paths, even when running on Windows. This avoids a
		complication presented by the fact that backslash is an escape character in Igor.
	*/
	strcpy(fullMacPath, fullWinPath);
	WinToMacPath(fullMacPath);							// Convert to HFS path
	
	// Set the dialog IDC_FILE_NAME item.
	char fileDirPath[MAX_PATH_LEN+1];
	char fileName[MAX_FILENAME_LEN+1];
	if (GetDirectoryAndFileNameFromFullPath(fullMacPath, fileDirPath, fileName) != 0)
		strcpy(fileName, "***Error***");				// Should never happen.
	SetDText(theDialog, IDC_FILE_NAME, fileName);
	
	return result;
}

/*	HandleItemHit(theDialog, itemID, dsp)
	
	Called when the item identified by itemID is hit.
	Carries out any actions necessitated by the hit.
*/
static void
HandleItemHit(XOPDialogRef theDialog, int itemID, DialogStorage* dsp)
{
	int selItem;
	
	if (ItemIsPopMenu(theDialog, itemID))
		GetPopMenu(theDialog, itemID, &selItem, NULL);
	
	switch(itemID) {
		case IDC_INPUT_TYPE_POPUP:
		case IDC_OUTPUT_TYPE_POPUP:
		case IDC_FLOAT_FORMAT_POPUP:
		case IDC_BYTE_ORDER_POPUP:
			// Nothing more needs to be done for these popup.
			break;

		case IDC_FILE_BUTTON:
			GetFileToLoad(theDialog, dsp->pointOpenFileDialog, dsp->fullMacPath);
			dsp->pointOpenFileDialog = 0;
			break;

		case IDC_PATH_POPUP:
			dsp->pointOpenFileDialog = 1;		// Flag that we want to point open file dialog at a particular directory.
			break;

		case IDC_POINTS_INTERLEAVED:
		case IDC_OVERWRITE_WAVES:
			ToggleCheckBox(theDialog, itemID);
			break;
		
		case IDC_SCALING_CHECKBOX:
			ToggleCheckBox(theDialog, IDC_SCALING_CHECKBOX);
			break;
		
		case IDC_HELP_BUTTON:
			XOPDisplayHelpTopic("GBLoadWave Help", "GBLoadWave XOP[The Load General Binary Dialog]", 1);
			break;

		case IDC_DOIT_BUTTON:
		case IDC_TO_CMD_BUTTON:
		case IDC_TO_CLIP_BUTTON:
			{
				char cmd[MAXCMDLEN+1];
				
				GenerateCommand(theDialog, dsp, cmd);
				switch(itemID) {
					case IDC_DOIT_BUTTON:
						FinishDialogCmd(cmd, 1);
						break;
					case IDC_TO_CMD_BUTTON:
						FinishDialogCmd(cmd, 2);
						break;
					case IDC_TO_CLIP_BUTTON:
						FinishDialogCmd(cmd, 3);
						break;
				}
			}
			break;
	}

	UpdateDialogItems(theDialog, dsp);
}

static INT_PTR CALLBACK
DialogProc(HWND theDialog, UINT msgCode, WPARAM wParam, LPARAM lParam)
{
	char cmd[MAXCMDLEN+1];
	int itemID, notificationMessage;
	BOOL result; 						// Function result

	static DialogStoragePtr dsp;

	result = FALSE;
	itemID = LOWORD(wParam);						// Item, control, or accelerator identifier.
	notificationMessage = HIWORD(wParam);
	
	switch(msgCode) {
		case WM_INITDIALOG:
			PositionWinDialogWindow(theDialog, NULL);		// Position nicely relative to Igor MDI client.
			
			dsp = (DialogStoragePtr)lParam;
			if (InitDialogSettings(theDialog, dsp) != 0) {
				EndDialog(theDialog, IDCANCEL);				// Should never happen.
				return FALSE;
			}
			
			RestoreDialogPositionAndSize(theDialog, &gDialogPositionAndSize);
			
			ShowCmd(theDialog, dsp, cmd);

			SetFocus(GetDlgItem(theDialog, IDC_PATH_POPUP));
			result = FALSE; // Tell Windows not to set the input focus			
			break;
		
		case WM_COMMAND:
			switch(itemID) {
				case IDC_DOIT_BUTTON:
				case IDC_TO_CMD_BUTTON:
				case IDC_TO_CLIP_BUTTON:
				case IDC_CANCEL_BUTTON:
					HandleItemHit(theDialog, itemID, dsp);
					GetDialogPositionAndSize(theDialog, &gDialogPositionAndSize);	// Store for next time
					ShutdownDialogSettings(theDialog, dsp);
					EndDialog(theDialog, itemID);
					result = TRUE;
					break;				
				
				default:
					if (!IsWinDialogItemHitMessage(theDialog, itemID, notificationMessage))
						break;					// This is not a message that we need to handle.
					HandleItemHit(theDialog, itemID, dsp);
					ShowCmd(theDialog, dsp, cmd);
					break;
			}
			break;
	}
	return result;
}

/*	GBLoadWaveDialog()

	GBLoadWaveDialog is called when user selects 'Load General Binary...'
	from 'Load Waves' submenu.
	
	Returns 0 if OK, -1 for cancel or an error code.
*/
int
GBLoadWaveDialog(void)
{
	DialogStorage ds;
	int result;
	
	if (result = InitDialogStorage(&ds))
		return result;

	result = (int)DialogBoxParam(XOPModule(), MAKEINTRESOURCE(IDD_GBLOADWAVE_DIALOG), IgorClientHWND(), DialogProc, (LPARAM)&ds);

	DisposeDialogStorage(&ds);

	if (result != IDC_CANCEL_BUTTON)
		return 0;
	return -1;					// Cancel.
}
