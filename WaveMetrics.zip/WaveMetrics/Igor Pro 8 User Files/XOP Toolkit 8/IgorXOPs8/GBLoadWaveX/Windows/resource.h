﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GBLoadWaveX.rc
//

#define IDD_GBLOADWAVE_DIALOG           1260

#define IDC_DOIT_BUTTON                 1
#define IDC_CANCEL_BUTTON               2
#define IDC_TO_CMD_BUTTON               1000
#define IDC_TO_CLIP_BUTTON              1001
#define IDC_COMMAND_BOX                 1002
#define IDC_HELP_BUTTON                 1003
#define IDC_INPUT_FILE_BOX              1004
#define IDC_INPUT_TYPE_POPUP_TITLE      1005
#define IDC_INPUT_TYPE_POPUP            1006
#define IDC_FLOAT_FORMAT_POPUP_TITLE    1007
#define IDC_FLOAT_FORMAT_POPUP          1008
#define IDC_PATH_POPUP_TITLE            1009
#define IDC_PATH_POPUP                  1010
#define IDC_FILE_BUTTON                 1011
#define IDC_FILE_NAME                   1012
#define IDC_SKIP_BYTES_TITLE            1013
#define IDC_SKIP_BYTES_TEXT             1014
#define IDC_NUMBER_OF_ARRAYS_TITLE      1015
#define IDC_NUMBER_OF_ARRAYS_TEXT       1016
#define IDC_NUMBER_OF_POINTS_TITLE      1017
#define IDC_NUMBER_OF_POINTS_TEXT       1018
#define IDC_BYTE_ORDER_POPUP_TITLE      1019
#define IDC_BYTE_ORDER_POPUP            1020
#define IDC_POINTS_INTERLEAVED          1021
#define IDC_OUTPUT_WAVES_BOX            1022
#define IDC_OVERWRITE_WAVES             1023
#define IDC_BASE_NAME_TITLE             1024
#define IDC_BASE_NAME_TEXT              1025
#define IDC_SCALING_CHECKBOX            1026
#define IDC_OUTPUT_TYPE_POPUP_TITLE     1027
#define IDC_OUTPUT_TYPE_POPUP           1028
#define IDC_OFFSET_TITLE                1029
#define IDC_OFFSET_TEXT                 1030
#define IDC_MULTIPLIER_TITLE            1031
#define IDC_MULTIPLIER_TEXT             1032
#define IDC_BAD_ITEM_INDICATOR             1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
