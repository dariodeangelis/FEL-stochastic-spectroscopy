//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VDT.rc
//
#define IDR_MENU_VDT                    100
#define IDR_MENU_TERMINAL_PORT          101
#define IDR_MENU_OPERATIONS_PORT        102
#define IDR_DIALOG_VDT_SETTINGS         1100
#define IDR_MENU_PORT                   1100
#define IDR_MENU_BAUD_RATE              1101
#define IDR_MENU_DATA_LENGTH            1102
#define IDR_MENU_STOP_BITS              1103
#define IDR_MENU_PARITY                 1104
#define IDR_MENU_LOCAL_ECHO             1105
#define IDR_MENU_INPUT_HANDSHAKING      1106
#define IDR_MENU_OUTPUT_HANDSHAKING     1107
#define IDR_MENU_TERMINAL_EOL           1108
#define ID_VDT_OPENVDTWINDOW            40001
#define ID_VDT_VDTSETTINGS              40003
#define ID_VDT_TERMINALPORT             40005
#define ID_VDT_SAVEFILE                 40006
#define ID_VDT_INSERTFILE               40007
#define ID_VDT_SENDFILE                 40008
#define ID_VDT_RECEIVEFILE              40009
#define ID_VDT_SENDSELECTEDTEXT         40010
#define ID_VDT_OPERATIONSPORT           40011
#define ID_VDT_RESET_SERIAL_PORTS		40012
#define ID_VDT_HELP		                40013


#define ID_OPERATIONSPORT_COM1          40021
#define ID_OPERATIONSPORT_COM2          40022
#define ID_OPERATIONSPORT_COM3          40023
#define ID_OPERATIONSPORT_COM4          40024
#define ID_OPERATIONSPORT_COM5          40025
#define ID_OPERATIONSPORT_COM6          40026
#define ID_OPERATIONSPORT_COM7          40027
#define ID_OPERATIONSPORT_COM8          40028
#define ID_OPERATIONSPORT_LPT1          40029
#define ID_OPERATIONSPORT_LPT2          40030
#define ID_OPERATIONSPORT_OFFLINE       40031

#define ID_TERMINALPORT_COM1            40041
#define ID_TERMINALPORT_COM2            40042
#define ID_TERMINALPORT_COM3            40043
#define ID_TERMINALPORT_COM4            40044
#define ID_TERMINALPORT_COM5            40045
#define ID_TERMINALPORT_COM6            40046
#define ID_TERMINALPORT_COM7            40047
#define ID_TERMINALPORT_COM8            40048
#define ID_TERMINALPORT_LPT1            40049
#define ID_TERMINALPORT_LPT2            40050
#define ID_TERMINALPORT_OFFLINE         40051

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40100
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
