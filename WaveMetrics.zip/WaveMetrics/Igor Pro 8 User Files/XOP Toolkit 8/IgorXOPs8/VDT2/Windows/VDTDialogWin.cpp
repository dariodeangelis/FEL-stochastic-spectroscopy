#include "XOPStandardHeaders.h"			// Include ANSI headers, Mac headers, IgorXOP.h, XOP.h and XOPSupport.h
#include "..\VDT.h"
#include "resource.h"

// Global Variables

DialogPositionAndSize gDialogPositionAndSize = {0};

// Equates

#define DIALOG_TEMPLATE_ID 1100

enum {				// These are both Macintosh item numbers and Windows item IDs.
	OK_BUTTON=1,
	CANCEL_BUTTON,
	PORT_TITLE,
	PORT_POPUP,
	PORT_IS_OPEN_STATTEXT,
	PORT_IS_CLOSED_STATTEXT,
	OPEN_PORT_CHECKBOX,
	CLOSE_PORT_CHECKBOX,
	PORT_WILL_BE_OPENED_STATTEXT,
	PORT_WILL_BE_CLOSED_STATTEXT,
	USE_PORT_FOR_TERMINAL_CHECKBOX,
	USE_PORT_FOR_OPERATIONS_CHECKBOX,
	BAUD_RATE_TITLE,
	BAUD_RATE_POPUP,
	INPUT_HANDSHAKE_TITLE,
	INPUT_HANDSHAKE_POPUP,
	DATA_LENGTH_TITLE,
	DATA_LENGTH_POPUP,
	OUTPUT_HANDSHAKE_TITLE,
	OUTPUT_HANDSHAKE_POPUP,
	STOP_BITS_TITLE,
	STOP_BITS_POPUP,
	INPUT_BUFFER_SIZE_TITLE,
	INPUT_BUFFER_SIZE_TEXT,
	PARITY_TITLE,
	PARITY_POPUP,
	LOCAL_ECHO_TITLE,
	LOCAL_ECHO_POPUP,
	TERMINAL_EOL_TITLE,
	TERMINAL_EOL_POPUP,
	SAVE_SETUP_WITH_EXP_CHECKBOX,
	INPUT_BUFFER_LIMITATION_MESSAGE		// "Input buffer is not settable on OS X".
};

/*	FillPortPopup(theDialog)

	Fills the popup with list of the ports that we found to be installed at runtime.
*/
static void
FillPortPopup(XOPDialogRef theDialog)
{
	VDTPortPtr pp;
	int index;
	
	DeletePopMenuItems(theDialog, PORT_POPUP, 0);		// Delete all items
	index = 0;
	do {
		pp = IndexedVDTPort(NULL, index);
		if (pp == NULL)
			break;
		FillPopMenu(theDialog, PORT_POPUP, pp->name, (int)strlen(pp->name), 10000);
		index += 1;
	} while(1);
	SetPopItem(theDialog, PORT_POPUP, 1);
}

static int
InitDialogPopups(XOPDialogRef theDialog)
{
	int err;
	
	err = 0;
	
	do {
		char baudStr[256];
		GetBaudRateMenuItemString(baudStr);			// Get list of supported baud rates for this platform.
		if (err = CreatePopMenu(theDialog, BAUD_RATE_POPUP, BAUD_RATE_TITLE, baudStr, 6))
			break;
		
		if (err = CreatePopMenu(theDialog, DATA_LENGTH_POPUP, DATA_LENGTH_TITLE, "7;8;", 2))
			break;
		
		if (err = CreatePopMenu(theDialog, STOP_BITS_POPUP, STOP_BITS_TITLE, "1;2;", 2))
			break;
		
		if (err = CreatePopMenu(theDialog, PARITY_POPUP, PARITY_TITLE, "None;Odd;Even;", 1))
			break;
		
		if (err = CreatePopMenu(theDialog, LOCAL_ECHO_POPUP, LOCAL_ECHO_TITLE, "Off;On;", 2))
			break;
		
		if (err = CreatePopMenu(theDialog, INPUT_HANDSHAKE_POPUP, INPUT_HANDSHAKE_TITLE, "None;CTS-DTR;XON-XOFF;", 1))
			break;
		
		if (err = CreatePopMenu(theDialog, OUTPUT_HANDSHAKE_POPUP, OUTPUT_HANDSHAKE_TITLE, "None;CTS-DTR;XON-XOFF;", 1))
			break;
		
		if (err = CreatePopMenu(theDialog, TERMINAL_EOL_POPUP, TERMINAL_EOL_TITLE, "CR;LF;CRLF;", 3))
			break;
		
		if (err = CreatePopMenu(theDialog, PORT_POPUP, PORT_TITLE, "", 1))
			break;
		FillPortPopup(theDialog);
	} while(0);
	
	return err;
}

/*	SetOpenAndClosedItems(...)

	Sets static text and checkboxes that have to do with whether the currently-selected
	port is open, closed, marked for opening or marked for closing.
*/
static void
SetOpenAndClosedItems(XOPDialogRef theDialog, VDTPortPtr dd)
{
	int portIsOpen;

	portIsOpen = dd != NULL && dd->portIsOpen;
	if (portIsOpen) {										// Port is open?
		HideDialogItem(theDialog, PORT_IS_CLOSED_STATTEXT);
		ShowDialogItem(theDialog, PORT_IS_OPEN_STATTEXT);
		HideDialogItem(theDialog, OPEN_PORT_CHECKBOX);
		ShowDialogItem(theDialog, CLOSE_PORT_CHECKBOX);
		if (dd->portClosedInDialog)
			ShowDialogItem(theDialog, PORT_WILL_BE_CLOSED_STATTEXT);
		else
			HideDialogItem(theDialog, PORT_WILL_BE_CLOSED_STATTEXT);
		HideDialogItem(theDialog, PORT_WILL_BE_OPENED_STATTEXT);
	}
	else {
		HideDialogItem(theDialog, PORT_IS_OPEN_STATTEXT);
		ShowDialogItem(theDialog, PORT_IS_CLOSED_STATTEXT);
		HideDialogItem(theDialog, CLOSE_PORT_CHECKBOX);
		ShowDialogItem(theDialog, OPEN_PORT_CHECKBOX);
		if (dd->portOpenedInDialog)
			ShowDialogItem(theDialog, PORT_WILL_BE_OPENED_STATTEXT);
		else
			HideDialogItem(theDialog, PORT_WILL_BE_OPENED_STATTEXT);
		HideDialogItem(theDialog, PORT_WILL_BE_CLOSED_STATTEXT);
	}

	SetCheckBox(theDialog, OPEN_PORT_CHECKBOX, dd != NULL && dd->portOpenedInDialog);
	SetCheckBox(theDialog, CLOSE_PORT_CHECKBOX, dd != NULL && dd->portClosedInDialog);
}

/*	SetTerminalAndOperationsCheckboxes(theDialog, dd, tp, op)

dd identifies the port selected in the dialog. It will be NULL if no ports are available.

tp identifies the port selected as terminal port. It will be NULL if no port is selected.

op identifies the port selected as operations port. It will be NULL if no port is selected.
*/
static void
SetTerminalAndOperationsCheckboxes(XOPDialogRef theDialog, VDTPortPtr dd, VDTPortPtr tp, VDTPortPtr op)
{
	int tpState, opState;

	if (dd == NULL) {
		tpState = 0;
		opState = 0;
	}
	else {
		if (tp == NULL)
			tpState = 0;
		else
			tpState = CmpStr(tp->name, dd->name) == 0;

		if (op == NULL)
			opState = 0;
		else
			opState = CmpStr(op->name, dd->name) == 0;
	}

	SetCheckBox(theDialog, USE_PORT_FOR_TERMINAL_CHECKBOX, tpState);
	SetCheckBox(theDialog, USE_PORT_FOR_OPERATIONS_CHECKBOX, opState);
}

/*	UpdateDialog(theDialog, dsp)

	Sets all items in the dialog according to the state indicated by dsp.
	
	This is called when the dialog is first displayed and then when the user
	changes the current port.
*/
static void
UpdateDialog(XOPDialogRef theDialog, DialogStorage* dsp)
{
	int baudRate;
	char baudRateStr[32];
	
	SetCheckBox(theDialog, SAVE_SETUP_WITH_EXP_CHECKBOX, dsp->useExpSettingsIn);
	SetPopMatch(theDialog, PORT_POPUP, dsp->port.name);

	BaudCodeToBaudRate(dsp->port.baudCode, &baudRate);
	snprintf(baudRateStr, sizeof(baudRateStr), "%d", baudRate);
	SetPopMatch(theDialog, BAUD_RATE_POPUP, baudRateStr);
	SetPopItem(theDialog, DATA_LENGTH_POPUP, dsp->port.databits+1);
	SetPopItem(theDialog, STOP_BITS_POPUP, dsp->port.stopbits+1);
	SetPopItem(theDialog, PARITY_POPUP, dsp->port.parity+1);
	SetPopItem(theDialog, LOCAL_ECHO_POPUP, dsp->port.echo+1);
	SetPopItem(theDialog, INPUT_HANDSHAKE_POPUP, dsp->port.inShake+1);
	SetPopItem(theDialog, OUTPUT_HANDSHAKE_POPUP, dsp->port.outShake+1);
	SetPopItem(theDialog, TERMINAL_EOL_POPUP, dsp->port.terminalEOL+1);
	SetDInt(theDialog, INPUT_BUFFER_SIZE_TEXT, (int)dsp->port.inputBufferSize);

	SetOpenAndClosedItems(theDialog, &dsp->port);
	SetTerminalAndOperationsCheckboxes(theDialog, &dsp->port, dsp->portToUseForTerminal, dsp->portToUseForOperations);
}

static void
ShutdownDialogSettings(XOPDialogRef theDialog, DialogStorage* dsp)
{
	KillPopMenus(theDialog);
}

/*	InitDialogSettings(theDialog, dsp)

Called when the dialog is first displayed to initialize all items.
*/
static int
InitDialogSettings(XOPDialogRef theDialog, DialogStorage* dsp)
{
	int err;

	err = 0;

#ifdef MACIGOR
	// The size of the input buffer is not settable on OS X.
	HideDialogItem(theDialog, INPUT_BUFFER_SIZE_TEXT);
	ShowDialogItem(theDialog, INPUT_BUFFER_LIMITATION_MESSAGE);
#endif

	InitPopMenus(theDialog);

	do {
		if (err = InitDialogPopups(theDialog))
			break;

		UpdateDialog(theDialog, dsp);
	} while (0);

	if (err != 0)
		KillPopMenus(theDialog);

	return err;
}

/*	HandleItemHit(theDialog, itemID, dsp)
	
	Called when the item identified by itemID is hit.
	Carries out any actions necessitated by the hit.
*/
static void
HandleItemHit(XOPDialogRef theDialog, int itemID, DialogStorage* dsp)
{
	int selItem;
	char itemText[256];
	int baudRate, baudCode;
	int intVal;
	
	if (ItemIsPopMenu(theDialog, itemID))
		GetPopMenu(theDialog, itemID, &selItem, itemText);
	
	switch(itemID) {
		case PORT_POPUP:
			SetCurrentDialogPort(selItem, dsp);
			UpdateDialog(theDialog, dsp);
			break;

		case OPEN_PORT_CHECKBOX:
			dsp->port.portOpenedInDialog = ToggleCheckBox(theDialog, OPEN_PORT_CHECKBOX);
			SetOpenAndClosedItems(theDialog, &dsp->port);
			break;

		case CLOSE_PORT_CHECKBOX:
			dsp->port.portClosedInDialog = ToggleCheckBox(theDialog, CLOSE_PORT_CHECKBOX);
			SetOpenAndClosedItems(theDialog, &dsp->port);
			break;
	
		case USE_PORT_FOR_TERMINAL_CHECKBOX:
			if (ToggleCheckBox(theDialog, USE_PORT_FOR_TERMINAL_CHECKBOX))
				dsp->portToUseForTerminal = dsp->pp;		// May be NULL.
			else
				dsp->portToUseForTerminal = NULL;			// No port selected as terminal port.
			break;
		
		case USE_PORT_FOR_OPERATIONS_CHECKBOX:
			if (ToggleCheckBox(theDialog, USE_PORT_FOR_OPERATIONS_CHECKBOX))
				dsp->portToUseForOperations = dsp->pp;		// May be NULL.
			else
				dsp->portToUseForOperations = NULL;			// No port selected as operations port.
			break;

		case BAUD_RATE_POPUP:
			baudRate = atoi(itemText);
			BaudRateToBaudCode(baudRate, &baudCode);
			dsp->port.baudCode = baudCode;
			dsp->port.portSettingsChangedInDialog = 1;
			break;

		case DATA_LENGTH_POPUP:
			dsp->port.databits = selItem - 1;
			dsp->port.portSettingsChangedInDialog = 1;
			break;

		case STOP_BITS_POPUP:
			dsp->port.stopbits = selItem - 1;
			dsp->port.portSettingsChangedInDialog = 1;
			break;

		case PARITY_POPUP:
			dsp->port.parity = selItem - 1;
			dsp->port.portSettingsChangedInDialog = 1;
			GetPopMenu(theDialog, itemID, &selItem, NULL);
			break;
		
		case LOCAL_ECHO_POPUP:
			dsp->port.echo = selItem - 1;
			dsp->port.portSettingsChangedInDialog = 1;
			break;
		
		case INPUT_HANDSHAKE_POPUP:
			dsp->port.inShake = selItem - 1;
			dsp->port.portSettingsChangedInDialog = 1;
			break;
		
		case OUTPUT_HANDSHAKE_POPUP:
			dsp->port.outShake = selItem - 1;
			dsp->port.portSettingsChangedInDialog = 1;
			break;
		
		case TERMINAL_EOL_POPUP:
			dsp->port.terminalEOL = selItem - 1;
			dsp->port.portSettingsChangedInDialog = 1;
			break;

	   case INPUT_BUFFER_SIZE_TEXT:
		   if (GetDInt(theDialog, INPUT_BUFFER_SIZE_TEXT, &intVal) == 0) {
				if (intVal < MINBUFSIZE)
					intVal = MINBUFSIZE;
				if (intVal > MAXBUFSIZE)
					intVal = MAXBUFSIZE;
			   dsp->port.inputBufferSize = intVal;
			   dsp->port.portSettingsChangedInDialog = 1;
		   }
		   break;
	   
	   case SAVE_SETUP_WITH_EXP_CHECKBOX:
		   dsp->expSettings = ToggleCheckBox(theDialog, SAVE_SETUP_WITH_EXP_CHECKBOX);
		   break;
		
		case OK_BUTTON:
			ProcessDialogOK(dsp);
			break;
	}
}

static INT_PTR CALLBACK
DialogProc(HWND theDialog, UINT msgCode, WPARAM wParam, LPARAM lParam)
{
	int itemID, notificationMessage;
	BOOL result; 						// Function result

	static DialogStoragePtr dsp;

	result = FALSE;
	itemID = LOWORD(wParam);						// Item, control, or accelerator identifier.
	notificationMessage = HIWORD(wParam);
	
	switch(msgCode) {
		case WM_INITDIALOG:
			PositionWinDialogWindow(theDialog, NULL);		// Position nicely relative to Igor MDI client.
			
			dsp = (DialogStoragePtr)lParam;
			if (InitDialogSettings(theDialog, dsp) != 0) {
				EndDialog(theDialog, IDCANCEL);				// Should never happen.
				return FALSE;
			}
			
			RestoreDialogPositionAndSize(theDialog, &gDialogPositionAndSize);

			UpdateDialog(theDialog, dsp);

			SetFocus(GetDlgItem(theDialog, PORT_POPUP));
			result = FALSE; // Tell Windows not to set the input focus			
			break;
		
		case WM_COMMAND:
			switch(itemID) {
				case OK_BUTTON:
				case CANCEL_BUTTON:
					HandleItemHit(theDialog, itemID, dsp);
					GetDialogPositionAndSize(theDialog, &gDialogPositionAndSize);	// Store for next time
					ShutdownDialogSettings(theDialog, dsp);
					EndDialog(theDialog, itemID);
					result = TRUE;
					break;				
				
				default:
					if (!IsWinDialogItemHitMessage(theDialog, itemID, notificationMessage))
						break;					// This is not a message that we need to handle.
					HandleItemHit(theDialog, itemID, dsp);
					break;
			}
			break;
	}

	return result;
}

int
VDTSettingsDialog(int useExpSettingsIn, int* useExpSettingsOutPtr)
{
	DialogStorage ds;
	INT_PTR result;
	
	*useExpSettingsOutPtr = useExpSettingsIn;
	if (result = InitDialogStorage(&ds, useExpSettingsIn, useExpSettingsOutPtr))
		return (int)result;

	result = DialogBoxParam(XOPModule(), MAKEINTRESOURCE(DIALOG_TEMPLATE_ID), IgorClientHWND(), DialogProc, (LPARAM)&ds);

	DisposeDialogStorage(&ds);

	if (result == OK_BUTTON)
		return 0;
	return -1;					// Cancel
}
