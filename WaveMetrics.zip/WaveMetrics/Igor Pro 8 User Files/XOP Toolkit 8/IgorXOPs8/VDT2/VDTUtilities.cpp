#include "XOPStandardHeaders.h"			// Include ANSI headers, Mac headers, IgorXOP.h, XOP.h and XOPSupport.h
#include "VDT.h"

// Baud Rate Utilities

struct BaudRateInfo {
	int baudCode;				// Integer code used internally and in VDT dialog settings structure.
	int baudRate;				// e.g., 9600
	int supportedOnMac;			// True if supported on Macintosh.
	int supportedOnWin;			// True if supported on Windows.
};
typedef struct BaudRateInfo BaudRateInfo;
typedef struct BaudRateInfo* BaudRateInfoPtr;

/*	HR, 990415, 2.12: Removed support on Windows for 128000 and 256000 baud in favor
	of supporting the more widely used 115200 and 230400 rates. I decided that it
	was fairly unlikely that someone relies on those non-standard rates.
	
	On Macintosh, rates higher than 57600 are supported only by relatively
	recent operating system software, such as Mac OS 8 or later. Also, rates
	higher than 57600 will be reliable only on fast machines. See TN1018.
	
	On Windows, I believe that standard PC hardware supports rates no higher
	than 57600. Specialized hardware may support higher rates. See Knowledge
	Base article Q99026.
	
	HR, 090612, 1.14: Added support for 128000 and 256000 baud. They do not appear
	to work on Mac OS X but I have marked it as supported anyway in case there is
	some hardware that supports it.
	
	HR, 2013-05-16, 1.15: Added support for 460800 and 921600 baud rates. They are
	listed as supported by http://digital.ni.com/public.nsf/allkb/D37754FFA24F7C3F86256706005B9BE7
	However they require special hardware support and may cause buffer overruns
	so use with caution.
*/
static struct BaudRateInfo baudRateInfo[]=
{
	// Baud Code		// Baud Rate		// Supported on Mac		// Supported on Win
	{0,					300,				1,						1},
	{1,					600,				1,						1},
	{2,					1200,				1,						1},
	{3,					2400,				1,						1},
	{4,					4800,				1,						1},
	{5,					9600,				1,						1},
	{6,					19200,				1,						1},
	{7,					38400,				1,						1},
	{8,					57600,				1,						1},
	{9,					115200,				1,						1},
	{10,				128000,				1,						1},		// HR, 090612, 1.14: Added this.
	{11,				230400,				1,						1},
	{12,				256000,				1,						1},		// HR, 090612, 1.14: Added this.
	{13,				460800,				1,						1},		// HR, 2013-05-16, 1.15: Added this.
	{14,				921600,				1,						1},		// HR, 2013-05-16, 1.15: Added this.
	{-1,				-1,					0,						0}		// Marks the end of the table.
};

/*	GetBaudRateMenuItemString(str)

	Returns a string to be used in the VDT dialog baud popup menu.
*/
void
GetBaudRateMenuItemString(char str[256])
{
	BaudRateInfoPtr brp;
	int supported;
	char temp[32];

	*str = 0;
	brp = baudRateInfo;
	while(brp->baudCode >= 0) {
		#ifdef MACIGOR
			supported = brp->supportedOnMac;
		#endif
		#ifdef WINIGOR
			supported = brp->supportedOnWin;
		#endif
		if (supported) {
			snprintf(temp, sizeof(temp), "%d;", brp->baudRate);
			strcat(str, temp);
		}
		brp += 1;	
	}
}

/*	BaudRateToBaudCode(baudRate, baudCodePtr)
	
	baudRate is an input (e.g., 9600).
	
	Returns via baudCodePtr the integer baud code associated with the rate.
	
	If the rate is supported on the current platform, the function result
	is zero. If the rate is not supported,the function result is a non-zero
	error code.
*/
int
BaudRateToBaudCode(int baudRate, int* baudCodePtr)
{
	BaudRateInfoPtr brp;
	int supported;

	*baudCodePtr = 0;							// Init in case of an error below.
	
	brp = baudRateInfo;
	while(brp->baudCode >= 0) {
		if (brp->baudRate == baudRate)
			break;
		brp += 1;	
	}

	if (brp->baudCode < 0)
		return INVALID_BAUD;					// This baud rate was not found in the table.
	
	*baudCodePtr = brp->baudCode;

	#ifdef MACIGOR
		supported = brp->supportedOnMac;
	#endif
	#ifdef WINIGOR
		supported = brp->supportedOnWin;
	#endif
	if (supported)
		return 0;
	return VDT_ERR_BAUD_NOT_SUPPORTED_ON_THIS_PLATFORM;
}

/*	BaudCodeToBaudRate(baudCode, baudRatePtr)
	
	baudCode is a small integer code representing a baud rate.
	
	Returns via baudRatePtr the actual baud rate associated with the code.
	
	If the code is supported on the current platform, the function result
	is zero. If the code is not supported,the function result is a non-zero
	error code.
*/
int
BaudCodeToBaudRate(int baudCode, int* baudRatePtr)
{
	BaudRateInfoPtr brp;
	int supported;

	*baudRatePtr = 9600;						// Init in case of an error below.
	
	brp = baudRateInfo;
	while(brp->baudCode >= 0) {
		if (brp->baudCode == baudCode)
			break;
		brp += 1;	
	}

	if (brp->baudCode < 0)
		return INVALID_BAUD;					// This baud rate was not found in the table.
	
	*baudRatePtr = brp->baudRate;

	#ifdef MACIGOR
		supported = brp->supportedOnMac;
	#endif
	#ifdef WINIGOR
		supported = brp->supportedOnWin;
	#endif
	if (supported)
		return 0;
	return VDT_ERR_BAUD_NOT_SUPPORTED_ON_THIS_PLATFORM;
}

/*	ValidateBaudCode(baudCode)

	Returns baudCode if it is a valid baud code for the current platform.
	If not, it returns the code for 9600 baud.
*/
int
ValidateBaudCode(int baudCode)
{
	int baudRate;
	
	if (BaudCodeToBaudRate(baudCode, &baudRate) != 0)
		baudCode = 5;
	return baudCode;
}


static void
DisposeVDTPortLinkedList(VDTPortPtr firstVDTPortPtr)
{
	VDTPortPtr dd, tt;

	dd = firstVDTPortPtr;
	while (dd != NULL) {
		tt = dd->nextPort;
		WMDisposePtr((Ptr)dd);
		dd = tt;	
	}
}

static void
CopyVDTPortFieldsOrGetDefaults(VDTPortPtr in, VDTPortPtr out)
{
	if (in != NULL) {
		VDTPortPtr nextPort;
		nextPort = out->nextPort;
		memcpy(out, in, sizeof(VDTPort));
		out->nextPort = nextPort;			// Never copy nextPort fields because this would mix up the dialog linked list with the main linked list.
	}
	else {
		SetVDTPortFieldsToDefault("-None-", "Input", "Output", out);	// Use dummy values when no ports exist.
	}
}

static int
BuildVDTPortLinkedList(VDTPortPtr* firstVDTPortPtrPtr, int* numberOfPortsInListPtr)
{
	VDTPortPtr firstVDTPortPtr;
	VDTPortPtr pp, dd;
	int index, numberOfPortsInList;
	
	firstVDTPortPtr = *firstVDTPortPtrPtr = NULL;
	numberOfPortsInList = *numberOfPortsInListPtr = 0;
	
	index = 0;
	while(1) {
		pp = IndexedVDTPort(NULL, index);
		if (pp == NULL)
			break;						// No more ports exist.
		
		// Make a copy of VDTPort structure.
		dd = (VDTPortPtr)WMNewPtr(sizeof(VDTPort));
		if (dd == NULL) {
			DisposeVDTPortLinkedList(firstVDTPortPtr);
			return NOMEM;
		}
		CopyVDTPortFieldsOrGetDefaults(pp, dd);
		dd->nextPort = NULL;								// Don't mix linked lists.
		
		// These should already be zero but just in case.
		dd->portSettingsChangedInDialog = 0;
		dd->portOpenedInDialog = 0;
		dd->portClosedInDialog = 0;
		
		// Add to linked list.
		if (firstVDTPortPtr == NULL) {
			firstVDTPortPtr = dd;
		}
		else {
			VDTPortPtr tt;
			tt = firstVDTPortPtr;
			while(tt->nextPort != NULL)
				tt = tt->nextPort;
			tt->nextPort = dd;
		}
		numberOfPortsInList += 1;
		index += 1;
	}
	
	*numberOfPortsInListPtr = numberOfPortsInList;
	*firstVDTPortPtrPtr = firstVDTPortPtr;
	return 0;
}

void
SetCurrentDialogPort(int oneBasedNewSelectedPort, DialogStorage* dsp)
{
	if (dsp->dd != NULL) {
		CopyVDTPortFieldsOrGetDefaults(&dsp->port, dsp->dd);	// Copy settings back to old selected port.
		dsp->dd->selectedInDialog = 0;
	}
	dsp->dd = IndexedVDTPort(dsp->firstVDTPortPtr, oneBasedNewSelectedPort-1);	// Get new selected port (may be the same port).
	if (dsp->dd == NULL) {
		dsp->pp = NULL;
	}
	else {
		dsp->dd->selectedInDialog = 1;
		dsp->pp = FindVDTPort(NULL, dsp->dd->name);
	}
	CopyVDTPortFieldsOrGetDefaults(dsp->dd, &dsp->port);		// Uses default values if dsp->dd is NULL.
}


/*	ClosePortsMarkedForClosing(firstVDTPortPtr)

	Called when the user clicks OK.
	
	Closes communications ports that the user specified to be closed.
	
	Returns 0 if OK or an error code.
*/
static int
ClosePortsMarkedForClosing(VDTPortPtr firstVDTPortPtr)
{
	VDTPortPtr dd;
	int firstErr, err;
	
	firstErr = 0;
	dd = firstVDTPortPtr;
	while(dd != NULL) {
		if (dd->portClosedInDialog) {
			err = CloseVDTPort(dd->name);
			if (err != 0) {
				char temp[128];
				snprintf(temp, sizeof(temp), "While closing %s port, the following error occurred: ", dd->name);
				ExplainPortError(temp, err);
				if (firstErr == 0)
					firstErr = err;
			}
		}
		dd = dd->nextPort;
	}

	return firstErr;
}

/*	OpenPortsMarkedForOpening(firstVDTPortPtr)

	Called when the user clicks OK.
	
	Opens communications ports that the user specified to be opened.
	
	Returns 0 if OK or an error code.
*/
static int
OpenPortsMarkedForOpening(VDTPortPtr firstVDTPortPtr)
{
	VDTPortPtr pp, dd;
	int firstErr, err;
	
	firstErr = 0;
	dd = firstVDTPortPtr;
	while(dd != NULL) {
		if (dd->portOpenedInDialog && !dd->portClosedInDialog) {
			err = OpenVDTPort(dd->name, &pp);
			if (err != 0) {
				char temp[128];
				snprintf(temp, sizeof(temp), "While opening %s port, the following error occurred: ", dd->name);
				ExplainPortError(temp, err);
				if (firstErr == 0)
					firstErr = err;
			}
		}
		dd = dd->nextPort;
	}

	return firstErr;
}

/*	UpdateChangedPorts(firstVDTPortPtr)
	
	Called when the user clicks OK.
	
	Carries out changes to ports following changes made by the user during the dialog.
	
	Returns 0 if OK or an error code.
	
	HR, 990415, 2.12: Previously, if the port was opened or closed in the dialog,
	UpdateChangedPorts did not copy the dialog settings (dd->xxx) to the actual
	port settings (pp->xxx). I fixed this by removing tests on dd->portClosedInDialog
	and dd->portOpenedInDialog in the first if statement.
*/
static int
UpdateChangedPorts(VDTPortPtr firstVDTPortPtr)
{
	VDTPortPtr pp, dd;
	int firstErr, err;
	
	firstErr = 0;
	dd = firstVDTPortPtr;
	while(dd != NULL) {
		if (dd->portSettingsChangedInDialog) {		// HR, 990415, 2.12: See note above.
			pp = FindVDTPort(NULL, dd->name);		// Pointer to real VDTPort for this port, not dialog copy.
			if (pp == NULL) {
				err = VDT_ERR_UNKNOWN_PORT_ERR;		// Should not happen.
			}
			else {
				pp->baudCode = dd->baudCode;
				pp->parity = dd->parity;
				pp->stopbits = dd->stopbits;
				pp->databits = dd->databits;
				pp->echo = dd->echo;
				pp->inShake = dd->inShake;
				pp->outShake = dd->outShake;
				pp->terminalEOL = dd->terminalEOL;
				err = SetInputBufferSize(pp, dd->inputBufferSize);
				if (VDTPortIsOpen(pp))
					err = SetCommPortSettings(pp);
			}
			if (err != 0) {
				char temp[128];
				snprintf(temp, sizeof(temp), "While changing settings for %s port, the following error occurred: ", dd->name);
				ExplainPortError(temp, err);
				if (firstErr == 0)
					firstErr = err;
			}
		}
		dd = dd->nextPort;
	}

	return firstErr;
}

/*	InitialPortToSelect(firstVDTPortPtr)

	Returns a VDTPortPtr that indicates which port should be selected
	when the dialog is first displayed.
	
	firstVDTPortPtr will be NULL if there are no functioning communications
	ports. In this case, it will return NULL.
*/
static VDTPortPtr
InitialPortToSelect(VDTPortPtr firstVDTPortPtr)
{
	VDTPortPtr dd;
	
	dd = firstVDTPortPtr;
	while(dd != NULL) {
		if (dd->selectedInDialog != 0)
			return dd;
		dd = dd->nextPort;	
	}
	
	return firstVDTPortPtr;			// Default to first.
}

/*	SetInitialPortToSelectForNextTime(firstVDTPortPtr)
	
	Marks the port that should be initially displayed the next time the
	dialog is invoked.
	
	firstVDTPortPtr will be NULL if there are no functioning communications
	ports.
*/
static void
SetInitialPortToSelectForNextTime(VDTPortPtr firstVDTPortPtr)
{
	VDTPortPtr dd, pp;
	
	dd = firstVDTPortPtr;
	while(dd != NULL) {
		pp = FindVDTPort(NULL, dd->name);
		if (pp != NULL)
			pp->selectedInDialog = dd->selectedInDialog;
		dd = dd->nextPort;	
	}
}

/*	InitDialogStorage(dsp, useExpSettingsIn, useExpSettingsOutPtr)

	We use a DialogStorage structure to store working values during the dialog.
	
	On entry into the dialog, we call BuildVDTPortLinkedList which creates a linked list
	of VDTPorts. This list contains a copies of the settings for each serial port. These
	copies are used to store settings during the dialog so that, if the user cancels,
	we have not modified any actual port settings.
	
	The port field of the DialogStorage structure is used to store settings for the
	port currently selected in the dialog. If the user selects a different port or
	clicks the OK button, the settings are copied from the port field to the appropriate
	settings in the linked list created by BuildVDTPortLinkedList.
	
	If the user clicks OK, we call UpdateChangedPorts which copies the port settings
	created by BuildVDTPortLinkedList to the actual port settings.
*/
int
InitDialogStorage(DialogStorage* dsp, int useExpSettingsIn, int* useExpSettingsOutPtr)
{
	int err;
	
	dsp->useExpSettingsIn = useExpSettingsIn;
	dsp->useExpSettingsOutPtr = useExpSettingsOutPtr;
	dsp->expSettings = useExpSettingsIn;
	
	dsp->portToUseForTerminal = VDTGetTerminalPortPtr();				// May be NULL.
	dsp->portToUseForOperations = VDTGetOperationsPortPtr();			// May be NULL.

	if (err = BuildVDTPortLinkedList(&dsp->firstVDTPortPtr, &dsp->numberOfPortsInList))
		return err;
	// Note that dsp->firstVDTPortPtr will be NULL if no ports exist.
	
	dsp->dd = InitialPortToSelect(dsp->firstVDTPortPtr);		// Will be NULL if dsp->firstVDTPortPtr is NULL.
	if (dsp->dd == NULL)
		dsp->pp = NULL;
	else
		dsp->pp = FindVDTPort(NULL, dsp->dd->name);
	CopyVDTPortFieldsOrGetDefaults(dsp->dd, &dsp->port);		// Uses default values if dd is NULL.

	return 0;
}

/*	ProcessDialogOK(dsp)
	
	Called when the user presses OK in the VDT Settings dialog. Carries outthe user-requested actions.
*/
void
ProcessDialogOK(DialogStorage* dsp)
{
	if (dsp->dd != NULL)
		CopyVDTPortFieldsOrGetDefaults(&dsp->port, dsp->dd);	// Copy settings back to selected port.
	ClosePortsMarkedForClosing(dsp->firstVDTPortPtr);
	OpenPortsMarkedForOpening(dsp->firstVDTPortPtr);
	UpdateChangedPorts(dsp->firstVDTPortPtr);

	VDTSetOperationsPortPtr(dsp->portToUseForOperations);		// OK if NULL.
	VDTSetTerminalPortPtr(dsp->portToUseForTerminal);			// OK if NULL.
		
	*dsp->useExpSettingsOutPtr = dsp->expSettings;
}

void
DisposeDialogStorage(DialogStorage* dsp)
{
	SetInitialPortToSelectForNextTime(dsp->firstVDTPortPtr);
	DisposeVDTPortLinkedList(dsp->firstVDTPortPtr);
}

