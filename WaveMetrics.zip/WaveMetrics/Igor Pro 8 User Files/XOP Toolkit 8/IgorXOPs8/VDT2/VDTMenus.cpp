#include "XOPStandardHeaders.h"			// Include ANSI headers, Mac headers, IgorXOP.h, XOP.h and XOPSupport.h
#include "VDT.h"

static void
CheckPortMenuItems(int portMenuID, int quittingVDT)
{
	XOPMenuRef portMenuRef;
	VDTPortPtr pp;
	char portName[MAX_OBJ_NAME+1];
	char itemText[MAX_OBJ_NAME+1];
	int i, numItems;
	
	portMenuRef = XOPResourceMenuIDToMenuRef(portMenuID);
	if (portMenuRef == NULL)
		return;											// Should never happen.

	if (portMenuID == VDT_TERMINAL_PORT_MENUID)
		pp = VDTGetTerminalPortPtr();					// This may be null.
	else
		pp = VDTGetOperationsPortPtr();					// This may be null.
	if (pp == NULL)
		strcpy(portName, "Off Line");					// Last item in menu is always "Off Line".
	else
		strcpy(portName, pp->name);

	numItems = XOPCountMenuItems(portMenuRef);
	for(i=1; i<=numItems; i++) {
		XOPGetMenuItemText(portMenuRef, i, itemText);
		if (!quittingVDT && CmpStr(itemText,portName)==0)
			XOPCheckMenuItem(portMenuRef, i, 1);
		else
			XOPCheckMenuItem(portMenuRef, i, 0);
	}
}

static void
DoVDTSettingsDialog(void)
{
	extern int gUseExpSettings;
	int useExpSettings;
	
	int numberOfPorts = GetNumberOfCurrentlyRegisteredPorts();
	if (numberOfPorts <= 0) {		// No ports are registered?
		const char* message = "No serial ports are registered with VDT2. " \
								CR_STR CR_STR \
								"Connect a serial port adapter. " \
								"Then choose Reset Serial Ports from the VDT2 submenu.";
		const char* title = "No Serial Ports Are Registered";
		XOPOKAlert(title, message);
		return;
	}
	
	if (VDTSettingsDialog(gUseExpSettings, &useExpSettings) != 0)
		return;
	UpdateStatusArea();
	VDTSettingsModified(1);		// Mark settings to be written to preferences.
	gUseExpSettings = useExpSettings;
}

/*	HandleVDTMenuItemSelected(menuID, itemID, vdtWindow)

	HandleVDTMenuItemSelected is called when user selects XOPs menu item, if it has one.
	
	vdtWindow may be NULL.
*/
int
HandleVDTMenuItemSelected(int menuID, int itemID, IgorWindowRef vdtWindow)
{
	VDTPortPtr tp;
	
	// Make sure to get all XOP items before doing another callback to Igor.
	menuID = (int)GetXOPItem(0);
	itemID = (int)GetXOPItem(1);

	/*	This is another callback to Igor. It would clobber the menuID and itemID if
		we did it before calling GetXOPItem(0) and GetXOPItem(1).
	*/
	menuID = ActualToResourceMenuID(menuID);
	
	tp = NULL;
	
	if (menuID == VDT_MENUID) {					// Main menu?
		switch (itemID) {
			case VDT_ITEM_OPEN_VDT_WINDOW:
				if (vdtWindow != NULL)
					ShowAndActivateIgorWindow(vdtWindow);
				break;
			
			case VDT_ITEM_SETTINGS_DIALOG:
				DoVDTSettingsDialog();
				break;
			
			case VDT_ITEM_SAVEFILE:
				VDTSaveText();
				break;
			
			case VDT_ITEM_INSERTFILE:
				VDTInsertText();
				break;
			
			case VDT_ITEM_SENDFILE:
				VDTGetOpenAndCheckTerminalPortPtr(&tp, 1);		// tp may be null.
				if (tp == NULL)
					break;						// No terminal port is selected or other error.
				if (tp->terminalOp == OP_SENDFILE)
					VDTAbortTerminalOperation();
				else
					VDTSendFile();
				break;
			
			case VDT_ITEM_RECEIVEFILE:
				VDTGetOpenAndCheckTerminalPortPtr(&tp, 1);		// tp may be null.
				if (tp == NULL)
					break;						// No terminal port is selected or other error.
				if (tp->terminalOp == OP_RECEIVEFILE)
					VDTAbortTerminalOperation();
				else
					VDTReceiveFile();
				break;
			
			case VDT_ITEM_SENDTEXT:
				VDTGetOpenAndCheckTerminalPortPtr(&tp, 1);		// tp may be null.
				if (tp == NULL)
					break;						// No terminal port is selected or other error.
				if (tp->terminalOp == OP_SENDTEXT)
					VDTAbortTerminalOperation();
				else
					VDTSendText();
				break;
			
			case VDT_ITEM_RESET_SERIAL_PORTS:
				{
					const char* message = "Resetting ports terminates any VDT2 serial I/O, " \
											"closes any ports opened by VDT2, " \
											"rescans for available serial ports, " \
											"and re-initializes all VDT2 port settings to default values." \
											CR_STR CR_STR \
											"Reset all serial ports?";
					const char* title = "Reset Serial Ports";
					int result = XOPOKCancelAlert(title, message);
					if (result < 0)
						break;					// Cancel
					ResetVDTPorts();
				}
				break;
			
			case VDT_ITEM_HELP:
				XOPDisplayHelpTopic("", "VDT2 - Serial Port Support", 0);
				break;
		}
	}

	// Handle selection in Terminal Port menu or Operations Port menu.
	while (menuID==VDT_TERMINAL_PORT_MENUID || menuID==VDT_OPERATIONS_PORT_MENUID) {
		VDTPortPtr pp;
		XOPMenuRef portMenuRef;
		char itemText[MAX_OBJ_NAME+1];
		
		portMenuRef = XOPResourceMenuIDToMenuRef(menuID);
		if (portMenuRef == NULL)
			break;										// Should never happen.
		XOPGetMenuItemText(portMenuRef, itemID, itemText);
		pp = FindVDTPort(NULL, itemText);				// This will be NULL if user chose Off Line.
		if (menuID == VDT_TERMINAL_PORT_MENUID)
			VDTSetTerminalPortPtr(pp);					// OK if pp is NULL.
		else
			VDTSetOperationsPortPtr(pp);				// OK if pp is NULL.
		CheckPortMenuItems(menuID, 0);
		if (pp != NULL) {
			int err;
			err = OpenVDTPort(itemText, &pp);			// Does nothing if port is already open.
			if (err != 0) {
				char temp[256];

				if (menuID == VDT_TERMINAL_PORT_MENUID)
					VDTSetTerminalPortPtr(NULL);
				else
					VDTSetOperationsPortPtr(NULL);

				snprintf(temp, sizeof(temp), "While trying to open the %s port", itemText);
				ExplainPortError(temp, err);
			}
		}
		VDTSettingsModified(1);		// So that new port assignment will be written to Igor Prefs file
		
		break;
	}

	return 0;
}

/*	FillPortMenu(mH, includeOffLine)

	Fills the menu with list of the ports that we found to be installed at runtime.
	If includeOffLine is true, it includes a separator plus "Off Line".
*/
static void
FillPortMenu(XOPMenuRef menuRef, int includeOffLine)
{
	VDTPortPtr pp;
	int index;
	
	XOPDeleteMenuItemRange(menuRef, 1, 10000);	// Delete all items.
	index = 0;
	do {
		pp = IndexedVDTPort(NULL, index);
		if (pp == NULL)
			break;
		XOPAppendMenuItem(menuRef, pp->name);
		index += 1;
	} while(1);
	
	if (includeOffLine)
		XOPAppendMenuItem(menuRef, "-");		// Append the separator.
	XOPAppendMenuItem(menuRef, "Off Line");
}

void
FillPortMenus(void)
{
	/*	Fill the terminal port menu and the operations port menu with list of the ports
		that InitVDT found to be installed.
	*/
	{
		XOPMenuRef terminalPortMenuRef, operationsPortMenuRef;
		
		terminalPortMenuRef = XOPResourceMenuIDToMenuRef(VDT_TERMINAL_PORT_MENUID);
		if (terminalPortMenuRef != NULL)		// Should never be NULL.
			FillPortMenu(terminalPortMenuRef, 1);
		
		operationsPortMenuRef = XOPResourceMenuIDToMenuRef(VDT_OPERATIONS_PORT_MENUID);
		if (operationsPortMenuRef != NULL)		// Should never be NULL.
			FillPortMenu(operationsPortMenuRef, 1);
	}
}

/*	SetVDTMenuItems(vdtWindow, vdtTU)

	Sets VDT menu items according to current conditions.
*/
void
SetVDTMenuItems(IgorWindowRef vdtWindow, Handle vdtTU)
{
	VDTPortPtr tp;
	XOPMenuRef vdtMenuRef;
	int menuID, itemID;
	char text[80];
	int isActive;
	int terminalIsOnline, terminalOp;
	
	isActive = IsIgorWindowActive(vdtWindow);
	if (isActive) {										// If XOP is front window
		TUFixEditMenu(vdtTU);
		TUFixFileMenu(vdtTU);
		SetIgorMenuItem(kXOPWindowMessageMoveToPreferredPosition, 1, NULL, 0);
		SetIgorMenuItem(kXOPWindowMessageMoveToFullPosition, 1, NULL, 0);
		SetIgorMenuItem(kXOPWindowMessageRetrieveWindow, 1, NULL, 0);
	}
	menuID = MISCID;									// Main VDT item is in Igor Misc menu.
	itemID = ResourceToActualItem(MISCID, 1);			// Ask Igor which item VDT item is.
	vdtMenuRef = XOPResourceMenuIDToMenuRef(VDT_MENUID);
	if (vdtMenuRef == NULL)
		return;											// Should never happen.

	// VDT_ITEM_OPEN_VDT_WINDOW item is always enabled.

	// VDT_ITEM_SETTINGS_DIALOG item is always enabled.

	// VDT_ITEM_TERMINAL_PORT_MENU item is always enabled. Also, all items in the VDT Operations submenu are always enabled.
	CheckPortMenuItems(VDT_TERMINAL_PORT_MENUID, 0);
	
	tp = VDTGetTerminalPortPtr();						// This may be null.
	terminalIsOnline = tp != NULL;
	terminalOp = tp ? tp->terminalOp:0;

	if (isActive && !terminalIsOnline) {
		XOPEnableMenuItem(vdtMenuRef, VDT_ITEM_SAVEFILE);
		XOPEnableMenuItem(vdtMenuRef, VDT_ITEM_INSERTFILE);
	}
	else {
		XOPDisableMenuItem(vdtMenuRef, VDT_ITEM_SAVEFILE);
		XOPDisableMenuItem(vdtMenuRef, VDT_ITEM_INSERTFILE);
	}
	
	// Set "Send File" menu item (VDT_ITEM_SENDFILE).
	if (terminalOp == OP_SENDFILE)
		GetXOPIndString(text, VDT_MISCSTR_ID, STOP_SENDING_FILE);
	else
		GetXOPIndString(text, VDT_MISCSTR_ID, SEND_FILE);
	XOPSetMenuItemText(vdtMenuRef, VDT_ITEM_SENDFILE, text);
	if (tp!=NULL && (terminalOp==OP_SENDFILE || terminalOp==0))
		XOPEnableMenuItem(vdtMenuRef, VDT_ITEM_SENDFILE);
	else
		XOPDisableMenuItem(vdtMenuRef, VDT_ITEM_SENDFILE);
	
	// Set "Receive File" menu item (VDT_ITEM_RECEIVEFILE).
	if (terminalOp == OP_RECEIVEFILE)
		GetXOPIndString(text, VDT_MISCSTR_ID, STOP_RECEIVING_FILE);
	else
		GetXOPIndString(text, VDT_MISCSTR_ID, RECEIVE_FILE);
	XOPSetMenuItemText(vdtMenuRef, VDT_ITEM_RECEIVEFILE, text);
	if (tp!=NULL && (terminalOp==OP_RECEIVEFILE || terminalOp==0))
		XOPEnableMenuItem(vdtMenuRef, VDT_ITEM_RECEIVEFILE);
	else
		XOPDisableMenuItem(vdtMenuRef, VDT_ITEM_RECEIVEFILE);
	
	// Set "Send Text" menu item (VDT_ITEM_SENDTEXT).
	if (terminalOp == OP_SENDTEXT) {
		GetXOPIndString(text, VDT_MISCSTR_ID, STOP_SENDING_TEXT);
	}
	else {
		if (VDTNoCharactersSelected())
			GetXOPIndString(text, VDT_MISCSTR_ID, SEND_VDT_TEXT);
		else
			GetXOPIndString(text, VDT_MISCSTR_ID, SEND_SELECTED_TEXT);
	}
	XOPSetMenuItemText(vdtMenuRef, VDT_ITEM_SENDTEXT, text);
	if (tp!=NULL && (terminalOp==OP_SENDTEXT || terminalOp==0))
		XOPEnableMenuItem(vdtMenuRef, VDT_ITEM_SENDTEXT);
	else
		XOPDisableMenuItem(vdtMenuRef, VDT_ITEM_SENDTEXT);

	// VDT_ITEM_OPERATIONS_PORT_MENU item is always enabled. Also, all items in the VDT Operations submenu are always enabled.
	CheckPortMenuItems(VDT_OPERATIONS_PORT_MENUID, 0);

	// VDT_ITEM_TERMINAL_PORT_MENU item is always enabled.

	// VDT_ITEM_RESET_SERIAL_PORTS item is always enabled.
	
	XOPEnableMenuItem(vdtMenuRef, VDT_ITEM_HELP);
}

