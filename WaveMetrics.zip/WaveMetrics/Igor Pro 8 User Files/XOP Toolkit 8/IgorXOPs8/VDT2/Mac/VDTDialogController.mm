#import "VDTDialogController.h"

/*	Cocoa Dialog Notes

	The VDT dialog is defined in a nib file as is the practice in Cocoa.

	The VDT dialog is invoked from C++ by calling the VDTDialog routine.
	VDTDialog creates a VDTDialogLoader Objective-C object.
	The VDTDialogLoader loads the nib. The act of loading the nib creates
	the VDTDialogController. The VDTDialogController runs the dialog.
	
	We need the VDTDialogLoader because we need an Objective-C object to load
	the nib. The VDTDialogController cannot load the nib because it is created
	by loading the nib. The VDTDialogController *must* be created by loading the
	nib because this is what sets the VDTDialogController outlets to point to
	the dialog window and to the various controls in the dialog. The VDTDialogController
	object uses these pointers to get and set dialog settings.
	
	We use the old-fashioned Objective-C retain/release memory management because the
	newer ARC (automatic reference counting) technique is not supported in 32 bits.
	If you do not plan to support 32 bits in your XOP, you can switch to ARC. See
	Apple's "Transitioning to ARC" document. If you do this, you can get rid of the 
	instance variables (e.g., _dialogWindow), defined in VDTDialogController.h,
	since these are needed for 32 bits only.

	The VDTDialogController object is wired as the dialog window's delegate in the nib.
	This means that the window object will send messages to the VDTDialogController object
	giving it the opportunity to customize the behavior of the window, if the VDTDialogController
	object implements the appropriate methods. windowShouldClose is an example of an implemented
	delegate method.
	
	The VDTDialogController object is wired as each NSTextView control's delegate in the nib.
	controlDidChange is an example of an implemented delegate method. This is what allows us
	to update the VDT command each time the user types in an NSTextView control.
	This is needed because NSTextViews normally do not send action messages until the user
	presses return but we need to know about changes each time the user changes the text
	so that we can update the dialog's command box.

	Setting the tab order is surprisingly difficult. See
		http://www.cocoabuilder.com/archive/cocoa/298020-how-to-set-tab-order-in-window-that-has-view-swapping.html
	Because of this I am punting and allowing Cocoa to set the tab order, even though
	it is not optimal.
*/

DialogPositionAndSize gDialogPositionAndSize = {0};

@interface VDTDialogController ()

@end

@implementation VDTDialogController

@synthesize dialogWindow = _dialogWindow;
@synthesize portPopup = _portPopup;
@synthesize portCurrentlyClosedTextField = _portCurrentlyClosedTextField;
@synthesize portCurrentlyOpenTextField = _portCurrentlyOpenTextField;
@synthesize openThisPortCheckbox = _openThisPortCheckbox;
@synthesize closeThisPortCheckbox = _closeThisPortCheckbox;
@synthesize portWillBeClosedTextField = _portWillBeClosedTextField;
@synthesize portWillBeOpenedTextField = _portWillBeOpenedTextField;
@synthesize useThisPortForTerminalOperationsCheckbox = _useThisPortForTerminalOperationsCheckbox;
@synthesize useThisPortForCommandLineOperationsCheckbox = _useThisPortForCommandLineOperationsCheckbox;
@synthesize baudRatePopup = _baudRatePopup;
@synthesize dataLengthPopup = _dataLengthPopup;
@synthesize stopBitsPopup = _stopBitsPopup;
@synthesize parityPopup = _parityPopup;
@synthesize localEchoPopup = _localEchoPopup;
@synthesize terminalEOLPopup = _terminalEOLPopup;
@synthesize inputHandshakingPopup = _inputHandshakingPopup;
@synthesize outputHandshakingPopup = _outputHandshakingPopup;
@synthesize saveSetupWithExperimentCheckbox = _saveSetupWithExperimentCheckbox;
@synthesize okButton = _okButton;
@synthesize cancelButton = _cancelButton;

- (void)windowDidLoad {
    [super windowDidLoad];
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
}

- (BOOL)windowShouldClose:(id)sender {						// From NSWindowDelegate protocol
	/*	This is called when the user clicks the close box but not when the user
		clicks the OK or Cancel button. If we return YES here the dialog is hidden
		but not deallocated. Furthermore, it does not terminate the modal loop.
		Therefore we can not allow the user to close the dialog this way. He must
		click OK or Cancel. This will not actually be called because we have disabled
		the close control using the window's attributes in the nib. This routine
		would be needed only if the close control were enabled.
	*/
	// NSLog(@"windowShouldClose");
	return NO;						// Prevents close box from killing window
}

- (void)windowWillClose:(NSNotification*)notification {		// From NSWindowDelegate protocol
	/*	This is called when the user clicks the close box but not when the user
		clicks the OK or Cancel button.
	*/
	// NSLog(@"windowWillClose");
}

- (void)controlTextDidChange:(NSNotification*)notification		// Called by NSTextView controls
{
	// NSLog(@"controlTextDidChange");
	// We don't need to do this because this dialog does not need to do anything until the user clicks OK
}

- (IBAction)okButtonClicked:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	ProcessDialogOK(dsp);
    [NSApp stopModal];
}

- (IBAction)cancelButtonClicked:(id)sender {
	// NSLog(@"Cancel button clicked");
	self->dialogResult = -1;
    [NSApp stopModal];
}

- (IBAction)portSelected:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int zeroBasedMenuItemIndex = (int)[ self.portPopup indexOfSelectedItem ];
	SetCurrentDialogPort(zeroBasedMenuItemIndex+1, dsp);
	[ self updateDialog ];
}

- (IBAction)openPortCheckboxClicked:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	VDTPort* port = &dsp->port;
	int val = [ self.openThisPortCheckbox intValue ];
	port->portOpenedInDialog = (short)val;
	[ self setOpenAndClosedItems:port ];
}

- (IBAction)closePortCheckboxClicked:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	VDTPort* port = &dsp->port;
	int val = [ self.closeThisPortCheckbox intValue ];
	port->portClosedInDialog = (short)val;
	[ self setOpenAndClosedItems:port ];
}

- (IBAction)terminalPortCheckboxClicked:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int val = [ self.useThisPortForTerminalOperationsCheckbox intValue ];
	if (val)
		dsp->portToUseForTerminal = dsp->pp;		// May be NULL
	else
		dsp->portToUseForTerminal = NULL;			// No port selected as terminal port
}

- (IBAction)operationsPortCheckboxClicked:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int val = [ self.useThisPortForCommandLineOperationsCheckbox intValue ];
	if (val)
		dsp->portToUseForOperations = dsp->pp;		// May be NULL
	else
		dsp->portToUseForOperations = NULL;			// No port selected as operations port
}

- (IBAction)baudRateSelected:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int zeroBasedMenuItemIndex = (int)[ self.baudRatePopup indexOfSelectedItem ];
	dsp->port.baudCode = (unsigned short)zeroBasedMenuItemIndex;
	dsp->port.portSettingsChangedInDialog = 1;
}

- (IBAction)dataLengthSelected:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int zeroBasedMenuItemIndex = (int)[ self.dataLengthPopup indexOfSelectedItem ];
	dsp->port.databits = (unsigned short)zeroBasedMenuItemIndex;
	dsp->port.portSettingsChangedInDialog = 1;
}

- (IBAction)stopBitsSelected:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int zeroBasedMenuItemIndex = (int)[ self.stopBitsPopup indexOfSelectedItem ];
	dsp->port.stopbits = (unsigned short)zeroBasedMenuItemIndex;
	dsp->port.portSettingsChangedInDialog = 1;
}

- (IBAction)paritySelected:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int zeroBasedMenuItemIndex = (int)[ self.parityPopup indexOfSelectedItem ];
	dsp->port.parity = (unsigned short)zeroBasedMenuItemIndex;
	dsp->port.portSettingsChangedInDialog = 1;
}

- (IBAction)localEchoSelected:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int zeroBasedMenuItemIndex = (int)[ self.localEchoPopup indexOfSelectedItem ];
	dsp->port.echo = (unsigned short)zeroBasedMenuItemIndex;
	dsp->port.portSettingsChangedInDialog = 1;
}

- (IBAction)terminalEOLSelected:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int zeroBasedMenuItemIndex = (int)[ self.terminalEOLPopup indexOfSelectedItem ];
	dsp->port.terminalEOL = (unsigned short)zeroBasedMenuItemIndex;
	dsp->port.portSettingsChangedInDialog = 1;
}

- (IBAction)inputHandshakeSelected:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int zeroBasedMenuItemIndex = (int)[ self.inputHandshakingPopup indexOfSelectedItem ];
	dsp->port.inShake = (unsigned short)zeroBasedMenuItemIndex;
	dsp->port.portSettingsChangedInDialog = 1;
}

- (IBAction)outputHandshakeSelected:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int zeroBasedMenuItemIndex = (int)[ self.outputHandshakingPopup indexOfSelectedItem ];
	dsp->port.outShake = (unsigned short)zeroBasedMenuItemIndex;
	dsp->port.portSettingsChangedInDialog = 1;
}

- (IBAction)saveSetupWithExpCheckboxClicked:(id)sender {
	DialogStorage* dsp = self->dialogStoragePtr;
	int val = [ self.saveSetupWithExperimentCheckbox intValue ];
	dsp->expSettings = val;
}

- (void)fillPortPopup
{
	VDTPortPtr pp;
	int index;
	
	[ [self portPopup] removeAllItems ];
	
	index = 0;
	do {
		pp = IndexedVDTPort(NULL, index);
		if (pp == NULL)
			break;
		NSString* itemText = [ NSString stringWithUTF8String:pp->name ];	// Auto-released
		[ [self portPopup] addItemWithTitle:itemText ];
		index += 1;
	} while(1);
	
	[ [self portPopup] selectItemAtIndex:0 ];
}

- (void)initializeDialog
{
	[ self fillPortPopup ];
	
	[ self updateDialog ];
}

- (void)setOpenAndClosedItems:(VDTPortPtr)port				// port may be NULL
{
	bool portIsOpen = port!=NULL && port->portIsOpen;
	if (portIsOpen) {										// Port is open?
		[ self.portCurrentlyOpenTextField setHidden:NO ];
		[ self.portCurrentlyClosedTextField setHidden:YES ];

		[ self.openThisPortCheckbox setHidden:YES ];
		[ self.closeThisPortCheckbox setHidden:NO ];

		if (port->portClosedInDialog)
			[ self.portWillBeClosedTextField setHidden:NO ];
		else
			[ self.portWillBeClosedTextField setHidden:YES ];
		[ self.portWillBeOpenedTextField setHidden:YES ];
	}
	else {
		[ self.portCurrentlyOpenTextField setHidden:YES ];
		[ self.portCurrentlyClosedTextField setHidden:NO ];

		[ self.openThisPortCheckbox setHidden:NO ];
		[ self.closeThisPortCheckbox setHidden:YES ];

		if (port->portOpenedInDialog)
			[ self.portWillBeOpenedTextField setHidden:NO ];
		else
			[ self.portWillBeOpenedTextField setHidden:YES ];
		[ self.portWillBeClosedTextField setHidden:YES ];

	}
	
	int checkboxState = port!=NULL && port->portOpenedInDialog;
	[ self.openThisPortCheckbox setIntValue:checkboxState ];
	
	checkboxState = port!=NULL && port->portClosedInDialog;
	[ self.closeThisPortCheckbox setIntValue:checkboxState ];
}

/*	SetTerminalAndOperationsCheckboxes(dd, tp, op)
	
	dd identifies the port selected in the dialog. It will be NULL if no ports are available.
	
	tp identifies the port selected as terminal port. It will be NULL if no port is selected.
	
	op identifies the port selected as operations port. It will be NULL if no port is selected.
*/
- (void)setTerminalAndOperationsCheckboxes:(VDTPortPtr)dd terminalPortPtr:(VDTPortPtr)tp operationsPortPtr:(VDTPortPtr)op
{
	int tpState, opState;
	
	if (dd == NULL) {
		tpState = 0;
		opState = 0;
	}
	else {
		if (tp == NULL)
			tpState = 0;
		else
			tpState = CmpStr(tp->name, dd->name) == 0;
	
		if (op == NULL)
			opState = 0;
		else
			opState = CmpStr(op->name, dd->name) == 0;
	}

	[ self.useThisPortForTerminalOperationsCheckbox setIntValue:tpState ];
	[ self.useThisPortForCommandLineOperationsCheckbox setIntValue:opState ];
}

- (void)updateDialog			// Sets dialog controls based on dsp->port
{
	DialogStorage* dsp = self->dialogStoragePtr;
	VDTPortPtr port = &dsp->port;

	[ self.saveSetupWithExperimentCheckbox setIntValue:dsp->useExpSettingsIn ];

	NSString* portNameStr = [ NSString stringWithUTF8String:port->name ];	// Auto-released
	[ self.portPopup selectItemWithTitle:portNameStr];
	
	int zeroBasedMenuItemIndex = port->baudCode;							// 0, 1, ... see baudRateInfo
	[ self.baudRatePopup selectItemAtIndex:zeroBasedMenuItemIndex ];

	zeroBasedMenuItemIndex = port->databits;
	[ self.dataLengthPopup selectItemAtIndex:zeroBasedMenuItemIndex ];

	zeroBasedMenuItemIndex = port->stopbits;
	[ self.stopBitsPopup selectItemAtIndex:zeroBasedMenuItemIndex ];

	zeroBasedMenuItemIndex = port->parity;
	[ self.parityPopup selectItemAtIndex:zeroBasedMenuItemIndex ];

	zeroBasedMenuItemIndex = port->echo;
	[ self.localEchoPopup selectItemAtIndex:zeroBasedMenuItemIndex ];

	zeroBasedMenuItemIndex = port->inShake;
	[ self.inputHandshakingPopup selectItemAtIndex:zeroBasedMenuItemIndex ];

	zeroBasedMenuItemIndex = port->outShake;
	[ self.outputHandshakingPopup selectItemAtIndex:zeroBasedMenuItemIndex ];

	zeroBasedMenuItemIndex = port->terminalEOL;
	[ self.terminalEOLPopup selectItemAtIndex:zeroBasedMenuItemIndex ];
	
	[ self setOpenAndClosedItems:&dsp->port ];
	
	[ self setTerminalAndOperationsCheckboxes:&dsp->port terminalPortPtr:dsp->portToUseForTerminal operationsPortPtr:dsp->portToUseForOperations ];
}

- (int)runModalDialog:(DialogStorage*)dsp
{
	self->dialogStoragePtr = dsp;
	self->dialogResult = 0;
	
	[ self initializeDialog ];

	RestoreDialogPositionAndSize(self.dialogWindow, &gDialogPositionAndSize);
	
	NSWindow* window = [ self dialogWindow ];
    [ window makeKeyAndOrderFront:nil ];
    [ NSApp runModalForWindow:window ];
    [ window orderOut:nil ];
	
	GetDialogPositionAndSize(self.dialogWindow, &gDialogPositionAndSize);
	VDTSettingsModified(1);		// Because gDialogPositionAndSize is stored in VDT settings
	
	int result = self->dialogResult;
	return result;
}

- (void)dealloc
{
	// NSLog(@"VDTDialogController dealloc called");
	[ _dialogWindow release ];
	[ super dealloc ];
}

@end


/*	VDTDialogLoader

	The VDTDialogController object runs the dialog. In order to create it
	and to wire it to the dialog window and controls, as specified in the nib,
	we need another object to load the nib. The VDTDialogController cannot
	load the nib because it is created by loading the nib.
	
	The VDTDialogLoader is this other object. We manually create the VDTDialogLoader
	object. This creates the VDTDialogController object and sets the dialogController member
	of the VDTDialogLoader to point to the new VDTDialogController object.
	
	The loading of the nib also makes all of the connections wired in the nib between
	the VDTDialogController and the dialog window and its controls.
*/
@implementation VDTDialogLoader

@synthesize dialogController = _dialogController;

- (void)dealloc
{
	// NSLog(@"VDTDialogLoader dealloc called");
	[ _dialogController release ];
	[ super dealloc ];
}

-(int)runVDTDialog:(DialogStorage*)dsp {	// Loads dialog from nib and runs it
	/*	These identifiers must agree with the identifiers that you enter in the
		Bundle Identifier field of the XOP's Info.plist or Info64.plist file.
		They are case-sensitive.
	*/
	#ifdef __LP64__
		NSString* bundleIdentifier = @"com.wavemetrics.xops.dataacquisition.vdt2-64";	// Must agree with Info64.plist
	#else
		NSString* bundleIdentifier = @"com.wavemetrics.xops.dataacquisition.vdt2";		// Must agree with Info.plist
	#endif
	[ bundleIdentifier autorelease ];

	// Find the XOP bundle (the WindowXOP1.xop folder)
	NSBundle* xopBundle = [ NSBundle bundleWithIdentifier:bundleIdentifier ];	// xopBundle is autoreleased
	if (xopBundle == nil) {
		XOPNotice("Can't find VDT2 bundle - check the identifier passed to bundleWithIdentifier" CR_STR);
		return GENERAL_BAD_VIBS;
	}
	
	// Connect to the nib (VDT2.xop/Contents/Resources/VDT2.nib or 64-bit equivalent)
	NSNib* aNib = [[NSNib alloc] initWithNibNamed:@"VDTDialog" bundle:xopBundle];
	if (aNib == nil) {
		XOPNotice("VDT2 initWithNibNamed failed");
		return GENERAL_BAD_VIBS;
	}
	
	// Load the nib
	NSArray* topLevelObjects = nil;
	if ([aNib instantiateNibWithOwner:self topLevelObjects:&topLevelObjects] == NO) {
		XOPNotice("VDT2 instantiateNibWithOwner failed");
		[aNib release];
		return GENERAL_BAD_VIBS;
	}
	
	// Release the raw nib data.
	[aNib release];

	VDTDialogController* dialogController = [ self dialogController ];
	dialogController->saveExperimentSettings = self->saveExperimentSettings;
	int result = [ dialogController runModalDialog:dsp ];
	self->saveExperimentSettings = dialogController->saveExperimentSettings;

	/*	Apple's "Resource Programming Guide" says:
			For historical reasons, in OS X the top-level objects in a nib file
			are created with an additional reference count
		and prescribes this next statement.
	*/
	[topLevelObjects makeObjectsPerformSelector:@selector(release)];
	// topLevelObjects is autoreleased by instantiateNibWithOwner
	
	return result;
}

@end

int
VDTSettingsDialog(int useExpSettingsIn, int* useExpSettingsOutPtr)	// Returns 0 if OK, -1 if cancel, or error code
{
	DialogStorage ds;
	int result = 0;

	*useExpSettingsOutPtr = useExpSettingsIn;
	if (result = InitDialogStorage(&ds, useExpSettingsIn, useExpSettingsOutPtr))
		return result;

	VDTDialogLoader* loader = [ [ VDTDialogLoader alloc ] init ];	// Retains loader
	result = [ loader runVDTDialog:&ds ];
	[ loader release ];												// Balance alloc retain
	
	DisposeDialogStorage(&ds);
	
	return result;
}
