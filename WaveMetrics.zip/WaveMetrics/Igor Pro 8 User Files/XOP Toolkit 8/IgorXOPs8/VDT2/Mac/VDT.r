#include "XOPStandardHeaders.r"

resource 'vers' (1) {						/* XOP version info */
	0x02, 0x20, release, 0x00, 0,			/* version bytes and country integer */
	"2.20",
	"2.20, Copyright 2002-2018 WaveMetrics, Inc., all rights reserved."
};

resource 'vers' (2) {						/* Igor version info */
	0x08, 0x00, release, 0x00, 0,			/* version bytes and country integer */
	"8.00",
	"(for Igor 8.00 or later)"
};

resource 'STR#' (1100) {					/* custom error messages */
	{
		/* [1] */
		"VDT2 unable to open window",		/* can't open window on initialization */
		/* [2] */
		"Invalid baud rate",
		/* [3] */
		"Data bits must be 7 or 8",
		/* [4] */
		"Stop bits must be 1 or 2",
		/* [5] */
		"Parity is 0 for none, 1 for odd, 2 for even",
		/* [6] */
		"Handshake is 0 for none, 1 for CTS, 2 for XON/XOFF",
		/* [7] */
		"Echo is 0 for off, 1 for on",
		/* [8] */
		"Port is 0 for modem, 1 for printer",
		/* [9] */
		"Buffer size must be at least 32 bytes",
		/* [10] */
		"The port is busy",
		/* [11] */
		"The port could not be initialized",
		/* [12] */
		"There is not enough memory for the input buffer",
		/* [13] */
		"No port is selected",
		/* [14] */
		"Another VDT2 operation is in progress",
		/* [15] */
		"The numeric format must end with a valid numeric conversion character.",
		/* [16] */
		"Not used.",
		/* [17] */
		"Not used.",
		/* [18] */
		"This version of VDT2 requires Igor version 8.00 or later",
		/* [19] */
		"Can't do VDTBinaryWaveRead2 or VDTBinaryWaveWrite2 on a text wave. Use VDTWaveRead2 or VDTWaveWrite2.",
		/* [20] */
		"The channel number must be 0 (for the input port) or 1 (for the output port).",
		/* [21] */
		"The status code must be between 0 and 6.",
		/* [22] */
		"Break detected.",
		/* [23] */
		"No parallel device is selected.",
		/* [24] */
		"A framing error occurred (check baud rate, parity, stop bits).",
		/* [25] */
		"An I/O error occurred.",
		/* [26] */
		"Mode error.",
		/* [27] */
		"Parallel device is out of paper.",
		/* [28] */
		"Overrun error - too many characters received or sent to fit in buffer.",
		/* [29] */
		"Parallel port timeout.",
		/* [30] */
		"Input overrun error - too many characters received to fit in input buffer.",
		/* [31] */
		"A parity error occurred (check baud rate, parity, stop bits).",
		/* [32] */
		"Input overrun error - too many characters sent to fit in output buffer.",
		/* [33] */
		"An communications error of unknown nature occurred.",
		/* [34] */
		"Unknown port name.",
		/* [35] */
		"No port is selected for command line operations. Commands will not work until you select a port.",
		/* [36] */
		"No port is selected for terminal operations. Terminal operations will not work until you select a port.",
		/* [37] */
		"Expected the name of an installed port (such as Printer, Modem, COM1, COM2).",
		/* [38] */
		"Expected the name of an installed port (such as Printer, Modem, COM1, COM2) or 'None'.",
		/* [39] */
		"The specified port is not available on this machine.",
		/* [40] */
		"Expect 0 (CR), 1 (LF), or 2 (CRLF) for terminalEOL.",
		/* [41] */
		"The port can't be opened. This machine may not have the specified port or may not be configured to use the port.",
		/* [42] */
		"The port appears to be in use by another program.",
		/* [43] */
		"This baud rate is not supported on Macintosh.",
		/* [44] */
		"A UNIX-related error occurred. See the history for diagnostics.",
		/* [45] */
		"A system-related error occurred. See the history for diagnostics.",
		/* [46] */
		"Bad binary data type. Codes are the same as those used for the WaveType function.",
		/* [47] */
		"Serial reads are limited to 4 billion bytes at a time.",
		/* [48] */
		"Serial writes are limited to 4 billion bytes at a time.",
	}
};

resource 'STR#' (1101) {					// Misc strings that Igor looks for.
	{
		/* [1] */
		"-1",								// This item is no longer supported by the Carbon XOP Toolkit.
		/* [2] */
		"---"		,						// This item is no longer supported by the Carbon XOP Toolkit.
		/* [3] */
		"VDT2 Help",						// Name of XOP's help file.
	}
};

/* Balloon strings for "VDT2" item */
resource 'STR#' (1110, "VDT2") {
	{
		/* [1] (used when menu item is enabled) */
		"VDT2 == �Very Dumb Terminal�.\n\n"
		"In addition to dumb terminal emulation, the VDT2 external operation adds command "
		"line operations to Igor for setting up serial ports and for transfering data "
		"to and from serial ports.",
		
		/* [2] (used when menu item is disabled) */
		"",
		
		/* [3] (used when menu item is checked) */
		"",
		
		/* [4] (used when menu item is marked) */
		"",
	}
};

resource 'STR#' (1102) {					// Misc strings private to VDT2.
	{
		/* [1] */
		"Send VDT2 Text",
		/* [2] */
		"Send Selected Text",				// Alternate to "Send VDT2 Text" menu item.
		/* [3] */
		"Stop Sending Text",				// Alternate to "Send VDT2 Text" menu item.
		/* [4] */
		"Send File...",
		/* [5] */
		"Stop Sending File",				// Alternate to "Send File..." menu item.
		/* [6] */
		"Receive File...",
		/* [7] */
		"Stop Receiving File",				// Alternate to "Receive File..." menu item.
		/* [8] */
		"Error opening file",
	}
};

resource 'XOPI' (1100) {
	XOP_VERSION,							// XOP protocol version.
	DEV_SYS_CODE,							// Code for development system used to make XOP
	XOP_FEATURE_FLAGS,						// Tells Igor about XOP features
	XOPI_RESERVED,							// Reserved - must be zero.
	XOP_TOOLKIT_VERSION,					// XOP Toolkit version.
};

resource 'XOPC' (1100) {					/* commands added by XOP */
	{
		"VDT2",								/* name of operation */
		XOPOp+UtilOP+compilableOp,			/* operation's category */

		"VDTRead2",
		XOPOp+UtilOP+compilableOp,

		"VDTWrite2",
		XOPOp+UtilOP+compilableOp,

		"VDTReadWave2",
		XOPOp+UtilOP+compilableOp,

		"VDTWriteWave2",
		XOPOp+UtilOP+compilableOp,

		"VDTReadBinary2",
		XOPOp+UtilOP+compilableOp,

		"VDTWriteBinary2",
		XOPOp+UtilOP+compilableOp,

		"VDTReadBinaryWave2",
		XOPOp+UtilOP+compilableOp,

		"VDTWriteBinaryWave2",
		XOPOp+UtilOP+compilableOp,

		"VDTReadHex2",
		XOPOp+UtilOP+compilableOp,

		"VDTWriteHex2",
		XOPOp+UtilOP+compilableOp,

		"VDTReadHexWave2",
		XOPOp+UtilOP+compilableOp,

		"VDTWriteHexWave2",
		XOPOp+UtilOP+compilableOp,

		"VDTGetStatus2",					// Added 9/9/96 in version 1.31.
		XOPOp+UtilOP+compilableOp,

		"VDTOpenPort2",						// Added 9/29/97 in version 2.00.
		XOPOp+UtilOP+compilableOp,

		"VDTClosePort2",					// Added 9/29/97 in version 2.00.
		XOPOp+UtilOP+compilableOp,

		"VDTTerminalPort2",					// Added 9/29/97 in version 2.00.
		XOPOp+UtilOP+compilableOp,

		"VDTOperationsPort2",				// Added 9/29/97 in version 2.00.
		XOPOp+UtilOP+compilableOp,

		"VDTGetPortList2",					// Added 10/5/97 in version 2.00.
		XOPOp+UtilOP+compilableOp,
	}
};

// Description of menu items added to built-in Igor menus.
resource 'XMI1' (1100) {
	{
		8,							// Add item to menu with ID=8 (Misc menu).
		"VDT2",						// This is text for added menu item.
		100,						// This item has a submenu with resourceID==100.
		0,							// Flags field.
	}
};

// Description of submenus added to XOP menus.
resource 'XSM1' (1100) {
	{								// 2 submenus added.
		101,						// Add submenu with resource ID 101 (Terminal Port submenu).
		100,						// To menu with resource ID 100 (main VDT2 submenu).
		5,							// To item 5 of menu.

		102,						// Add submenu with resource ID 102 (Operations Port submenu).
		100,						// To menu with resource ID 100.
		12,							// To item 12 of menu.
	}
};

resource 'MENU' (100) {				// Submenu for VDT2 XOP,
	100,							// menu ID is same as resource ID.
	textMenuProc,
	0xFFFFFFFF,
	enabled,
	"VDT2",
	{
		"Open VDT2 Window", noIcon, noKey, noMark, plain,
		"-", noIcon, noKey, noMark, plain,
		"VDT2 Settings...", noIcon, noKey, noMark, plain,
		"-", noIcon, noKey, noMark, plain,
		"Terminal Port", noIcon, noKey, noMark, plain,
		"(Save File...", noIcon, noKey, noMark, plain,
		"(Insert File...", noIcon, noKey, noMark, plain,
		"(Send File...", noIcon, noKey, noMark, plain,
		"(Receive File...", noIcon, noKey, noMark, plain,
		"(Send Selected Text", noIcon, noKey, noMark, plain,
		"-", noIcon, noKey, noMark, plain,
		"Operations Port", noIcon, noKey, noMark, plain,
		"-", noIcon, noKey, noMark, plain,
		"Reset Serial Ports...", noIcon, noKey, noMark, plain,
		"-", noIcon, noKey, noMark, plain,
		"VDT2 Help", noIcon, noKey, noMark, plain,
	}
};

resource 'MENU' (101) {						/* submenu for Terminal Port */
	101,									/* menu ID is same as resource ID */
	textMenuProc,
	0xffffffff,
	enabled,
	"Terminal Port",
	{
		"(VDT2 is not yet loaded", noIcon, noKey, noMark, plain,
		"-", noIcon, noKey, check, plain,
		"Off Line", noIcon, noKey, check, plain,
	}
};

resource 'MENU' (102) {						/* submenu for Operations Port */
	102,									/* menu ID is same as resource ID */
	textMenuProc,
	0xffffffff,
	enabled,
	"Operations Port",
	{
		"(VDT2 is not yet loaded", noIcon, noKey, noMark, plain,
		"-", noIcon, noKey, check, plain,
		"Off Line", noIcon, noKey, check, plain,
	}
};
