#import <Cocoa/Cocoa.h>
#import "XOPStandardHeaders.h"
#import "VDT.h"

@interface VDTDialogController : NSWindowController <NSWindowDelegate, NSTextDelegate>
{
	/*	Compiling a property for 32 bits requires an explicit instance variable, a.k.a. "backing ivar". See
		http://stackoverflow.com/questions/3377869/how-to-define-and-implement-properties-in-protocol
	*/
	NSWindow* _dialogWindow;
	__weak NSPopUpButton* _portPopup;
	__weak NSTextField* _portCurrentlyClosedTextField;
	__weak NSTextField* _portCurrentlyOpenTextField;
	__weak NSButton* _openThisPortCheckbox;
	__weak NSButton* _closeThisPortCheckbox;
	__weak NSTextField* _portWillBeClosedTextField;
	__weak NSTextField* _portWillBeOpenedTextField;
	__weak NSButton* _useThisPortForTerminalOperationsCheckbox;
	__weak NSButton* _useThisPortForCommandLineOperationsCheckbox;
	__weak NSPopUpButton* _baudRatePopup;
	__weak NSPopUpButton* _dataLengthPopup;
	__weak NSPopUpButton* _stopBitsPopup;
	__weak NSPopUpButton* _parityPopup;
	__weak NSPopUpButton* _localEchoPopup;
	__weak NSPopUpButton* _terminalEOLPopup;
	__weak NSPopUpButton* _inputHandshakingPopup;
	__weak NSPopUpButton* _outputHandshakingPopup;
	__weak NSButton* _saveSetupWithExperimentCheckbox;
	__weak NSButton* _okButton;
	__weak NSButton* _cancelButton;
	
	bool settingsAreOK;
	DialogStorage* dialogStoragePtr;
	int dialogResult;						// 0 if OK, -1 if cancel, or error code

@public
	int saveExperimentSettings;				// State of the Save Setup With Experiment checkbox
}

@property (strong) IBOutlet NSWindow* dialogWindow;
@property (weak) IBOutlet NSPopUpButton* portPopup;
@property (weak) IBOutlet NSTextField* portCurrentlyClosedTextField;
@property (weak) IBOutlet NSTextField* portCurrentlyOpenTextField;
@property (weak) IBOutlet NSButton* openThisPortCheckbox;
@property (weak) IBOutlet NSButton* closeThisPortCheckbox;
@property (weak) IBOutlet NSTextField* portWillBeClosedTextField;
@property (weak) IBOutlet NSTextField* portWillBeOpenedTextField;
@property (weak) IBOutlet NSButton* useThisPortForTerminalOperationsCheckbox;
@property (weak) IBOutlet NSButton* useThisPortForCommandLineOperationsCheckbox;
@property (weak) IBOutlet NSPopUpButton* baudRatePopup;
@property (weak) IBOutlet NSPopUpButton* dataLengthPopup;
@property (weak) IBOutlet NSPopUpButton* stopBitsPopup;
@property (weak) IBOutlet NSPopUpButton* parityPopup;
@property (weak) IBOutlet NSPopUpButton* localEchoPopup;
@property (weak) IBOutlet NSPopUpButton* terminalEOLPopup;
@property (weak) IBOutlet NSPopUpButton* inputHandshakingPopup;
@property (weak) IBOutlet NSPopUpButton* outputHandshakingPopup;
@property (weak) IBOutlet NSButton* saveSetupWithExperimentCheckbox;
@property (weak) IBOutlet NSButton* okButton;
@property (weak) IBOutlet NSButton* cancelButton;

- (IBAction)okButtonClicked:(id)sender;
- (IBAction)cancelButtonClicked:(id)sender;
- (IBAction)portSelected:(id)sender;
- (IBAction)openPortCheckboxClicked:(id)sender;
- (IBAction)closePortCheckboxClicked:(id)sender;
- (IBAction)terminalPortCheckboxClicked:(id)sender;
- (IBAction)operationsPortCheckboxClicked:(id)sender;
- (IBAction)baudRateSelected:(id)sender;
- (IBAction)dataLengthSelected:(id)sender;
- (IBAction)stopBitsSelected:(id)sender;
- (IBAction)paritySelected:(id)sender;
- (IBAction)localEchoSelected:(id)sender;
- (IBAction)terminalEOLSelected:(id)sender;
- (IBAction)inputHandshakeSelected:(id)sender;
- (IBAction)outputHandshakeSelected:(id)sender;
- (IBAction)saveSetupWithExpCheckboxClicked:(id)sender;

- (void)controlTextDidChange:(NSNotification*)notification;	// Called by NSTextView controls for which we are wired in the nib as the delegate
- (void)windowDidLoad;
- (BOOL)windowShouldClose:(id)sender;
- (void)windowWillClose:(NSNotification*)notification;

- (void)setOpenAndClosedItems:(VDTPortPtr)port;
- (void)initializeDialog;
- (void)updateDialog;
- (int)runModalDialog:(DialogStorage*)dsp;
@end

@interface VDTDialogLoader : NSObject
{
	/*	Compiling a property for 32 bits requires an explicit instance variable, a.k.a. "backing ivar". See
		http://stackoverflow.com/questions/3377869/how-to-define-and-implement-properties-in-protocol
	*/
	VDTDialogController* _dialogController;

@public
	int saveExperimentSettings;				// State of the Save Setup With Experiment checkbox
}

@property (strong) IBOutlet VDTDialogController* dialogController;

-(int)runVDTDialog:(DialogStorage*)dsp;

@end

int VDTSettingsDialog(int useExpSettingsIn, int* useExpSettingsOutPtr);

