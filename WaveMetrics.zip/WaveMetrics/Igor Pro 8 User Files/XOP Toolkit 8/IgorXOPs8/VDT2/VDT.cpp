/*	VDT.c -- implements a dumb terminal (very dumb terminal) as an Igor XOP

	VDT is documented in the 'VDT Documentation' file on the Igor Extras disk
	and in the "VDT Help" file in Igor Pro's "More Help Files:Data Acquisition"
	folder.
	
	Change History
	
	6/10/92
		For Igor Pro 2.0 and beyond, added 'Save File' and 'Insert File' items to
		VDT menu because these items have been removed from Igor Pro.
		
	5/18/93
		Fixed Hex2Long in VDTIO.c to treat 2 and 4 character hex values as SIGNED.
		Previously, it treated them as signed but treated 8 character values as signed.
	
	3/28/94
		Changed some things to check igorVersion. Compiled VDT 1.20.
	
	5/11/94
		Used CloseWindow instead of DisposeWindow.
		Compiled version 1.21.
	
	8/24/94
		Set routines that require 68K assembly to compile under MPW for 68K only,
		not under THINK or PowerPC compilers. These are the hex IO routines,
		VDTReadHex, VDTWriteHex, VDTReadHexWave and VDTWriteHexWave.
	
	1/12/96
		Removed calls to 68K assembly so that hex I/O routines can work in PPC version.
		Added error checking after InitVDT.
		Prevented idle loop from attempting to access driver if the driver is not open.

	9/9/96 for version 1.31
		Fixed timeout in binary operations. VDTGetBinaryFlags was treating the timeout
		parameter as a number of ticks when it should be a number of seconds.
	
	4/25/97
		Changed GetXOPWindow to pass NULL for wStorage parameter as required under Windows.
		As a consequence of this, I changed CloseWindow instead of DisposeWindow.
	
	9/11/97 for version 2.0
		Reorganized and ported to Windows.
	
	9/14/97 for version 2.0
		Split out dumb-terminal-related routines into VDTTerminal.c.

	9/15/97 for version 2.0
		Split out dialog-related routines into VDTDialog.c.

	3/18/98 for version 2.1
		Revamped so that VDT for Windows can be compiled by XOP Toolkit users.
		Because of this, this version requires Igor Pro 3.13 or later.
		
	021024:
		Totally revamped using Operation Handler so that VDT operations are
		directly usable in user functions.

	HR, 2013-02-08
		Updated for Xcode 4 compatibility. Changed to use XOPMain instead of main.
		As a result the XOP now requires Igor Pro 6.20 or later.
		
	HR, 2014-07-28: Updated for Igor7 compatibility including:
		Used new window message codes (e.g., kXOPWindowMessageActivate) in place of old (e.g., ACTIVATE).
		Used new container message codes (e.g., kXOPContainerMessageMouseClick) in place of old (.e.g, CLICK)
		
	HR, 2017-11-02, 2.10:
		Updated VDT2 to support long names. Consequently it now requires Igor8.
		
	HR, 2018-04-15, 2.20:
		Added VDTGetPortList2 /SCAN flag and VDT2 resetPorts keyword to allow a programmer to
		detect and respond to the addition or removal of USB-to-serial adapters.
		
	HR, 2018-04-17, 2.20:
		Split VDTMenus.cpp out of this file.
		
	HR, 2018-05-04
		Recompiled with XOP Toolkit 8 which supports long object names.
		As a result the XOP now requires Igor Pro 8.00 or later.
*/

#include "XOPStandardHeaders.h"			// Include ANSI headers, Mac headers, IgorXOP.h, XOP.h and XOPSupport.h
#include "VDT.h"

// Global Variables
static int gSettingsModified = 0;				// True if need to save new settings.
int gUseExpSettings = 0;						// Should VDT reset settings when experiment loaded ?.
static IgorWindowRef gVDTWindow = NULL;
static int gDisposeInProgress = 0;			// Flag used by XOPEntry.
Handle gVDTTU = NULL;

void
VDTSettingsModified(int state)		// state is 1 if modified since last save, 0 if settings saved and therefore are now unmodified
{
	gSettingsModified = state;
}

/*	VDTAlert(message, strID, itemNum)

	Puts up alert.
	If message is not NULL, uses that as message.
	Otherwise, gets message from STR# resource identified by strID and itemNum.
*/
void
VDTAlert(char *message, int strID, int itemNum)
{
	char alert[256];

	if (message == NULL)
		GetXOPIndString(alert, strID, itemNum);
	else
		strcpy(alert, message);
	XOPOKAlert("VDT2 Error", alert);
}

void
ErrorAlert(int errorCode)		// errorCode can be VDT error, Igor error or system error code.
{
	if (errorCode>=FIRST_XOP_ERR && errorCode<=LAST_XOP_ERR)
		VDTAlert(NULL, XOP_ERRS_ID, errorCode-FIRST_XOP_ERR);
	else
		IgorError("VDT2 Error", errorCode);
}

void
ExplainPortError(const char* preamble, int err)
{
	char errMessage[256];
	char message[256];
	
	if (err>=FIRST_XOP_ERR && err<=LAST_XOP_ERR)		// VDT error.
		GetXOPIndString(errMessage, XOP_ERRS_ID, err-FIRST_XOP_ERR);
	else
		snprintf(errMessage, sizeof(errMessage), "Error number %d", err);	// Igor or system error.
	strcpy(message, preamble);
	strcat(message, errMessage);
	VDTAlert(message, 0, 0);
}

int
CheckPort(VDTPortPtr pp, int doAlert)
{
	int result=0;
	
	if (pp == NULL)	{							// Couldn't open port?
		result = CANT_INIT;
	}
	else {
		if (!VDTPortIsOpen(pp))
			result = NO_PORT;
	}
	if (result && doAlert)
		VDTAlert(NULL, 1100, result-FIRST_XOP_ERR);
	return result;
}

int
VDTNoCharactersSelected(void)
{
	TULoc startLoc, endLoc;
	
	TUGetSelLocs(gVDTTU, &startLoc, &endLoc);
	return startLoc.paragraph==endLoc.paragraph && startLoc.pos==endLoc.pos;
}

int
VDTInsertText(void)
{
	OSType fileTypes;
	
	#ifdef MACIGOR
		fileTypes = 'TEXT';			// We want to insert a file containing plain text.
	#endif
	#ifdef WINIGOR
		fileTypes = '\?\?\?\?';		// On Windows, there is no extension that covers all files with plain text, so allow any file.
	#endif

	return(TUSFInsertFile(gVDTTU, "File to insert in VDT window:", &fileTypes, 1));
}

int
VDTSaveText(void)
{
	return(TUSFWriteFile(gVDTTU, "Save VDT text as:", 'TEXT', TRUE));		// Write TEXT file on Mac, .txt file on Windows.
}

/*	XOPNew()

	XOPNew() is called when a new document is opened in the host application. The XOP should
	reset itself to its default settings.
*/
static void
XOPNew(void)
{
	TUSelectAll(gVDTTU);
	TUDelete(gVDTTU);
	XOPModified = FALSE;
}

/*	GetVDTSettingsHandle(hPtr)

	Returns via hPtr a handle containing the current VDT setup or NULL if can't get memory.
	
	Function result is 0 if OK or error code.
*/
static int
GetVDTSettingsHandle(VDTSettingsHandle* hPtr)
{
	VDTPortPtr tp, op;
	int index, numPorts, numBytes;
	VDTSettingsHandle vsHandle;
	VDTSettingsPtr vsPtr;
	VDTPortSettingsPtr psp;
	int winState;
	
	*hPtr = NULL;
	
	// Find number of open ports (may be zero).
	numPorts = 0;
	index = 0;
	while(IndexedVDTPort(NULL, index) != NULL) {
		index += 1;
		numPorts += 1;
	}
	
	numBytes = (int)(sizeof(VDTSettings) + (numPorts-1)*sizeof(VDTPortSettings));	// -1 because the VDTSettings field has one VDTPortSettings record in it.
	vsHandle = (VDTSettingsHandle)WMNewHandle(numBytes);
	if (vsHandle == NULL)
		return NOMEM;
	vsPtr = *vsHandle;
	MemClear(vsPtr, numBytes);

	vsPtr->version = VDT_VERSION;
	vsPtr->useExpSettings = gUseExpSettings;
	op = VDTGetOperationsPortPtr();
	if (op != NULL)
		strcpy(vsPtr->opPortName, op->name);
	tp = VDTGetTerminalPortPtr();
	if (tp != NULL)
		strcpy(vsPtr->termPortName, tp->name);

	GetIgorWindowPositionAndState(gVDTWindow, &vsPtr->winRect, &winState);
	vsPtr->winState = winState;

	// Added in VDT2 2.00 - All fields will be 0 if written by earlier versions
	{
		extern DialogPositionAndSize gDialogPositionAndSize;
		vsPtr->dialogPosition = gDialogPositionAndSize;
	}
	
	vsPtr->numPortSettings = numPorts;
	
	for(index=0; index<numPorts; index++) {
		VDTPortPtr pp;
		pp = IndexedVDTPort(NULL, index);
		psp = &vsPtr->ps[index];
		strcpy(psp->name, pp->name);
		strcpy(psp->inputChan, pp->inputChan);
		strcpy(psp->outputChan, pp->outputChan);
		psp->baudCode = pp->baudCode;
		psp->parity = pp->parity;
		psp->stopbits = pp->stopbits;
		psp->databits = pp->databits;
		psp->echo = pp->echo;
		psp->inShake = pp->inShake;
		psp->outShake = pp->outShake;
		psp->terminalEOL = pp->terminalEOL;
		psp->inputBufferSize = pp->inputBufferSize;
		psp->selectedInDialog = pp->selectedInDialog;
	}
	
	*hPtr = vsHandle;
	return 0;
}

/*	StoreVDTSetup()

	Stores current VDT settings in the IGOR preferences file.
	
	Returns error code from writing resource.
*/
static int
StoreVDTSetup(void)
{
	VDTSettingsHandle vsHandle;
	int result;
	
	if (result = GetVDTSettingsHandle(&vsHandle))
		return result;
	
	result = SaveXOPPrefsHandle((Handle)vsHandle);		// SaveXOPPrefsHandle makes its own copy of handle.
	WMDisposeHandle((Handle)vsHandle);
	
	return result;
}

/*	SetVDTSetup(vsHandle, loadingExperiment)

	Sets VDT settings from contents of vsHandle.
	
	This routine does not change the open/closed status of ports.
	
	loadingExperiment is true if we are loading settings from an experiment file,
	false if we are loading settings from preferences file.
	
	If the settings come from another platform (e.g. Windows when we are running
	on Mac or vice versa), SetVDTSetup does nothing. To support cross-platform
	settings, we would need to do byte-swapping on the structure and also take
	into account the different meaning of the winRect field.
		
	Returns:
		0 if everything OK
		1 if this version of VDT doesn't know about version of settings
		2 if vsHandle was NULL
		3 if vsHandle contains byte-swapped settings.
*/
static int
SetVDTSetup(VDTSettingsHandle vsHandle, int loadingExperiment)
{
	VDTPortPtr op, tp;
	int index, numPorts;
	VDTSettingsPtr vsPtr;
	VDTPortSettingsPtr psp;
	short version;
	int winState;
	int err;

	if (vsHandle == NULL)
		return 2;
	
	version = (*vsHandle)->version;				// Version of settings structure.
	
	if ((version & 0xFF) == 0)					// Don't support cross-platform settings.
		return 3;
	
	if (version < VDT_VERSION)					// Don't support old versions.
		return 1;
	
	if (version > VDT_VERSION)					// Don't know about new versions.
		return 1;

	op = VDTGetOperationsPortPtr();
	if (op != NULL)
		KillVDTIO(op);
	VDTAbortTerminalOperation();

	vsPtr = *vsHandle;

	gUseExpSettings = vsPtr->useExpSettings;
	winState = vsPtr->winState;
	if (!loadingExperiment)					// Just launched VDT and loading prefs?
		winState &= ~1;						// Clear bit 0 - leave window hidden.
	
	SetIgorWindowPositionAndState(gVDTWindow, &vsPtr->winRect, winState);
	TUGrow(gVDTTU, -1);						// Allow TU document to adjust to change in window size.

	{
		extern DialogPositionAndSize gDialogPositionAndSize;
		if (vsPtr->dialogPosition.width!=0 && vsPtr->dialogPosition.height!=0)
			gDialogPositionAndSize = vsPtr->dialogPosition;
	}

	numPorts = vsPtr->numPortSettings;
	
	for(index=0; index<numPorts; index++) {
		VDTPortPtr pp;
		pp = IndexedVDTPort(NULL, index);
		psp = &vsPtr->ps[index];
		TranslatePortName(psp->name);		// Do platform-related port name translation and handle other name equivalences.
		pp = FindVDTPort(NULL, psp->name);
		if (pp == NULL) {
			// This port is not available now. (e.g., opening Mac experiment on PC).
			continue;
		}
		
		pp->selectedInDialog = psp->selectedInDialog;
		
		pp->baudCode = ValidateBaudCode(psp->baudCode);
		pp->parity = psp->parity;
		pp->stopbits = psp->stopbits;
		pp->databits = psp->databits;
		pp->echo = psp->echo;
		pp->inShake = psp->inShake;
		pp->outShake = psp->outShake;
		pp->terminalEOL = psp->terminalEOL;
		SetInputBufferSize(pp, psp->inputBufferSize);

		if (pp->portIsOpen) {
			if (err = SetCommPortSettings(pp)) {
				char temp[128];
				snprintf(temp, sizeof(temp), "While changing settings for %s port, the following error occurred: ", pp->name);
				ExplainPortError(temp, err);
				continue;
			}
		}
	}

	op = FindVDTPort(NULL, vsPtr->opPortName);			// NULL if port does not exist.
	VDTSetOperationsPortPtr(op);						// It is OK if NULL or the port is not open.

	tp = FindVDTPort(NULL, vsPtr->termPortName);		// NULL if port does not exist.
	VDTSetTerminalPortPtr(tp);							// It is OK if NULL or the port is not open.
	
	/*	If there is a designated terminal port, we must open it so that if any incoming
		characters will be received.
	*/
	VDTGetOpenAndCheckTerminalPortPtr(&tp, 0);
	
	return 0;
}

/*	LoadVDTSetup()

	Loads VDT settings from the IGOR preferences file.
	Then, sets up hardware accordingly.
	
	Returns 0 or error code.
*/
static int
LoadVDTSetup(void)
{
	VDTSettingsHandle vsHandle;
	int result;
	
	if (result = GetXOPPrefsHandle((Handle*)&vsHandle))
		return result;
	result = SetVDTSetup(vsHandle, 0);
	WMDisposeHandle((Handle)vsHandle);
	
	return result;
}

/*	XOPLoadSettings()

	XOPLoadSettings() is called when a existing experiment is opened in the IGOR
	only if the XOP has previously stored its settings in the experiment using
	XOPSaveSettings.
	
	The XOPRecHandle contains a handle to the saved settings which the XOP can use to restore
	its settings or NULL if there are no settings to restore.
	
	NOTE: the host will dispose of this handle shortly so if you want, make a copy of it.
*/
static void
XOPLoadSettings(void)
{
	VDTSettingsHandle vsHandle;
	
	vsHandle = (VDTSettingsHandle)GetXOPItem(0);			// NOTE: This handle still belongs to IGOR.
	if (vsHandle == NULL)
		return;												// We did not save settings in this experiment.
	
	gUseExpSettings = (*vsHandle)->useExpSettings;
	if (gUseExpSettings)
		SetVDTSetup(vsHandle, 1);
	VDTSettingsModified(0);
}

/*	XOPSaveSettings()

	XOPSaveSettings() is called when the current experiment is saved in the IGOR.
	The XOP can return a handle to data to be saved in the experiment.
	If the XOP does not want to save anything it should return NULL.
		
	NOTE: The host will dispose of this handle shortly so if you want, make a copy of it.
*/
static Handle
XOPSaveSettings(void)
{
	VDTSettingsHandle vsHandle = NULL;
	
	if (gUseExpSettings) {							// Want to save settings in experiment ?
		GetVDTSettingsHandle(&vsHandle);			// vsHandle will be NULL if error.
		VDTSettingsModified(0);
	}
	return((Handle)vsHandle);
}

/*	XOPIdle()

	XOPIdle() is called periodically by the host application when nothing else is going on.
	It allows the XOP to perform periodic, ongoing tasks.
*/
static void
XOPIdle(void)
{
	TUIdle(gVDTTU);
		
	VDTTerminalIdle();							// Handle dumb terminal chores.
}

void
UpdateStatusArea(void)
{
	VDTPortPtr tp, op;
	char termPortDescription[256];
	char opPortDescription[256];
	char message[512];

	tp = VDTGetTerminalPortPtr();
	if (tp == NULL) {
		strcpy(termPortDescription, "Off line");
	}
	else {
		if (tp->portIsOpen)
			snprintf(termPortDescription, sizeof(termPortDescription), "%s (open)", tp->name);
		else
			snprintf(termPortDescription, sizeof(termPortDescription), "%s (closed)", tp->name);
	}

	op = VDTGetOperationsPortPtr();
	if (op == NULL) {
		strcpy(opPortDescription, "Off line");
	}
	else {
		if (op->portIsOpen)
			snprintf(opPortDescription, sizeof(opPortDescription), "%s (open)", op->name);
		else
			snprintf(opPortDescription, sizeof(opPortDescription), "%s (closed)", op->name);
	}
	
	snprintf(message, sizeof(message), "Terminal port: %s.  Operations port: %s.", termPortDescription, opPortDescription);
	TUSetStatusArea(gVDTTU, message, TU_ERASE_STATUS_NEVER, -1);
}

/*	HandleWindowMessage(message)

	WindowMessage handles any window message (update, activate, etc).
	The meaning of the function return value depends on the message received.
*/
static XOPIORecResult
HandleWindowMessage(int message)
{	
	XOPIORecResult result = 0;
			
	IgorWindowRef windowRef = (IgorWindowRef)GetXOPItem(0);
	if (windowRef == NULL)
		return GENERAL_BAD_VIBS;						// Should never happen
	
	switch (message) {
		case kXOPWindowMessageActivate:
			{
				int activeFlag = (int)GetXOPItem(1);	//  1 for activate, 0 for deactivate
				TUActivate(gVDTTU, activeFlag);
			}
			break;
			
		case kXOPWindowMessageUpdate:
			TUUpdate(gVDTTU);
			break;
			
		case kXOPWindowMessageResized:
			TUGrow(gVDTTU, -1);					// Adjust window for size change that has already occurred
			VDTSettingsModified(1);				// So that new window size will be written to Igor Prefs file.
			break;
			
		case kXOPWindowMessageMoved:
			VDTSettingsModified(1);				// So that new window size will be written to Igor Prefs file.
			break;
			
		case kXOPWindowMessageZoom:
			TUGrow(gVDTTU, 0);					// Zoom window in or out as appropriate
			VDTSettingsModified(1);				// So that new window size will be written to Igor Prefs file.
			break;
			
		case kXOPWindowMessageSetSizeLimits:
			{
				Rect* rectPtr;
				rectPtr = (Rect*)GetXOPItem(1);
				rectPtr->left = MIN_WIN_WIDTH;
				rectPtr->top = MIN_WIN_HEIGHT;
			}
			break;
			
		case kXOPWindowMessageCloseMeansHide:
			result = 1;							// Click on close box means hide window
			break;
			
		case kXOPWindowMessagePageSetup:
			TUPageSetupDialog(gVDTTU);
			break;
			
		case kXOPWindowMessagePrint:
			TUPrint(gVDTTU);
			break;
			
		case kXOPWindowMessageMoveToPreferredPosition:
			TUMoveToPreferredPosition(gVDTTU);
			break;
			
		case kXOPWindowMessageMoveToFullPosition:
			TUMoveToFullSizePosition(gVDTTU);
			break;
			
		case kXOPWindowMessageRetrieveWindow:
			TURetrieveWindow(gVDTTU);
			break;
	}
	return result;
}

/*	HandleKeyPress(TU, eventPtr)

	Handles a keystroke event by sending the key to the VDT window and/or by
	sending the key to the serial port.
	
	Returns true if the key was sent to the VDT window.
	
	"Online" means that the chosen terminal port is not "None".
	
	The key is sent to the VDT window if we are online and local echo mode is on
	or if we are not online.
	
	The key is sent to the serial port if the terminal port is online
	and if the key is a sendable key (i.e., not page up, page down, etc.)
*/
static int
HandleKeyPress(WMKeyboardEventRecord* kerP)
{
	VDTPortPtr tp;
	int terminalIsOnline;
	int sentKeyToVDTWindow;
	
	if (kerP->eventType != kWMKeydownEvent)
		return 0;										// Ignore kWMKeyupEvent
	
	sentKeyToVDTWindow = 0;

	terminalIsOnline = VDTGetTerminalPortPtr() != NULL;
	tp = NULL;
	if (terminalIsOnline) {
		VDTGetOpenAndCheckTerminalPortPtr(&tp, 1);		// tp may be null.
		if (tp == NULL)
			return 0;									// We are online but can't open the port.
	}
	
	if ((tp!=NULL && tp->echo) || !terminalIsOnline) {
		TUKey(gVDTTU, kerP);
		sentKeyToVDTWindow = 1;
	}
	
	if (tp!=NULL && terminalIsOnline) {
		char textToSend[64];
		*textToSend = 0;
		if (kerP->specialKeyCode != 0) {
			switch(kerP->specialKeyCode)
			{
				case kWMKeyCodeReturn:
				case kWMKeyCodeEnter:
					strcpy(textToSend, CR_STR);
					break;
				case kWMKeyCodeTab:
					strcpy(textToSend, "\t");
					break;
				case kWMKeyCodeEscape:
					strcpy(textToSend, "\033");			// Octal 033 == hex 1B == decimal 27 == escape character
					break;
			}
		}
		else {
			strcpy(textToSend, kerP->text);
		}
		
		const char* p = textToSend;
		while(*p != 0) {
			VDTSendTerminalChar(tp, *p);
			p += 1;
		}
	}

	return sentKeyToVDTWindow;
}

/*	HandleContainerMessage(message)

	ContainerMessage handles any container messages (click, mouse move, etc.).
	The meaning of the function return value depends on the message received.
*/
static XOPIORecResult
HandleContainerMessage(int message)
{	
	XOPIORecResult result = 0;
	
	IgorContainerRef container = (IgorContainerRef)GetXOPItem(0);
	if (container == NULL)
		return GENERAL_BAD_VIBS;						// Should never happen
	
	switch (message) {
		case kXOPContainerMessageMouseClick:
			{
				WMMouseEventRecord* merP;
				merP = (WMMouseEventRecord*)GetXOPItem(1);
				TUClick(gVDTTU, merP);
			}
			break;
			
		case kXOPContainerMessageMouseMove:
			{
				WMMouseEventRecord* merP;
				merP = (WMMouseEventRecord*)GetXOPItem(1);
				TUNull(gVDTTU, merP);
			}
			break;
			
		case kXOPContainerMessageKeyPressed:
			{
				WMKeyboardEventRecord* kerP;
				kerP = (WMKeyboardEventRecord*)GetXOPItem(1);
				HandleKeyPress(kerP);
			}
			break;
			
		case kXOPContainerMessageCopy:
			TUCopy(gVDTTU);
			break;
			
		case kXOPContainerMessageCut:
			TUCut(gVDTTU);
			XOPModified = TRUE;
			break;
			
		case kXOPContainerMessagePaste:
			TUPaste(gVDTTU);
			XOPModified = TRUE;
			break;
			
		case kXOPContainerMessageClear:
			TUClear(gVDTTU);
			XOPModified = TRUE;
			break;
			
		case kXOPContainerMessageFind:
		case kXOPContainerMessageFindSame:
		case kXOPContainerMessageFindSameBackwards:
		case kXOPContainerMessageFindSelection:
		case kXOPContainerMessageFindSelectionBackwards:
		case kXOPContainerMessageUseSelectionForFind:
			TUFind(gVDTTU, message);
			break;
			
		case kXOPContainerMessageDisplaySelection:
			TUDisplaySelection(gVDTTU);
			break;
			
		case kXOPContainerMessageReplace:
			TUReplace(gVDTTU);
			XOPModified = TRUE;
			break;
			
		case kXOPContainerMessageIndentLeft:
			TUIndentLeft(gVDTTU);
			XOPModified = TRUE;
			break;
			
		case kXOPContainerMessageIndentRight:
			TUIndentRight(gVDTTU);
			XOPModified = TRUE;
			break;
			
		case kXOPContainerMessageUndo:
			TUUndo(gVDTTU);
			break;
			
		case kXOPContainerMessageSelectAll:
			TUSelectAll(gVDTTU);
			break;
			
		case kXOPContainerMessageInsertFile:
			result = VDTInsertText();
			break;
	}
	return result;
}

static void
DisposeVDTWindow(void)
{
	gDisposeInProgress = 1;						// Flag used by XOPEntry.

	if (gVDTTU == NULL)
		return;

	TUDispose(gVDTTU);							// Discard text window.
	gVDTTU = NULL;
}

/*	XOPEntry()

	This is the entry point from the host application to the XOP when the message specified by the
	host is other than INIT.
*/
extern "C" void
XOPEntry(void)
{	
	XOPIORecResult result = 0;
	
	if (gDisposeInProgress) {
		/*	If here, we got a message from IGOR while we were quitting VDT.
			We may have already disposed some VDT resources (e.g. VDT window).
			Therefore, we can't service the message. This happens because, under Windows,
			when we close the VDT window, the Windows OS sends a barrage of messages.
		*/
		return;	
	}

	int message;
	message = GetXOPMessage();
	
	int isWindowMessage = 0;
	if (message>=kXOPWindowMessageFirst && message<=kXOPWindowMessageLast)
		isWindowMessage = 1;
		
	int isContainerMessage = 0;
	if (message>=kXOPContainerMessageFirst && message<=kXOPContainerMessageLast)
		isContainerMessage = 1;
	
	if (isWindowMessage) {
		result = HandleWindowMessage(message);
		SetXOPResult(result);
		return;
	}
	
	if (isContainerMessage) {
		result = HandleContainerMessage(message);
		SetXOPResult(result);
		return;
	}

	switch (message) {
		case CLEANUP:								// XOP about to be disposed of.
			VDTAbortTerminalOperation();			// Abort any operation in progress.
			if (gSettingsModified)					// Need to write settings out ?
				StoreVDTSetup();
			CloseAllVDTPorts();
			DisposeAllVDTPorts();
			DisposeVDTWindow();
			break;
		
		case IDLE:									// Time to perform idle functions.
			XOPIdle();
			break;
		
		case NEW:									// New experiment -- init settings.
			XOPNew();
			break;
		
		case LOADSETTINGS:							// Loading experiment -- load settings.
			XOPLoadSettings();
			break;
		
		case SAVESETTINGS:							// Saving experiment -- save settings.
			result = (XOPIORecResult)XOPSaveSettings();
			break;
		
		case MODIFIED:								// Saving experiment -- save settings.
			result = XOPModified;
			result |= gUseExpSettings && gSettingsModified;
			break;
		
		case MENUITEM:								// XOPs menu item selected.
			{
				// Make sure to get all XOP items before doing another callback to Igor.
				int menuID = (int)GetXOPItem(0);
				int itemID = (int)GetXOPItem(1);
				result = HandleVDTMenuItemSelected(menuID, itemID, gVDTWindow);
				break;
			}
		
		case MENUENABLE:							// Enable/disable XOPs menu item.
			SetVDTMenuItems(gVDTWindow, gVDTTU);
			break;
	}
	SetXOPResult(result);
}

static int
RegisterOperations(void)
{
	int err;
	
	if (err = RegisterVDTGetPortList2())
		return err;

	if (err = RegisterVDTOpenPort2())
		return err;

	if (err = RegisterVDTClosePort2())
		return err;

	if (err = RegisterVDTTerminalPort2())
		return err;

	if (err = RegisterVDTOperationsPort2())
		return err;

	if (err = RegisterVDT2())
		return err;

	if (err = RegisterVDTGetStatus2())
		return err;

	if (err = RegisterVDTRead2())
		return err;

	if (err = RegisterVDTReadWave2())
		return err;

	if (err = RegisterVDTReadBinary2())
		return err;

	if (err = RegisterVDTReadBinaryWave2())
		return err;

	if (err = RegisterVDTReadHex2())
		return err;

	if (err = RegisterVDTReadHexWave2())
		return err;

	if (err = RegisterVDTWrite2())
		return err;

	if (err = RegisterVDTWriteWave2())
		return err;

	if (err = RegisterVDTWriteBinary2())
		return err;

	if (err = RegisterVDTWriteBinaryWave2())
		return err;

	if (err = RegisterVDTWriteHex2())	
		return err;

	if (err = RegisterVDTWriteHexWave2())
		return err;
	
	return 0;
}

/*	XOPMain(ioRecHandle)

	This is the initial entry point at which the host application calls XOP.
	The message sent by the host must be INIT.
	
	XOPMain does any necessary initialization and then sets the XOPEntry field of the
	ioRecHandle to the address to be called for future messages.
*/
HOST_IMPORT int
XOPMain(IORecHandle ioRecHandle)
{	
	Rect winRect;
	int err;
	
	XOPInit(ioRecHandle);				// Do standard XOP initialization
	SetXOPEntry(XOPEntry);				// Set entry point for future calls.
	SetXOPType(RESIDENT | IDLES);		// Specify XOP to stick around and to receive IDLE messages.

	if (igorVersion < 800) {			// Requires Igor 8.00 or later because of use of long object names.
		SetXOPResult(OLD_IGOR);			// OLD_IGOR is defined in NIGPIB.h and there are corresponding error strings in NIGPIB.r and NIGPIBWinCustom.rc.
		return EXIT_FAILURE;
	}
	
	if (err = RegisterOperations()) {
		SetXOPResult(err);
		return EXIT_FAILURE;
	}
		
	// Create XOP TU record and window.
	winRect.left = 5;
	winRect.right = 500;
	winRect.top = 160;
	winRect.bottom = 260;
	err = TUNew2("VDT2", &winRect, &gVDTTU, &gVDTWindow);
	if (err != 0) {
		SetXOPResult(err);
		return EXIT_FAILURE;
	}

	TUSetStatusArea(gVDTTU, "", TU_ERASE_STATUS_NEVER, 300);	// Set initial status area width.
	
	if (err = InitVDTPorts()) {
		DisposeVDTWindow();
		SetXOPResult(err);
		return EXIT_FAILURE;
	}

	if (LoadVDTSetup())							// Try to load settings from IGOR preferences file.
		gSettingsModified = 1;					// If no settings, flag settings to be written.
	
	FillPortMenus();
	
	UpdateStatusArea();
	
	SetXOPResult(0);
	return EXIT_SUCCESS;
}
